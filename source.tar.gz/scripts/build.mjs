import { cp, mkdir, writeFile, access } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../", import.meta.url));
const engine = path.resolve(process.argv[2] || path.join(root, "engine", "build", "bin"));
const files = ["srb2.mjs", "srb2.wasm"];
await Promise.all(files.map(name => access(path.join(engine, name))));

const client = path.join(root, "dist/client");
const server = path.join(root, "dist/server");
await Promise.all([client, server].map(dir => mkdir(dir, { recursive: true })));

await Promise.all([
  cp(path.join(root, "web"), client, { recursive: true }),
  cp(path.join(root, "worker/index.mjs"), path.join(server, "index.js")),
  cp(path.join(root, "worker/game-download.mjs"), path.join(server, "game-download.mjs")),
  cp(path.join(root, "worker/public-relay.mjs"), path.join(server, "public-relay.mjs")),
  cp(path.join(root, "common/relay-ticket.mjs"), path.join(server, "relay-ticket.mjs")),
  ...[client, server].map(dir => cp(path.join(root, "common/directory.mjs"), path.join(dir, "directory.mjs"))),
  ...[client, server].map(dir => cp(path.join(root, "common/game-data.mjs"), path.join(dir, "game-data.mjs"))),
  cp(path.join(root, "engine/LICENSE"), path.join(client, "license.txt")),
  ...files.map(name => cp(path.join(engine, name), path.join(client, name))),
]);

await writeFile(path.join(server, "wrangler.json"), JSON.stringify({
  main: "index.js",
  compatibility_date: "2026-01-01",
  assets: { directory: "../client", binding: "ASSETS", run_worker_first: true },
}, null, 2));

const sourceFiles = [
  "engine/CMakeLists.txt", "engine/WebTarget.cmake", "engine/src",
  "engine/LICENSE", "engine/LICENSE-3RD-PARTY.txt", "common", "relay", "scripts",
  "web", "worker", "package.json", "package-lock.json", "README.md", ".github/workflows/pages.yml",
];
const tar = spawnSync("tar", [
  "-czf", path.join(client, "source.tar.gz"), "-C", root, ...sourceFiles,
], { stdio: "inherit" });
if (tar.error || tar.status !== 0) throw tar.error || new Error("Source archive creation failed");
