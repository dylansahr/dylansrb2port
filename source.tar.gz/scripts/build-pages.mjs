import { cp, mkdir, readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const [outputDirectory, relayOrigin] = process.argv.slice(2);
if (!outputDirectory || !relayOrigin) {
  throw new Error("Usage: npm run build:pages -- <output directory> <HTTPS relay origin>");
}
const relay = new URL(relayOrigin);
if (relay.protocol !== "https:" || relay.href !== relay.origin + "/") {
  throw new Error("The Pages relay must be an HTTPS origin.");
}

const source = fileURLToPath(new URL("../dist/client/", import.meta.url));
const target = resolve(outputDirectory);
await cp(source, target, { recursive: true });

const index = resolve(target, "index.html");
const html = await readFile(index, "utf8");
await Promise.all([
  writeFile(index, html.replace("</head>", `  <meta name="srb2-relay" content="${relay.origin}">\n</head>`)),
  writeFile(resolve(target, ".nojekyll"), ""),
  mkdir(resolve(target, "scripts"), { recursive: true }).then(() =>
    cp(new URL("./stage-game-data.mjs", import.meta.url), resolve(target, "scripts/stage-game-data.mjs"))),
  cp(new URL("../.github/workflows/", import.meta.url), resolve(target, ".github/workflows"), { recursive: true }),
]);
