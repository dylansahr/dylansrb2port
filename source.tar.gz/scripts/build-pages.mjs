import { cp, readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

const [outputDirectory, backendOrigin] = process.argv.slice(2);
if (!outputDirectory || !backendOrigin) {
  throw new Error("Usage: npm run build:pages -- <output directory> <HTTPS backend origin>");
}
const backend = new URL(backendOrigin);
if (backend.protocol !== "https:" || backend.href !== backend.origin + "/") {
  throw new Error("The Pages backend must be an HTTPS origin.");
}

const source = fileURLToPath(new URL("../dist/client/", import.meta.url));
const target = resolve(outputDirectory);
await cp(source, target, { recursive: true });

const index = resolve(target, "index.html");
const html = await readFile(index, "utf8");
await writeFile(index, html.replace("</head>", `  <meta name="srb2-backend" content="${backend.origin}">\n</head>`));
await writeFile(resolve(target, ".nojekyll"), "");
