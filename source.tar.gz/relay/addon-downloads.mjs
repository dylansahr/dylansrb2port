import { createHash, randomBytes } from "node:crypto";
import { lookup } from "node:dns/promises";
import { request as httpRequest } from "node:http";
import { request as httpsRequest } from "node:https";
import { isIP } from "node:net";
import { Transform } from "node:stream";
import { pipeline } from "node:stream/promises";
import { setImmediate } from "node:timers/promises";
import {
  addonFragment, advertisedAddons, listAdvertisement, packet, packetHeader,
  serverAdvertisement, validGamePacket,
} from "./game-packets.mjs";

const maxCachedFile = 32 * 1024 * 1024;
const maxCacheSize = 96 * 1024 * 1024;
const maxPendingSize = 64 * 1024 * 1024;
const maxFiles = 255; // SRB2 reserves file index 255 as the request terminator.

function mirrorBase(value) {
  const url = URL.parse(value);
  if (!url || !["https:", "http:"].includes(url.protocol) || url.username || url.password ||
      url.search || url.hash) return null;
  if (!url.pathname.endsWith("/")) url.pathname += "/";
  return url;
}

async function openMirror(url, allowAddress, signal, redirects = 0) {
  const base = mirrorBase(url.origin);
  if (!base || url.username || url.password) throw new Error("Invalid add-on mirror");

  const hostname = url.hostname.replace(/^\[|\]$/g, "");
  const family = isIP(hostname);
  const addresses = family ? [{ address: hostname, family }] : await lookup(hostname, { all: true });
  const selected = addresses.find(entry => allowAddress(entry.address));
  if (!selected) throw new Error("Add-on mirror is outside the permitted network");
  signal.throwIfAborted();
  const request = url.protocol === "https:" ? httpsRequest : httpRequest;
  const response = await new Promise((resolve, reject) => {
    const outgoing = request(url, {
      signal,
      family: selected.family,
      autoSelectFamily: false,
      timeout: 8000,
      lookup: (_host, _options, callback) => callback(null, selected.address, selected.family),
      headers: { "User-Agent": "Sonic Robo Blast 2/v2.2.15", "Accept-Encoding": "identity" },
    }, resolve);
    outgoing.on("error", reject);
    outgoing.on("timeout", () => outgoing.destroy(new Error("The add-on mirror stopped responding")));
    outgoing.end();
  });

  if ([301, 302, 303, 307, 308].includes(response.statusCode) && redirects < 4 && response.headers.location) {
    const next = new URL(response.headers.location, url);
    response.destroy();
    return openMirror(next, allowAddress, signal, redirects + 1);
  }
  if (response.statusCode !== 200 || !["", "identity"].includes(response.headers["content-encoding"] || "")) {
    response.destroy();
    throw new Error("The add-on mirror could not serve this file");
  }
  return response;
}

export function createAddonDownloads({ origins, isPublicAddress, localOrigin }) {
  const sessions = new Map();
  const cached = new Map();
  let cacheSize = 0;
  let pendingSize = 0;

  function reserve(size) {
    if (!size || size > maxCachedFile || pendingSize + size > maxPendingSize) return null;
    const bytes = Buffer.allocUnsafe(size);
    pendingSize += size;
    return bytes;
  }

  function release(bytes) {
    if (bytes) pendingSize -= bytes.length;
  }

  function cacheKey(file) {
    return file.md5 + ":" + file.size;
  }

  async function verifyAndCache(file, bytes) {
    try {
      const key = cacheKey(file);
      if (cached.has(key)) return;
      const hash = createHash("md5");
      for (let offset = 0; offset < bytes.length; offset += 1024 * 1024) {
        hash.update(bytes.subarray(offset, offset + 1024 * 1024));
        await setImmediate();
      }
      if (hash.digest("hex") !== file.md5 || cached.has(key)) return;
      while (cacheSize + bytes.length > maxCacheSize) {
        const oldest = cached.keys().next().value;
        cacheSize -= cached.get(oldest).length;
        cached.delete(oldest);
      }
      cached.set(key, bytes);
      cacheSize += bytes.length;
    } finally {
      release(bytes);
    }
  }

  function open(origin, allowLoopback, sendHint) {
    const id = randomBytes(24).toString("base64url");
    const cancel = new AbortController();
    const files = new Map();
    const requested = new Set();
    const session = { origin, allowLoopback, signal: cancel.signal, files: new Map(), mirror: null };
    let nextFile = 0;
    let capture;
    sessions.set(id, session);

    function addPage(advertisement, first) {
      const addons = advertisedAddons(advertisement.files, advertisement.count);
      if (!addons) return;
      for (const addon of addons) {
        if (first + addon.index >= maxFiles) break;
        files.set(first + addon.index, addon);
        session.files.set(addon.md5, addon);
      }
      nextFile = first + advertisement.count;
      sendHint?.({
        addonKey: id,
        mirror: Boolean(session.mirror),
        cached: [...session.files.values()].filter(file => cached.has(cacheKey(file))).map(file => file.md5),
      });
    }

    function receive(datagram) {
      if (datagram[6] === packet.serverInfo && !requested.size && validGamePacket(datagram)) {
        const advertisement = serverAdvertisement(datagram);
        if (!advertisement) return;
        session.mirror = mirrorBase(advertisement.mirror);
        files.clear();
        session.files.clear();
        addPage(advertisement, 0);
      } else if (datagram[6] === packet.fileList && nextFile < maxFiles && validGamePacket(datagram)) {
        const page = listAdvertisement(datagram);
        if (page && page.first === nextFile) addPage(page, nextFile);
      } else if (datagram[6] === packet.fileFragment && requested.size) {
        const fragment = addonFragment(datagram);
        if (!fragment || !requested.has(fragment.index)) return;
        const file = files.get(fragment.index);
        if (!file || file.size !== fragment.size || cached.has(cacheKey(file))) return;
        if (!capture) {
          const bytes = reserve(fragment.size);
          if (!bytes) return;
          capture = { index: fragment.index, bytes, stride: fragment.stride,
            seen: new Uint8Array(Math.ceil(fragment.size / fragment.stride)), received: 0 };
        }
        if (capture.index !== fragment.index || capture.stride !== fragment.stride) return;
        const part = fragment.position / fragment.stride;
        if (capture.seen[part]) return;
        fragment.data.copy(capture.bytes, fragment.position);
        capture.seen[part] = 1;
        capture.received += fragment.data.length;
        if (capture.received === file.size) {
          void verifyAndCache(file, capture.bytes).catch(() => {});
          requested.delete(fragment.index);
          capture = null;
        }
      }
    }

    function send(datagram) {
      if (datagram[6] === packet.requestFile) {
        for (const index of datagram.subarray(packetHeader)) {
          if (index === 255) break;
          if (files.has(index)) requested.add(index);
        }
      } else if (datagram[6] === packet.clientJoin) {
        requested.clear();
        release(capture?.bytes);
        capture = null;
      }
    }

    function close() {
      sessions.delete(id);
      cancel.abort();
      release(capture?.bytes);
      capture = null;
    }
    return { receive, send, close };
  }

  function allowRequestOrigin(req, session) {
    return req.headers.origin === session.origin || (!req.headers.origin && session.origin === localOrigin);
  }

  function sendHeaders(res, size) {
    res.writeHead(200, {
      "Content-Type": "application/octet-stream", "Content-Length": size,
      "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff",
    });
  }

  async function handle(req, res) {
    const origin = req.headers.origin;
    res.setHeader("Vary", "Origin");
    if (origins.has(origin)) res.setHeader("Access-Control-Allow-Origin", origin);
    if (req.method === "OPTIONS") {
      if (!origins.has(origin)) return res.writeHead(403).end();
      return res.writeHead(204, {
        "Access-Control-Allow-Methods": "GET", "Access-Control-Allow-Headers": "Authorization",
        "Access-Control-Max-Age": "600",
      }).end();
    }
    if (req.method !== "GET") return res.writeHead(405).end();

    const digest = /^\/addons\/([0-9a-f]{32})$/.exec(req.url)?.[1];
    const id = /^Bearer ([A-Za-z0-9_-]{32})$/.exec(req.headers.authorization || "")?.[1];
    const session = sessions.get(id);
    if (!session || !allowRequestOrigin(req, session)) return res.writeHead(403).end();
    const file = session.files.get(digest);
    if (!file) return res.writeHead(404).end();
    if (session.busy) return res.writeHead(429).end();

    const key = cacheKey(file);
    const hit = cached.get(key);
    if (hit) {
      cached.delete(key);
      cached.set(key, hit);
      session.busy = true;
      res.once("close", () => { session.busy = false; });
      sendHeaders(res, hit.length);
      return res.end(hit);
    }
    if (!session.mirror) return res.writeHead(404).end();

    const mirror = new URL(encodeURIComponent(file.name), session.mirror);
    mirror.searchParams.set("md5", digest);
    const cancel = new AbortController();
    const signal = AbortSignal.any([cancel.signal, session.signal, AbortSignal.timeout(120_000)]);
    const onClose = () => { if (!res.writableFinished) cancel.abort(); };
    res.once("close", onClose);
    session.busy = true;
    let capture;
    try {
      const response = await openMirror(mirror, address => isPublicAddress(address) ||
        (session.allowLoopback && ["127.0.0.1", "::1"].includes(address)), signal);
      const length = response.headers["content-length"];
      if (length !== undefined && Number(length) !== file.size) {
        response.destroy();
        throw new Error("Unexpected add-on size");
      }
      capture = reserve(file.size);
      let count = 0;
      const limit = new Transform({
        transform(chunk, _encoding, callback) {
          if (count + chunk.length > file.size) return callback(new Error("Add-on is larger than advertised"));
          if (capture) chunk.copy(capture, count);
          count += chunk.length;
          callback(null, chunk);
        },
        flush(callback) {
          callback(count === file.size ? null : new Error("Add-on is shorter than advertised"));
        },
      });
      sendHeaders(res, file.size);
      await pipeline(response, limit, res, { signal });
      if (capture) {
        void verifyAndCache(file, capture).catch(() => {});
        capture = null;
      }
    } catch {
      if (res.headersSent) res.destroy();
      else res.writeHead(502).end();
    } finally {
      res.off("close", onClose);
      session.busy = false;
      release(capture);
    }
  }

  return { open, handle };
}
