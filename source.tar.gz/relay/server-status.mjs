import { createSocket } from "node:dgram";
import { isIP } from "node:net";
import { endpoint } from "../common/directory.mjs";
import {
  askFileList, askInfo, listAdvertisement, packet, packetHeader, publicPlayerInfo,
  publicServerInfo, serverAdvertisement, validGamePacket,
} from "./game-packets.mjs";

const maximumServers = 192;
const concurrentProbes = 16;
const maximumFilePages = 8;

function probe({ address, port }) {
  return new Promise(resolve => {
    const socket = createSocket(isIP(address) === 4 ? "udp4" : "udp6");
    const queryTime = Date.now() >>> 0;
    const snapshot = { files: [] };
    let started;
    let nextFile;
    let filesComplete = false;
    let settled = false;
    const deadline = setTimeout(finish, 1100);

    function finish() {
      if (settled) return;
      settled = true;
      clearTimeout(deadline);
      try { socket.close(); } catch { /* A failed socket might already be closed. */ }
      resolve(snapshot.info ? snapshot : null);
    }

    function requestMore() {
      socket.send(askFileList(nextFile), error => { if (error) finish(); });
    }

    socket.on("error", finish);
    socket.on("message", datagram => {
      if (!validGamePacket(datagram)) return;
      switch (datagram[6]) {
        case packet.serverInfo: {
          if (snapshot.info) break;
          const info = serverAdvertisement(datagram, queryTime);
          if (!info) break;
          snapshot.info = publicServerInfo(datagram);
          snapshot.ping = Math.round(performance.now() - started);
          nextFile = info.count;
          filesComplete = !info.more;
          if (info.more) requestMore();
          break;
        }
        case packet.playerInfo:
          snapshot.players = publicPlayerInfo(datagram);
          break;
        case packet.fileList: {
          const page = listAdvertisement(datagram);
          if (!page || page.first !== nextFile || filesComplete) break;
          snapshot.files.push(datagram.subarray(packetHeader).toString("base64"));
          nextFile += page.count;
          filesComplete = !page.more || snapshot.files.length >= maximumFilePages;
          if (!filesComplete) requestMore();
          break;
        }
      }
      if (snapshot.info && snapshot.players && filesComplete) finish();
    });
    socket.connect(port, address, error => {
      if (error || settled) return finish();
      started = performance.now();
      socket.send(askInfo(queryTime), error => { if (error) finish(); });
    });
  });
}

export async function readServerStatus(servers) {
  const targets = new Map(servers.map(server => [endpoint(server.address, server.port), server]));
  const pending = [...targets.entries()].slice(0, maximumServers).values();
  const status = Object.create(null);
  await Promise.all(Array.from({ length: Math.min(concurrentProbes, targets.size) }, async () => {
    for (const [target, server] of pending) {
      const snapshot = await probe(server);
      if (snapshot) status[target] = snapshot;
    }
  }));
  return status;
}
