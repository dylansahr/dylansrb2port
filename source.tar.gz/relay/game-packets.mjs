// Wire format shared with engine/src/netcode/protocol.h.
export const packet = {
  askInfo: 12, serverInfo: 13, playerInfo: 14, requestFile: 15, fileFragment: 24, clientJoin: 29,
  askFileList: 31, fileList: 32,
};
export const packetHeader = 8;
export const packetLimit = 1450;

const version = 202;
const packetVersion = 5;
const mirrorOffset = packetHeader + 150;
const fileListOffset = mirrorOffset + 256;
const addonCountOffset = packetHeader + 50;
const flagsOffset = packetHeader + 49;
const echoedTimeOffset = packetHeader + 51;
const playerSize = 36;
const playerSlots = 32;

function checksum(datagram) {
  let value = 0x1234567;
  for (let index = 4; index < datagram.length; index++) value += datagram[index] * (index - 3);
  return value >>> 0;
}

export function validGamePacket(datagram) {
  return datagram.length >= packetHeader && datagram.length <= packetLimit &&
    datagram[6] < 34 && datagram.readUInt32LE(0) === checksum(datagram);
}

export function askInfo(time) {
  const datagram = Buffer.alloc(packetHeader + 5);
  datagram[6] = packet.askInfo;
  datagram[8] = version;
  datagram.writeUInt32LE(time, 9);
  datagram.writeUInt32LE(checksum(datagram), 0);
  return datagram;
}

export function askFileList(first) {
  const datagram = Buffer.alloc(packetHeader + 4);
  datagram[6] = packet.askFileList;
  datagram.writeInt32LE(first, 8);
  datagram.writeUInt32LE(checksum(datagram), 0);
  return datagram;
}

export function serverAdvertisement(datagram, time) {
  if (datagram[6] !== packet.serverInfo ||
      datagram.length < fileListOffset || datagram.length > fileListOffset + 915 ||
      datagram[8] !== 255 || datagram[9] !== packetVersion || datagram[26] !== version ||
      datagram[27] !== 15 || !datagram.subarray(10, 15).equals(Buffer.from("SRB2\0")) ||
      (time !== undefined && datagram.readUInt32LE(echoedTimeOffset) !== time)) return null;

  const mirrorField = datagram.subarray(mirrorOffset, fileListOffset);
  const end = mirrorField.indexOf(0);
  return {
    mirror: end > 0 ? mirrorField.subarray(0, end).toString("utf8") : "",
    count: datagram[addonCountOffset],
    more: Boolean(datagram[flagsOffset] & 0x20),
    files: datagram.subarray(fileListOffset),
  };
}

export function listAdvertisement(datagram) {
  if (datagram[6] !== packet.fileList || datagram.length < 14 || datagram.length > 14 + 915) return null;
  const first = datagram.readInt32LE(8);
  const count = datagram[12];
  const more = Boolean(datagram[13]);
  if (first < 0 || (count === 0 && more)) return null;
  return { first, count, more, files: datagram.subarray(14) };
}

export function advertisedAddons(files, count) {
  const addons = [];
  let offset = 0;
  for (let index = 0; index < count; index++) {
    if (files.length - offset < 23) return null;
    const end = files.indexOf(0, offset + 6);
    if (end < 0 || end + 17 > files.length || end - offset - 6 >= 512) return null;
    if (!files[offset + 1]) {
      const name = files.subarray(offset + 6, end).toString("utf8").split(/[\\/:]/).at(-1);
      const size = files.readUInt32LE(offset + 2);
      const md5 = files.subarray(end + 1, end + 17).toString("hex");
      if (name && name !== "." && name !== ".." && !/[\x00-\x1f\x7f]/.test(name)) {
        addons.push({ index, name, size, md5 });
      }
    }
    offset = end + 17;
  }
  return addons;
}

export function addonFragment(datagram) {
  const header = packetHeader + 12;
  if (datagram.length <= header || datagram[6] !== packet.fileFragment) return null;
  const size = datagram.readUInt32LE(9);
  const position = datagram.readUInt32LE(14);
  const stride = datagram.readUInt16LE(18);
  const data = datagram.subarray(header);
  if (stride < 256 || position >= size || position % stride ||
      data.length !== Math.min(stride, size - position)) return null;
  return { index: datagram[8], size, position, stride, data };
}

export function publicServerInfo(datagram) {
  const info = Buffer.from(datagram.subarray(packetHeader));
  info.fill(0, mirrorOffset - packetHeader, fileListOffset - packetHeader);
  return info.toString("base64");
}

export function publicPlayerInfo(datagram) {
  if (datagram[6] !== packet.playerInfo || datagram.length !== packetHeader + playerSize * playerSlots) return null;
  const players = Buffer.from(datagram.subarray(packetHeader));
  for (let offset = 0; offset < players.length; offset += playerSize) {
    // Publish only the public name, slot, and spectator flag.
    players.fill(0, offset + 23, offset + 27);
    players.fill(0, offset + 28, offset + playerSize);
    if (players[offset] !== offset / playerSize) players.fill(0, offset + 1, offset + playerSize);
  }
  return players.toString("base64");
}
