import { createServer } from "node:http";
import { createSocket } from "node:dgram";
import { BlockList, isIP } from "node:net";
import { randomBytes, timingSafeEqual } from "node:crypto";
import { createReadStream } from "node:fs";
import { stat, access } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { WebSocket, WebSocketServer } from "ws";
import { endpoint, engineVersion, fetchDirectory, normalizeAddress } from "../common/directory.mjs";
import { gameProtocol, isSigningKey, verifyTicket } from "../common/relay-ticket.mjs";
import { packet, packetLimit, validGamePacket } from "./game-packets.mjs";
import { readServerStatus } from "./server-status.mjs";
import { createAddonDownloads } from "./addon-downloads.mjs";

const relayOnly = process.env.SRB2_RELAY_ONLY === "1";
const signingKey = process.env.SRB2_RELAY_SIGNING_KEY;
const host = relayOnly ? (process.env.SRB2_RELAY_BIND || "127.0.0.1") : "127.0.0.1";
const port = Number(process.env.SRB2_WEB_PORT || (relayOnly && process.env.PORT) || 5173);
const key = relayOnly ? null : (process.env.SRB2_RELAY_KEY || randomBytes(32).toString("base64url"));
if (!["127.0.0.1", "0.0.0.0"].includes(host) || !Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error("Invalid relay listen address or port.");
}
const localOrigin = `http://${host}:${port}`;
const origins = new Set((
  process.env.SRB2_RELAY_ORIGINS || ""
).split(",").map(origin => origin.trim()).filter(Boolean));
if (relayOnly) {
  if (!isSigningKey(signingKey) || origins.size === 0 || [...origins].some(origin => {
    const url = new URL(origin);
    return url.origin !== origin || url.protocol !== "https:";
  }) || process.env.SRB2_EXTRA_SERVER) {
    throw new Error("Public relay mode requires a signing key and HTTPS Site origins.");
  }
} else {
  if (!/^[\w-]{32,128}$/.test(key)) throw new Error("Invalid local relay key.");
  origins.add(localOrigin);
}
const clientFolder = new URL("../dist/client/", import.meta.url);
let worker;
if (!relayOnly) {
  await access(new URL("index.html", clientFolder));
  worker = (await import("../dist/server/index.js")).default;
}

const extra = process.env.SRB2_EXTRA_SERVER?.match(/^(?:\[([^\]]+)\]|([^:]+)):(\d{1,5})$/);
const extraAddress = extra && normalizeAddress(extra[1] || extra[2]);
const extraPort = extra && Number(extra[3]);
if (process.env.SRB2_EXTRA_SERVER && (!extraAddress || extraPort < 1 || extraPort > 65535)) {
  throw new Error("SRB2_EXTRA_SERVER must be a literal IP address and UDP port.");
}
const extraServer = extraAddress ? {
  address: extraAddress, port: extraPort, name: "Configured direct server", version: engineVersion,
} : null;

const blocked = new BlockList();
for (const [address, bits] of [
  ["0.0.0.0", 8], ["10.0.0.0", 8], ["100.64.0.0", 10], ["127.0.0.0", 8],
  ["169.254.0.0", 16], ["172.16.0.0", 12], ["192.0.0.0", 24], ["192.0.2.0", 24],
  ["192.168.0.0", 16], ["198.18.0.0", 15], ["198.51.100.0", 24], ["203.0.113.0", 24],
  ["224.0.0.0", 3],
]) blocked.addSubnet(address, bits, "ipv4");
for (const [address, bits] of [
  ["2001::", 23], ["2001:db8::", 32], ["2002::", 16], ["3fff::", 20],
]) blocked.addSubnet(address, bits, "ipv6");
const globalV6 = new BlockList();
globalV6.addSubnet("2000::", 3, "ipv6");

let servedDirectory;
let lookup;
let latestStatus;
let statusRefresh;

function isPublicAddress(address) {
  const family = isIP(address);
  if (!family) return false;
  const kind = family === 4 ? "ipv4" : "ipv6";
  return !blocked.check(address, kind) && (kind === "ipv4" || globalV6.check(address, kind));
}

async function getMasterDirectory() {
  if (!servedDirectory || Date.now() - Date.parse(servedDirectory.updatedAt) >= 20_000) {
    lookup ??= fetchDirectory().finally(() => { lookup = null; });
    servedDirectory = await lookup;
  }
  return servedDirectory;
}

async function allowedTarget(address, portNumber) {
  if (extraServer?.address === address && extraServer.port === portNumber) return true;
  if (!isPublicAddress(address)) return false;
  return (await getMasterDirectory()).servers.some(server =>
    server.address === address && server.port === portNumber && server.version === engineVersion
  );
}

async function directoryWithStatus() {
  if (latestStatus?.expires > Date.now()) return latestStatus.value;
  statusRefresh ??= (async () => {
    const directory = await getMasterDirectory().catch(error => {
      if (!extraServer) throw error;
      return { rooms: [], servers: [] };
    });
    const targets = directory.servers.filter(server =>
      server.version === engineVersion && isPublicAddress(server.address)
    );
    if (extraServer) targets.unshift(extraServer);
    const status = await readServerStatus(targets);
    const value = { ...directory, status };
    latestStatus = { value, expires: Date.now() + 10_000 };
    return value;
  })().finally(() => { statusRefresh = null; });
  return statusRefresh;
}

const assets = {
  async fetch(request) {
    const name = new URL(request.url).pathname.slice(1) || "index.html";
    if (!/^[a-z0-9][a-z0-9.-]*$/i.test(name)) return new Response(null, { status: 404 });
    const path = fileURLToPath(new URL(name, clientFolder));
    try {
      const { size } = await stat(path);
      const types = {
        html: "text/html; charset=utf-8",
        css: "text/css; charset=utf-8",
        mjs: "text/javascript; charset=utf-8",
        wasm: "application/wasm",
        gz: "application/gzip",
      };
      return new Response(request.method === "HEAD" ? null : Readable.toWeb(createReadStream(path)), {
        headers: { "Content-Type": types[name.split(".").at(-1)] || "text/plain; charset=utf-8", "Content-Length": size },
      });
    } catch {
      return new Response("Not found", { status: 404 });
    }
  },
};

const downloads = createAddonDownloads({ origins, isPublicAddress, localOrigin });
const server = createServer(async (req, res) => {
  if (req.url.startsWith("/addons/") && (relayOnly || req.headers.host === `${host}:${port}`)) {
    await downloads.handle(req, res);
    return;
  }
  if (relayOnly) {
    if (req.method === "GET" && req.url === "/healthz") {
      res.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" })
        .end(JSON.stringify({ protocol: gameProtocol }));
    } else if (req.method === "GET" && req.url === "/directory-status") {
      try {
        const { status } = await directoryWithStatus();
        const headers = {
          "Content-Type": "application/json", "Cache-Control": "no-store", Vary: "Origin",
        };
        if (origins.has(req.headers.origin)) headers["Access-Control-Allow-Origin"] = req.headers.origin;
        res.writeHead(200, headers)
          .end(JSON.stringify({ status }));
      } catch {
        res.writeHead(502).end();
      }
    } else {
      res.writeHead(404).end();
    }
    return;
  }
  if (req.headers.host !== `${host}:${port}`) {
    res.writeHead(421).end();
    return;
  }
  try {
    const request = new Request(new URL(req.url, localOrigin), { method: req.method });
    const localConfig = req.method === "GET" && new URL(request.url).pathname === "/api/local-relay";
    const response = localConfig
      ? Response.json({
        available: true, key, url: `ws://${host}:${port}/relay`, extraServer,
      }, { headers: { "Cache-Control": "no-store", "Cross-Origin-Resource-Policy": "same-origin" } })
      : new URL(request.url).pathname === "/api/servers"
      ? Response.json(await directoryWithStatus(), { headers: { "Cache-Control": "no-store" } })
      : await worker.fetch(request, { ASSETS: assets });
    res.writeHead(response.status, Object.fromEntries(response.headers));
    if (req.method === "HEAD" || !response.body) res.end();
    else await pipeline(response.body, res);
  } catch {
    if (res.headersSent) res.destroy();
    else res.writeHead(500).end("Local server error");
  }
});

const wss = new WebSocketServer({
  noServer: true,
  maxPayload: packetLimit,
  perMessageDeflate: false,
  handleProtocols: () => gameProtocol,
});
const expectedKey = key && Buffer.from(`key.${key}`);
const redeemedTickets = new Map();
const recentJoins = new Map();
const visitors = new Map();
const targets = new Map();
let pending = 0;

function updateConnections(map, id, change) {
  const count = (map.get(id) || 0) + change;
  if (count) map.set(id, count);
  else map.delete(id);
}

function consumeTicket(claims, target) {
  const now = Date.now();
  for (const [id, expires] of redeemedTickets) {
    if (expires <= now) redeemedTickets.delete(id);
  }
  for (const [id, entry] of recentJoins) {
    if (entry.expires <= now) recentJoins.delete(id);
  }
  if (redeemedTickets.has(claims.id) || redeemedTickets.size >= 1024 ||
      (visitors.get(claims.visitor) || 0) >= 3 || (targets.get(target) || 0) >= 6) return false;
  const attempts = recentJoins.get(claims.visitor) || { count: 0, expires: now + 60_000 };
  if (attempts.count >= 8) return false;
  attempts.count++;
  recentJoins.set(claims.visitor, attempts);
  redeemedTickets.set(claims.id, claims.expires);
  return true;
}

server.on("upgrade", async (request, socket, head) => {
  const close = status => socket.end(`HTTP/1.1 ${status}\r\nConnection: close\r\n\r\n`);
  const protocols = (request.headers["sec-websocket-protocol"] || "").split(/,\s*/);
  const origin = request.headers.origin;
  const credential = protocols[1] || "";
  if (!origins.has(origin) || protocols[0] !== gameProtocol) return close("403 Forbidden");
  if (wss.clients.size + pending >= 12) return close("503 Service Unavailable");
  const url = new URL(request.url, localOrigin);
  const address = normalizeAddress(url.searchParams.get("address"));
  const portNumber = Number(url.searchParams.get("port"));
  if (url.pathname !== "/relay" || !address || !Number.isInteger(portNumber) ||
      portNumber < 1 || portNumber > 65535) return close("400 Bad Request");

  const onSocketError = () => socket.destroy();
  socket.on("error", onSocketError);
  pending++;
  try {
    let claims;
    if (relayOnly) {
      if (!credential.startsWith("ticket.")) return close("403 Forbidden");
      claims = await verifyTicket(signingKey, credential.slice(7), { address, port: portNumber, origin });
      if (!claims) return close("403 Forbidden");
    } else {
      const suppliedKey = Buffer.from(credential);
      if (suppliedKey.length !== expectedKey.length || !timingSafeEqual(suppliedKey, expectedKey)) {
        return close("403 Forbidden");
      }
    }
    if (!await allowedTarget(address, portNumber)) return close("403 Forbidden");
    if (socket.destroyed) return;
    const target = endpoint(address, portNumber);
    if (claims && (claims.expires <= Date.now() || !consumeTicket(claims, target))) {
      return close("429 Too Many Requests");
    }
    socket.off("error", onSocketError);
    wss.handleUpgrade(request, socket, head, ws => {
      if (claims) {
        updateConnections(visitors, claims.visitor, 1);
        updateConnections(targets, target, 1);
        ws.once("close", () => {
          updateConnections(visitors, claims.visitor, -1);
          updateConnections(targets, target, -1);
        });
      }
      bridge(ws, address, portNumber, origin, url.searchParams.get("fast") === "1");
    });
  } catch {
    close("502 Bad Gateway");
  } finally {
    pending--;
  }
});

function bridge(ws, address, portNumber, origin, fast) {
  const udp = createSocket(isIP(address) === 4 ? "udp4" : "udp6");
  const addonSession = downloads.open(origin, extraServer?.address === address && extraServer.port === portNumber,
    fast ? hint => ws.send(JSON.stringify(hint)) : null);
  let ready = false;
  let activity = Date.now();
  let replenished = activity;
  let credit = 1024;
  let fragments = [];
  let fragmentBytes = 0;
  let batchTimer;

  function flushFragments() {
    clearTimeout(batchTimer);
    batchTimer = null;
    if (ws.readyState === WebSocket.OPEN && fragments.length) {
      if (fragments.length > 1 && fragmentBytes > packetLimit) {
        const frame = Buffer.allocUnsafe(fragmentBytes);
        let offset = 0;
        for (const datagram of fragments) {
          frame.writeUInt16LE(datagram.length, offset);
          offset += 2;
          datagram.copy(frame, offset);
          offset += datagram.length;
        }
        ws.send(frame, { binary: true });
      } else {
        for (const datagram of fragments) ws.send(datagram, { binary: true });
      }
    }
    fragments = [];
    fragmentBytes = 0;
  }

  udp.on("error", () => ws.close(1011, "UDP route unavailable"));
  udp.on("message", datagram => {
    if (datagram.length < 8 || datagram.length > packetLimit || ws.readyState !== WebSocket.OPEN) return;
    activity = Date.now();
    addonSession.receive(datagram);
    if (fast && datagram[6] === packet.fileFragment) {
      if (ws.bufferedAmount + fragmentBytes >= 1024 * 1024) return;
      fragments.push(datagram);
      fragmentBytes += datagram.length + 2;
      if (fragmentBytes >= 24 * 1024) flushFragments();
      else batchTimer ??= setTimeout(flushFragments, 4);
      return;
    }
    if (fragments.length) flushFragments();
    if (ws.bufferedAmount < 128 * 1024) ws.send(datagram, { binary: true });
  });
  ws.on("message", (datagram, binary) => {
    if (!ready || !binary || !validGamePacket(datagram)) return;
    const now = Date.now();
    credit = Math.min(1024, credit + (now - replenished) * 0.512);
    replenished = now;
    if (credit < 1) return;
    credit--;
    activity = now;
    addonSession.send(datagram);
    udp.send(datagram, error => {
      if (error && ws.readyState === WebSocket.OPEN) ws.close(1011, "UDP send failed");
    });
  });
  const timer = setInterval(() => {
    if (Date.now() - activity > 120_000) ws.close(1000, "Idle");
  }, 30_000);
  ws.on("error", () => ws.terminate());
  ws.once("close", () => {
    clearInterval(timer);
    clearTimeout(batchTimer);
    addonSession.close();
    try { udp.close(); } catch { /* Already closed. */ }
  });
  udp.connect(portNumber, address, error => {
    if (ws.readyState !== WebSocket.OPEN) return;
    if (error) return ws.close(1011, "UDP route unavailable");
    try { udp.setRecvBufferSize(1024 * 1024); } catch { /* Use the platform default. */ }
    ready = true;
    ws.send("ready");
  });
  console.info(`SRB2 relay connected to ${endpoint(address, portNumber)}`);
}

server.listen(port, host, () => {
  console.info(relayOnly ? `SRB2 relay listening on ${host}:${port}` : `Local URL: ${localOrigin}`);
});
