import { fetchDirectory } from "./directory.mjs";
import { gameDataPath } from "./game-data.mjs";
import { serveGameData } from "./game-download.mjs";
import { relayAvailable, relayConfig, relayHttpUrl, relayTicket } from "./public-relay.mjs";

let directory;
let fetchedAt = 0;

async function getDirectory() {
  if (!directory || Date.now() - fetchedAt >= 20_000) {
    directory = await fetchDirectory();
    fetchedAt = Date.now();
  }
  return directory;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method !== "GET" && request.method !== "HEAD") {
      return new Response("Method not allowed", { status: 405, headers: { Allow: "GET, HEAD" } });
    }
    const pagesOrigin = env.SRB2_PAGES_ORIGIN;
    const pagesRequestOrigin = request.headers.get("Origin") === pagesOrigin ? pagesOrigin : undefined;
    function forGameBrowser(response) {
      if (pagesOrigin) response.headers.append("Vary", "Origin");
      if (pagesRequestOrigin) response.headers.set("Access-Control-Allow-Origin", pagesRequestOrigin);
      return response;
    }
    if (url.pathname.startsWith(gameDataPath)) {
      return forGameBrowser(await serveGameData(url.pathname.slice(gameDataPath.length), request.method === "HEAD"));
    }
    if (url.pathname === "/api/servers") {
      try {
        const listing = await getDirectory();
        const relay = relayConfig(env);
        const statusUrl = relay ? relayHttpUrl(relay, "/directory-status").href : undefined;
        return forGameBrowser(Response.json({ ...listing, statusUrl }, { headers: { "Cache-Control": "no-store" } }));
      } catch (error) {
        console.warn("SRB2 Master Server request failed", error.message);
        return forGameBrowser(Response.json({ error: "Could not reach the SRB2 Master Server." }, {
          status: 502, headers: { "Cache-Control": "no-store" },
        }));
      }
    }
    if (url.pathname === "/api/local-relay") {
      return Response.json({ available: false }, { headers: { "Cache-Control": "no-store" } });
    }
    if (url.pathname === "/api/relay") {
      const available = await relayAvailable(relayConfig(env));
      return forGameBrowser(Response.json({ available }, { headers: { "Cache-Control": "no-store" } }));
    }
    if (request.method === "GET" && url.pathname === "/api/relay/ticket") {
      return forGameBrowser(await relayTicket(request, relayConfig(env), getDirectory, pagesRequestOrigin));
    }
    return env.ASSETS.fetch(request);
  },
};
