import { engineVersion, normalizeAddress } from "./directory.mjs";
import { gameProtocol, isSigningKey, issueTicket } from "./relay-ticket.mjs";

export function relayConfig(env) {
  if (!isSigningKey(env.SRB2_RELAY_SIGNING_KEY) || typeof env.SRB2_RELAY_URL !== "string") return null;
  try {
    const url = new URL(env.SRB2_RELAY_URL);
    if (url.protocol !== "wss:" || url.pathname !== "/relay" ||
        url.username || url.password || url.search || url.hash) return null;
    return { url, secret: env.SRB2_RELAY_SIGNING_KEY };
  } catch {
    return null;
  }
}

let relayStatus;

export function relayHttpUrl(config, path) {
  const url = new URL(config.url.href);
  url.protocol = "https:";
  url.pathname = path;
  return url;
}

export async function relayAvailable(config) {
  if (!config) return false;
  if (relayStatus?.url === config.url.href && relayStatus.expires > Date.now()) return relayStatus.available;
  let available = false;
  try {
    const response = await fetch(relayHttpUrl(config, "/healthz"), {
      redirect: "manual", signal: AbortSignal.timeout(5000),
    });
    available = response.ok && (await response.json()).protocol === gameProtocol;
  } catch {
    // The relay can recover independently of the Site.
  }
  relayStatus = { url: config.url.href, available, expires: Date.now() + (available ? 12_000 : 2000) };
  return available;
}

function ticketResponse(body, status = 200) {
  return Response.json(body, { status, headers: { "Cache-Control": "no-store" } });
}

export async function relayTicket(request, config, getDirectory, pagesOrigin) {
  if (!config) return ticketResponse({ error: "The shared multiplayer relay is offline." }, 503);
  const url = new URL(request.url);
  const origin = request.headers.get("Origin");
  const site = request.headers.get("Sec-Fetch-Site");
  if (!pagesOrigin && ((site && site !== "same-origin") || (origin && origin !== url.origin))) {
    return ticketResponse({ error: "Open the SRB2 Site to join." }, 403);
  }

  const address = normalizeAddress(url.searchParams.get("address"));
  const port = Number(url.searchParams.get("port"));
  if (!address || !Number.isInteger(port) || port < 1 || port > 65535) {
    return ticketResponse({ error: "This server address is invalid." }, 400);
  }
  let directory;
  try {
    directory = await getDirectory();
  } catch {
    return ticketResponse({ error: "Couldn’t check the Master Server. Try again shortly." }, 502);
  }
  if (!directory.servers.some(server =>
    server.address === address && server.port === port && server.version === engineVersion
  )) {
    return ticketResponse({ error: "This server is no longer listed for SRB2 2.2.15." }, 404);
  }
  if (!await relayAvailable(config)) {
    return ticketResponse({ starting: true, error: "The multiplayer relay is starting." }, 503);
  }
  const visitor = normalizeAddress(request.headers.get("CF-Connecting-IP")) || "guest";
  const ticket = await issueTicket(config.secret, { address, port, origin: pagesOrigin ?? url.origin, visitor });
  return ticketResponse({ url: config.url.href, ticket });
}
