import { gameData, releaseSize, releaseZip } from "./game-data.mjs";

let location;
let resolvedUntil = 0;

async function resolveRelease() {
  if (Date.now() < resolvedUntil) return location;
  const response = await fetch(releaseZip, {
    redirect: "manual",
    signal: AbortSignal.timeout(8000),
  });
  const header = response.headers.get("Location");
  if (response.status !== 302 || !header) throw new Error("Official release is unavailable");
  const url = new URL(header);
  if (url.protocol !== "https:" || url.hostname !== "release-assets.githubusercontent.com" ||
      url.username || url.password || url.port) throw new Error("Unexpected release host");
  location = url.href;
  resolvedUntil = Date.now() + 60_000;
  return location;
}

async function requestEntry({ start, end }) {
  const headers = { Range: `bytes=${start}-${end}`, "Accept-Encoding": "identity" };
  const response = await fetch(await resolveRelease(), {
    headers,
    redirect: "manual",
    signal: AbortSignal.timeout(120_000),
  });
  if (response.status !== 206 ||
      response.headers.get("Content-Range") !== `bytes ${start}-${end}/${releaseSize}` ||
      !response.body) {
    resolvedUntil = 0;
    await response.body?.cancel();
    throw new Error(`Unexpected release response (${response.status})`);
  }
  return response.body;
}

export async function serveGameData(name, headOnly) {
  if (!Object.hasOwn(gameData, name)) return new Response(null, { status: 404 });
  const entry = gameData[name];
  try {
    const body = headOnly ? null : await requestEntry(entry);
    return new Response(body, {
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Length": String(entry.end - entry.start + 1),
        "Cache-Control": "public, max-age=31536000, immutable",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (error) {
    console.warn("Game data download failed", error.message);
    return new Response("The official SRB2 download is temporarily unavailable.", {
      status: 502, headers: { "Cache-Control": "no-store" },
    });
  }
}
