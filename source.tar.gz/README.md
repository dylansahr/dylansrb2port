# Dylan’s SRB2 Web Port

Browser build of Dylan’s Optimized SRB2 V1.6.0 for the SRB2 2.2.15 engine. Rendering is capped at 60 FPS. The OpenGL renderer requires WebGL 2. On first play, the app downloads and verifies the game, soundtrack, and 3D models, then saves them in the browser. Progress and settings are stored in the browser when IndexedDB is available. [Official SRB2 2.2.15 release](https://github.com/STJr/SRB2/releases/tag/SRB2_release_2.2.15)

Open **Multiplayer → Server browser** in SRB2 to browse the live Master Server directory. The in-game list shows the map, player count, relay-to-server ping, players, and add-ons for servers that respond. Choose **Join server** on a compatible 2.2.15 listing. The site connects through its WebSocket-to-UDP relay automatically, and the game uses Adaptive net buffering. Hosting a native game uses the desktop or dedicated build. Toggle **Stretch** to fill the available game area.

## Build and run locally

Use Emscripten SDK 4.0.23, CMake, Ninja, Node.js 24, npm, and tar. Activate the SDK in the shell before building.

```text
emcmake cmake -S engine -B engine/build -G Ninja -DCMAKE_BUILD_TYPE=MinSizeRel
cmake --build engine/build
npm ci
npm run build
npm start
```

Open the Local URL printed by `npm start` to launch the game. The local page automatically uses the loopback relay. Set `SRB2_WEB_PORT` to choose another web port. Set `SRB2_EXTRA_SERVER` to include a direct server you operate, for example `127.0.0.1:15029`. The relay generates a local access key on launch unless `SRB2_RELAY_KEY` is set.

## GitHub Pages

After building, run `npm run build:pages -- <Pages checkout> <HTTPS relay origin>`. Set GitHub Pages to publish with GitHub Actions. The included workflow downloads and verifies the six game data packs from the official release and deploys them alongside the browser build. Add the Pages origin to the relay’s allowed origins.

The former hosting manifest is archived at `.hosting/hosting.json`. The legacy Sites deployment tools expect it at `.openai/hosting.json`.

## Public multiplayer relay

The relay needs a Node.js 24 host that can send and receive UDP traffic. Install dependencies with `npm ci --omit=dev` and start the relay with `npm start`. It serves the Master Server list at `/api/servers`, live status at `/directory-status`, join tickets at `/api/relay/ticket`, netplay WebSockets at `/relay`, add-on downloads at `/addons/<md5>`, and availability at `/healthz`. Terminate HTTPS at a reverse proxy that preserves the `Origin`, `Authorization`, and `Sec-WebSocket-Protocol` headers and appends the visitor’s IP to `X-Forwarded-For`.

The game uses the server’s HTTP mirror and a shared relay cache when available, then requests missing files over the game connection. The relay checks the destination and accepts only add-ons advertised by the active server. The in-memory cache holds up to 96 MiB of verified files, with a 32 MiB limit per cached file. Verified downloads also stay in the player's browser storage when storage is available.

| Variable | Value |
| --- | --- |
| `SRB2_RELAY_ONLY` | `1` |
| `SRB2_RELAY_ORIGINS` | Comma-separated list of permitted HTTPS game origins with no trailing slashes |
| `SRB2_RELAY_PUBLIC_ORIGIN` | Public HTTPS address with no trailing slash. Defaults to `RENDER_EXTERNAL_URL` on Render. |
| `SRB2_RELAY_SIGNING_KEY` | A secret 32-byte random key encoded as 43 base64url characters |
| `SRB2_RELAY_BIND` | Defaults to `127.0.0.1`. Set to `0.0.0.0` when the container host terminates TLS. |
| `SRB2_WEB_PORT` | Optional port override. Otherwise uses the hosting provider’s `PORT` or 5173. |

The relay issues short-lived, single-use tickets and checks the visitor’s origin and the server’s listing before opening a connection. A Sites deployment can also issue tickets using its existing `SRB2_RELAY_URL` and shared `SRB2_RELAY_SIGNING_KEY`.

## Source and licenses

The engine is available under [GPL v2](engine/LICENSE). Its build scripts and corresponding source are included in the Site’s **Source code** download. The included engine source retains its copyright headers and third-party notices in [LICENSE-3RD-PARTY.txt](engine/LICENSE-3RD-PARTY.txt). Emscripten SDK 4.0.23 supplies SDL2 2.32.8, SDL2_mixer 2.8.0, libogg 1.3.5, libvorbis 1.3.7, zlib 1.3.1, and libpng 1.6.39 through its ports.
