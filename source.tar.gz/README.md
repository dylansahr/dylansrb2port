# SRB2 Optimized Web V1.5

Browser build of Dylan’s Optimized SRB2, based on the Linux V5.150 source and the SRB2 2.2.15 engine. Rendering is capped at 60 FPS. The OpenGL renderer requires WebGL 2. On first play, the app downloads and verifies the game, soundtrack, and 3D models, then saves them in the browser. Progress and settings are stored in the browser when IndexedDB is available. [Official SRB2 2.2.15 release](https://github.com/STJr/SRB2/releases/tag/SRB2_release_2.2.15)

Open **Multiplayer → Server browser** in SRB2 to browse the live Master Server directory. The in-game list shows the map, player count, relay-to-server ping, players, and add-ons for servers that respond. Choose **Join server** on a compatible 2.2.15 listing. The site connects through its WebSocket-to-UDP relay automatically, and the game uses Adaptive net buffering. Hosting a native game uses the desktop or dedicated build.

## Build and run locally

Use Emscripten SDK 4.0.23, CMake, Ninja, Node.js 24, npm, and tar. Activate the SDK in the shell before building.

```text
emcmake cmake -S engine -B engine/build -G Ninja -DCMAKE_BUILD_TYPE=MinSizeRel
cmake --build engine/build
npm ci
npm run build
npm start
```

Open the Local URL printed by `npm start` to launch the game. The local page automatically uses the loopback relay. Set `SRB2_WEB_PORT` to choose another web port. Set `SRB2_EXTRA_SERVER` to include a direct server you operate, for example `127.0.0.1:15029`. The relay generates a local access key on launch unless `SRB2_RELAY_KEY` is set.

## Public multiplayer relay

The relay needs a Node.js 24 host that can send and receive UDP traffic. Install dependencies with `npm ci --omit=dev` and start the relay with `npm start`. It serves netplay WebSockets at `/relay`, directory metadata at `/directory-status`, add-on downloads at `/addons/<md5>`, and availability at `/healthz`. Terminate HTTPS at a reverse proxy that preserves the `Origin`, `Authorization`, and `Sec-WebSocket-Protocol` headers.

The game uses the server’s HTTP mirror and a shared relay cache when available, then requests missing files over the game connection. The relay checks the destination and accepts only add-ons advertised by the active server. The in-memory cache holds up to 96 MiB of verified files, with a 32 MiB limit per cached file. Verified downloads also stay in the player's browser storage when storage is available.

| Variable | Value |
| --- | --- |
| `SRB2_RELAY_ONLY` | `1` |
| `SRB2_RELAY_ORIGINS` | Comma-separated list of permitted HTTPS Site origins with no trailing slashes |
| `SRB2_RELAY_SIGNING_KEY` | A secret 32-byte random key encoded as 43 base64url characters |
| `SRB2_RELAY_BIND` | Defaults to `127.0.0.1`. Set to `0.0.0.0` when the container host terminates TLS. |
| `SRB2_WEB_PORT` | Optional port override. Otherwise uses the hosting provider’s `PORT` or 5173. |

In Sites, add `SRB2_RELAY_URL` with the public WebSocket URL ending in `/relay` and add the matching `SRB2_RELAY_SIGNING_KEY` as a secret. Visitors can then join directly from the server list. The Site issues short-lived, single-use tickets and the relay checks the visitor’s origin and the server’s listing before opening a connection.

## Source and licenses

The engine is available under [GPL v2](engine/LICENSE). Its build scripts and corresponding source are included in the Site’s **Source code** download. The included engine source retains its copyright headers and third-party notices in [LICENSE-3RD-PARTY.txt](engine/LICENSE-3RD-PARTY.txt). Emscripten SDK 4.0.23 supplies SDL2 2.32.8, SDL2_mixer 2.8.0, libogg 1.3.5, libvorbis 1.3.7, zlib 1.3.1, and libpng 1.6.39 through its ports.
