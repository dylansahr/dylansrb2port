add_subdirectory(blua)
add_subdirectory(netcode)
add_subdirectory(hardware)

target_sources(SRB2SDL2 PRIVATE
  apng.c
  sdl/dosstr.c
  sdl/endtxt.c
  sdl/hwsym_sdl.c
  sdl/i_main.c
  sdl/i_net.c
  sdl/i_system.c
  sdl/i_video.c
  sdl/mixer_sound.c
  sdl/ogl_sdl.c
)
set_target_properties(SRB2SDL2 PROPERTIES OUTPUT_NAME "srb2" SUFFIX ".mjs")
target_compile_features(SRB2SDL2 PRIVATE c_std_11)
target_include_directories(SRB2SDL2 PRIVATE "${PROJECT_BINARY_DIR}")
target_compile_definitions(SRB2SDL2 PRIVATE
  CMAKECONFIG HAVE_SDL SDL_MAIN_HANDLED HAVE_ZLIB HAVE_PNG
  HAVE_MIXER SOUND=SOUND_MIXER UNIXCOMMON NOEXECINFO NOTERMIOS NOMUMBLE
  HWRENDER STATIC_OPENGL GL_GLEXT_PROTOTYPES
)

set(web_ports
  "-sUSE_SDL=2"
  "--use-port=sdl2_mixer:formats=ogg"
  "-sUSE_LIBPNG=1"
  "-sUSE_ZLIB=1"
)
target_compile_options(SRB2SDL2 PRIVATE ${web_ports} -fwrapv)
target_link_options(SRB2SDL2 PRIVATE
  ${web_ports}
  -lidbfs.js
  "-sASYNCIFY=1"
  "-sASYNCIFY_STACK_SIZE=131072"
  "-sSTACK_SIZE=4194304"
  "-sALLOW_MEMORY_GROWTH=1"
  "-sMODULARIZE=1"
  "-sEXPORT_ES6=1"
  "-sENVIRONMENT=web"
  "-sMAX_WEBGL_VERSION=2"
  "-sLEGACY_GL_EMULATION=1"
  "-sGL_UNSAFE_OPTS=0"
  # The GL emulation setup in Emscripten 4.0.23 installs these hooks even when
  # the program has no direct calls to them.
  "-sDEFAULT_LIBRARY_FUNCS_TO_INCLUDE=glTexEnvf,glTexEnvfv,glGetTexEnviv,glGetTexEnvfv"
  "-sEXPORTED_RUNTIME_METHODS=FS,IDBFS,callMain"
  "-sINVOKE_RUN=0"
)
