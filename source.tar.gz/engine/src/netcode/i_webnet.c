/* Client transport for the V5.150 Emscripten build. GPL-2.0-or-later. */
#include "i_net.h"
#include "i_tcp.h"
#include "d_net.h"
#include <emscripten.h>

enum { RELAY_NODE = 1 };
static char peer[64];

EM_JS(int, RelayAttach, (const char *host, const char *port), {
	return Module['srb2Transport'].attach(UTF8ToString(host), Number(UTF8ToString(port))) ? 1 : 0;
});

EM_JS(void, RelayDetach, (void), {
	Module['srb2Transport'].detach();
});

EM_JS(int, RelayIsOpen, (void), {
	return Module['srb2Transport'].isOpen() ? 1 : 0;
});

boolean I_WebRelayDisconnected(void)
{
	return peer[0] && !RelayIsOpen();
}

EM_JS(int, RelayReceive, (char *data, int capacity), {
	const packet = Module['srb2Transport'].receive();
	if (!packet || packet.length > capacity) return 0;
	HEAPU8.set(packet, data);
	return packet.length;
});

EM_JS(void, RelaySend, (const char *data, int length), {
	Module['srb2Transport'].send(HEAPU8.subarray(data, data + length));
});

static boolean GetPacket(void)
{
	const int size = RelayReceive(doomcom->data, sizeof doomcom->data);
	doomcom->remotenode = size > 0 ? RELAY_NODE : -1;
	doomcom->datalength = (INT16)size;
	return size > 0;
}

static void SendPacket(void)
{
	if (doomcom->remotenode == RELAY_NODE && doomcom->datalength > 0
		&& doomcom->datalength <= MAXPACKETLENGTH)
		RelaySend(doomcom->data, doomcom->datalength);
}

static void FreeNode(INT32 node)
{
	if (node == RELAY_NODE && peer[0])
	{
		peer[0] = '\0';
		RelayDetach();
	}
}

static void CloseSocket(void)
{
	FreeNode(RELAY_NODE);
}

static const char *GetAddress(INT32 node)
{
	return node == RELAY_NODE && peer[0] ? peer : NULL;
}

static SINT8 MakeNode(const char *host, const char *port)
{
	if (peer[0] || !host || !port || !RelayAttach(host, port))
		return -1;

	if (strchr(host, ':'))
		snprintf(peer, sizeof peer, "[%s]:%s", host, port);
	else
		snprintf(peer, sizeof peer, "%s:%s", host, port);
	return RELAY_NODE;
}

static boolean OpenSocket(void)
{
	I_NetGet = GetPacket;
	I_NetSend = SendPacket;
	I_NetFreeNodenum = FreeNode;
	I_NetCloseSocket = CloseSocket;
	I_NetMakeNodewPort = MakeNode;
	I_GetNodeAddress = GetAddress;
	doomcom->extratics = 1;
	packetheaderlength = 28;
	return true;
}

boolean I_InitTcpDriver(void)
{
	I_NetOpenSocket = OpenSocket;
	return true;
}

boolean I_InitTcpNetwork(void)
{
	I_InitTcpDriver();
	return false;
}

void I_ShutdownTcpDriver(void) { CloseSocket(); }
void I_ConfigureUPnP(boolean enable) { (void)enable; }
boolean I_RetryUPnP(void) { return false; }
i_upnp_status_t I_GetUPnPStatus(void) { return I_UPNP_UNAVAILABLE; }
void I_ValidateUPnPMapping(void) {}
const char *I_GetPortMappingMethod(void) { return "none"; }
boolean I_RequestWindowsFirewallRule(const char *port) { (void)port; return false; }
