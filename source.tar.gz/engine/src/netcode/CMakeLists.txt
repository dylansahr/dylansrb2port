target_sources(SRB2SDL2 PRIVATE
	d_clisrv.c
	server_connection.c
	client_connection.c
	server_browser.c
	tic_command.c
	net_command.c
	gamestate.c
	commands.c
	d_net.c
	d_netcmd.c
	d_netfil.c
	http-mserv.c
	mserv.c
)

if(EMSCRIPTEN)
	target_sources(SRB2SDL2 PRIVATE i_webnet.c)
else()
	target_sources(SRB2SDL2 PRIVATE i_tcp.c)
endif()
