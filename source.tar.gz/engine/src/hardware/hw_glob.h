// SONIC ROBO BLAST 2
//-----------------------------------------------------------------------------
// Copyright (C) 1998-2000 by DooM Legacy Team.
// Copyright (C) 1999-2024 by Sonic Team Junior.
//
// This program is free software distributed under the
// terms of the GNU General Public License, version 2.
// See the 'LICENSE' file for more details.
//-----------------------------------------------------------------------------
/// \file hw_glob.h
/// \brief globals (shared data & code) for hw_ modules

#ifndef _HWR_GLOB_H_
#define _HWR_GLOB_H_

#include "hw_defs.h"
#include "hw_main.h"
#include "../m_misc.h"
#include "../p_setup.h"

// the original aspect ratio of Doom graphics isn't square
#define ORIGINAL_ASPECT (320.0f/200.0f)

// Uncomment this to enable the OpenGL loading screen
//#define HWR_LOADING_SCREEN

// -----------
// structures
// -----------

// a vertex of a Doom 'plane' polygon
typedef struct
{
	float x;
	float y;
	float z;
} polyvertex_t;

#ifdef _MSC_VER
#pragma warning(disable :  4200)
#endif

// a convex 'plane' polygon, clockwise order
typedef struct
{
	INT32 numpts;
	polyvertex_t pts[0];
} poly_t;

#ifdef _MSC_VER
#pragma warning(default :  4200)
#endif

// holds extra info for 3D render, for each subsector in subsectors[]
typedef struct
{
	poly_t *planepoly;  // the generated convex polygon
	poly_t *boundedpoly; // raised/island surfaces, bounded by real sector geometry
	sector_t *floorbackground, *ceilingbackground;
	struct hwr_plane_region_s *plane_regions;
} extrasubsector_t;

/* Real neighboring sectors covering the part trimmed from a BSP leaf. These
 * own persistent plane geometry because translucent floors are drawn later. */
typedef struct hwr_plane_region_s
{
	extrasubsector_t xsub;
	sector_t *sector;
	struct hwr_plane_region_s *next;
} hwr_plane_region_t;

// needed for sprite rendering
// equivalent of the software renderer's vissprites
typedef struct gl_vissprite_s
{
	float x1, x2;
	float z1, z2;
	float gz, gzt;

	float tz;
	float tracertz; // for MF2_LINKDRAW sprites, this contains tracer's tz for use in sorting

	float scale;
	float shadowheight, shadowscale;

	float spritexscale, spriteyscale;
	float spritexoffset, spriteyoffset;

	UINT32 renderflags;
	UINT8 rotateflags;

	boolean flip, vflip;
	boolean precip; // Tails 08-25-2002
	boolean bbox;
	boolean rotated;
	/* Cached by HWR_SortVisSprites. Comparing thousands of translucent sprites
	 * should not repeatedly inspect the same mobj/frame flags. */
	boolean sortblended;
	boolean sorttracerblended;
	/* The translucent-FOF relation scans delayed wall geometry. Cache it for
	 * the frame so linkdraw/deferred decisions do not repeat the same scan. */
	boolean fofrelationcached;
	UINT8 fofrelation;
	UINT8 translucency;       //alpha level 0-255

	angle_t angle; // for splats

	//Hurdler: 25/04/2000: now support colormap in hardware mode
	UINT8 *colormap;
	INT32 dispoffset; // copy of mobj->dispoffset, affects ordering but not drawing

	patch_t *gpatch;
	mobj_t *mobj; // NOTE: This is a precipmobj_t if precip is true !!! Watch out.
} gl_vissprite_t;

// --------
// hw_bsp.c
// --------
extern extrasubsector_t *extrasubsectors;
extern size_t addsubsector;

void HWR_InitPolyPool(void);
void HWR_FreePolyPool(void);

void HWR_FreeExtraSubsectors(void);

// --------
// hw_cache.c
// --------
RGBA_t *HWR_GetTexturePalette(void);

void HWR_InitMapTextures(void);
void HWR_LoadMapTextures(size_t pnumtextures);
boolean HWR_MapTexturesAreCurrent(size_t pnumtextures);
void HWR_FreeMapTextures(void);

patch_t *HWR_GetCachedGLPatchPwad(UINT16 wad, UINT16 lump);
patch_t *HWR_GetCachedGLPatch(lumpnum_t lumpnum);

void HWR_GetPatch(patch_t *patch);
void HWR_GetMappedPatch(patch_t *patch, const UINT8 *colormap);
void HWR_GetSpritePatch(patch_t *patch);
void HWR_GetMappedSpritePatch(patch_t *patch, const UINT8 *colormap);
void HWR_GetFadeMask(lumpnum_t fademasklumpnum);

GLMapTexture_t *HWR_GetTexture(INT32 tex, boolean chromakeyed);
void HWR_GetLevelFlat(levelflat_t *levelflat, boolean chromakeyed);
void HWR_GetRawFlat(lumpnum_t flatlumpnum);

void HWR_FreeTexture(patch_t *patch);
void HWR_FreeTextureData(patch_t *patch);
void HWR_FreeTextureColormaps(patch_t *patch);
void HWR_ClearAllTextures(void);
void HWR_ClearLevelTextures(void);
void HWR_FreeColormapCache(void);
void HWR_UnlockCachedPatch(GLPatch_t *gpatch);

void HWR_SetPalette(RGBA_t *palette);
void HWR_SetMapPalette(void);
void HWR_EnsurePaletteLookup(void);
UINT32 HWR_CreateLightTable(UINT8 *lighttable, RGBA_t *hw_lighttable);
void HWR_UpdateLightTable(UINT32 id, UINT8 *lighttable, RGBA_t *hw_lighttable);
UINT32 HWR_GetLightTableID(extracolormap_t *colormap);
void HWR_ClearLightTables(void);


// --------
// hw_draw.c
// --------
extern INT32 patchformat;
extern INT32 textureformat;

// --------
// hw_shaders.c
// --------
boolean HWR_InitShaders(void);
void HWR_CompileShaders(void);

int HWR_GetShaderFromTarget(int shader_target);

void HWR_LoadAllCustomShaders(void);
void HWR_LoadCustomShadersFromFile(UINT16 wadnum, boolean PK3);
const char *HWR_GetShaderName(INT32 shader);

extern customshaderxlat_t shaderxlat[];

#endif //_HW_GLOB_
