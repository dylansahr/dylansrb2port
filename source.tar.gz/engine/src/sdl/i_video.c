
// Emacs style mode select   -*- C++ -*-
// SONIC ROBO BLAST 2
//-----------------------------------------------------------------------------
//
// Copyright (C) 1993-1996 by id Software, Inc.
// Portions Copyright (C) 1998-2000 by DooM Legacy Team.
// Copyright (C) 2014-2023 by Sonic Team Junior.
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//-----------------------------------------------------------------------------
/// \file
/// \brief SRB2 graphics stuff for SDL

#include <stdlib.h>

#include <signal.h>

#ifdef _MSC_VER
#pragma warning(disable : 4214 4244)
#endif

#ifdef HAVE_SDL
#define _MATH_DEFINES_DEFINED
#include "SDL.h"

#ifdef _MSC_VER
#include <windows.h>
#pragma warning(default : 4214 4244)
#endif

#ifdef HAVE_TTF
#include "i_ttf.h"
#endif

#ifdef HAVE_IMAGE
#include "SDL_image.h"
#elif !defined(__EMSCRIPTEN__) && (defined(__unix__) || (!defined(__APPLE__) && defined(UNIXCOMMON)))
#define LOAD_XPM //I want XPM!
#include "IMG_xpm.c" //Alam: I don't want to add SDL_Image.dll/so
#define HAVE_IMAGE //I have SDL_Image, sortof
#endif

#ifdef HAVE_IMAGE
#include "SDL_icon.xpm"
#endif

#include "../doomdef.h"

#ifdef _WIN32
#include <windows.h>
#include "SDL_system.h"
#include "SDL_syswm.h"
#endif

#include "../doomstat.h"
#include "../i_system.h"
#include "../i_time.h"
#include "../v_video.h"
#include "../m_argv.h"
#include "../m_menu.h"
#include "../m_misc.h"
#include "../d_main.h"
#include "../s_sound.h"
#include "../i_joy.h"
#include "../st_stuff.h"
#include "../hu_stuff.h"
#include "../g_game.h"
#include "../g_input.h"
#include "../netcode/d_clisrv.h"
#include "../i_video.h"
#include "../console.h"
#include "../command.h"
#include "../r_main.h"
#include "../r_fps.h"
#include "../screen.h"
#include "../lua_script.h"
#include "../lua_libs.h"
#include "../lua_hook.h"
#include "sdlmain.h"
#ifdef __EMSCRIPTEN__
#include "../g_input.h"
#include <emscripten.h>
#endif
#ifdef HWRENDER
#include "../hardware/hw_main.h"
#include "../hardware/hw_drv.h"
#ifdef __EMSCRIPTEN__
#include "../hardware/r_opengl/r_opengl.h"
#endif
// For dynamic referencing of HW rendering functions
#include "hwsym_sdl.h"
#include "ogl_sdl.h"
#endif

// maximum number of windowed modes (see windowedModes[][])

/**	\brief
*/
static INT32 numVidModes = -1;

/**	\brief
*/
static char vidModeName[33][32]; // allow 33 different modes

rendermode_t rendermode = render_soft;
rendermode_t chosenrendermode = render_none; // set by command line arguments

static void VidWaitChanged(void);
static void WindowedStyleChanged(void);
static void VID_UpdateRefreshRate(boolean report);
static UINT32 refresh_rate;

static CV_PossibleValue_t vsync_cons_t[] = {
	{0, "Off"},
	{1, "On"},
	{0, NULL}
};

// synchronize page flipping with screen refresh
#ifdef __EMSCRIPTEN__
consvar_t cv_vidwait = CVAR_INIT ("vid_wait", "Off", CV_HIDEN, vsync_cons_t, NULL);
#else
consvar_t cv_vidwait = CVAR_INIT ("vid_wait", "On", CV_SAVE | CV_CALL, vsync_cons_t, VidWaitChanged);
#endif
static CV_PossibleValue_t windowedstyle_cons_t[] = {
	{0, "Normal"},
	{1, "Borderless Desktop"},
	{0, NULL}
};
/* Compatibility-only cvar for configs written by V5.52-V5.66. Borderless
 * desktop duplicated the fullscreen presentation without being fullscreen,
 * so new configs no longer save it and the menu no longer exposes it. */
static consvar_t cv_windowedstyle = CVAR_INIT ("windowedstyle", "Normal", CV_CALL | CV_NOSHOWHELP,
	windowedstyle_cons_t, WindowedStyleChanged);
static consvar_t cv_stretch = CVAR_INIT ("stretch", "Off", CV_SAVE|CV_NOSHOWHELP, CV_OnOff, NULL);
static consvar_t cv_alwaysgrabmouse = CVAR_INIT ("alwaysgrabmouse", "Off", CV_SAVE, CV_OnOff, NULL);

#if !defined(__ANDROID__) && !defined(__EMSCRIPTEN__)
static void WindowSizeChanged(void);

enum
{
	WINDOW_SIZE_CURRENT,
	WINDOW_SIZE_MATCH
};

static CV_PossibleValue_t windowsize_cons_t[] =
{
	{WINDOW_SIZE_CURRENT, "Keep Current"},
	{WINDOW_SIZE_MATCH, "Match Resolution"},
	{2, "320x200"},
	{3, "320x240"},
	{4, "640x360"},
	{5, "640x400"},
	{6, "640x480"},
	{7, "800x600"},
	{8, "960x600"},
	{9, "1024x768"},
	{10, "1280x720"},
	{11, "1280x800"},
	{12, "1600x900"},
	{13, "1920x1080"},
	{14, "1920x1200"},
	{15, "2560x1440"},
	{16, "3840x2160"},
	{0, NULL}
};

consvar_t cv_windowsize = CVAR_INIT ("windowsize", "Keep Current",
	CV_SAVE | CV_CALL | CV_NOINIT, windowsize_cons_t, WindowSizeChanged);
#endif

UINT8 graphics_started = 0; // Is used in console.c and screen.c

// To disable fullscreen at startup; is set in VID_PrepareModeList
boolean allow_fullscreen = false;
static SDL_bool disable_fullscreen = SDL_FALSE;
#define USE_FULLSCREEN (disable_fullscreen||!allow_fullscreen)?0:cv_fullscreen.value
static SDL_bool disable_mouse = SDL_FALSE;
#define USE_MOUSEINPUT (!disable_mouse && cv_usemouse.value && havefocus)
#define MOUSE_MENU false //(!disable_mouse && cv_usemouse.value && menuactive && !USE_FULLSCREEN)
#define MOUSEBUTTONS_MAX MOUSEBUTTONS

// first entry in the modelist which is not bigger than MAXVIDWIDTHxMAXVIDHEIGHT
static      INT32          firstEntry = 0;

// Total mouse motion X/Y offsets
static      INT32        mousemovex = 0, mousemovey = 0;

// SDL vars
static      SDL_Surface *vidSurface = NULL;
static      SDL_Surface *bufSurface = NULL;
static      SDL_Surface *icoSurface = NULL;
static      size_t        vid_buffer_capacity = 0;
static      SDL_Color    localPalette[256];
#if 0
static      SDL_Rect   **modeList = NULL;
static       Uint8       BitsPerPixel = 16;
#endif
Uint16      realwidth = BASEVIDWIDTH;
Uint16      realheight = BASEVIDHEIGHT;
static       SDL_bool    mousegrabok = SDL_TRUE;
static       SDL_bool    wrapmouseok = SDL_FALSE;
#define HalfWarpMouse(x,y) if (wrapmouseok) SDL_WarpMouseInWindow(window, (Uint16)(x/2),(Uint16)(y/2))
static       SDL_bool    videoblitok = SDL_FALSE;
static       SDL_bool    exposevideo = SDL_FALSE;
static       SDL_bool    usesdl2soft = SDL_FALSE;
static       SDL_bool    window_needs_first_present = SDL_FALSE;
#ifdef HWRENDER
static       SDL_bool    software_gl_presenter = SDL_FALSE;
#endif

// SDL2 vars
SDL_Window   *window;
SDL_Renderer *renderer;
static SDL_Texture  *texture;
static SDL_Texture  *software_color_texture;
static SDL_Texture  *last_software_texture;
static SDL_Rect src_rect;
static SDL_bool      havefocus = SDL_TRUE;
static const char *fallback_resolution_name = "Fallback";

#ifdef _WIN32
#define SRB2_SIZEMOVE_TIMER_ID 0x53524232u
static boolean windows_sizemove_active, windows_move_dispatching, windows_move_ticking;
static precise_t windows_sizemove_started, windows_sizemove_finished;
static HWND windows_sizemove_window, windows_game_window;
static WNDPROC windows_original_proc;
static UINT windows_move_message;
static WPARAM windows_move_wparam;
static LPARAM windows_move_lparam;
static void (*windows_move_frame)(boolean);
static POINT resize_cursor;
static boolean resize_cursor_valid;

static void CALLBACK Impl_WindowMoveTimer(HWND hwnd, UINT message, UINT_PTR id, DWORD time)
{
	(void)message;
	(void)id;
	(void)time;
	if (hwnd != windows_sizemove_window || !windows_sizemove_active || windows_move_ticking)
		return;

	windows_move_ticking = true;
	if (windows_move_dispatching)
		windows_move_frame(true);
	else if (netgame || serverrunning)
	{
		I_UpdateTime(cv_timescale.value);
		NetKeepAlive();
	}
	windows_move_ticking = false;
}

static LRESULT CALLBACK Impl_GameWindowProc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam)
{
	if (windows_move_frame && !windows_move_dispatching && !windows_sizemove_active
		&& ((message == WM_NCLBUTTONDOWN && wparam == HTCAPTION)
			|| (message == WM_SYSCOMMAND && (wparam & 0xfff0) == SC_MOVE)))
	{
		windows_move_message = message;
		windows_move_wparam = wparam;
		windows_move_lparam = lparam;
		return 0;
	}

	if (message == WM_ENTERSIZEMOVE)
	{
		windows_sizemove_active = true;
		windows_sizemove_started = I_GetPreciseTime();
		windows_sizemove_finished = 0;
		windows_sizemove_window = hwnd;
		SetTimer(hwnd, SRB2_SIZEMOVE_TIMER_ID, windows_move_dispatching ? 16 : 100, Impl_WindowMoveTimer);
		if (windows_move_dispatching)
			memset(gamekeydown, 0, NUMKEYS);
	}
	else if (message == WM_EXITSIZEMOVE || message == WM_NCDESTROY)
	{
		if (windows_sizemove_window)
			KillTimer(windows_sizemove_window, SRB2_SIZEMOVE_TIMER_ID);
		windows_sizemove_finished = I_GetPreciseTime();
		windows_sizemove_active = false;
		windows_sizemove_window = NULL;
	}

	const WNDPROC original = windows_original_proc;
	if (message == WM_NCDESTROY)
	{
		windows_game_window = NULL;
		windows_original_proc = NULL;
		windows_move_message = 0;
	}
	return CallWindowProcW(original, hwnd, message, wparam, lparam);
}

static void Impl_SubclassGameWindow(void)
{
	SDL_SysWMinfo info;
	SDL_VERSION(&info.version);
	if (SDL_GetWindowWMInfo(window, &info) && info.subsystem == SDL_SYSWM_WINDOWS)
	{
		HWND hwnd = info.info.win.window;
		WNDPROC original = (WNDPROC)SetWindowLongPtrW(hwnd, GWLP_WNDPROC, (LONG_PTR)Impl_GameWindowProc);
		if (original)
		{
			windows_original_proc = original;
			windows_game_window = hwnd;
		}
	}
}

void I_RunPendingWindowMove(void (*frame)(boolean))
{
	windows_move_frame = frame;
	if (!windows_move_message || !windows_game_window)
		return;

	const UINT message = windows_move_message;
	windows_move_message = 0;
	if (message == WM_NCLBUTTONDOWN && !(GetAsyncKeyState(VK_LBUTTON) & 0x8000))
		return;

	windows_move_dispatching = true;
	CallWindowProcW(windows_original_proc, windows_game_window, message, windows_move_wparam, windows_move_lparam);
	windows_move_dispatching = false;
}
boolean I_WindowManagerBlockedDuring(precise_t started, precise_t finished)
{
	precise_t blocked_finished;

	if (!windows_sizemove_started)
		return false;
	blocked_finished = windows_sizemove_active
		? I_GetPreciseTime() : windows_sizemove_finished;
	return windows_sizemove_started <= finished && blocked_finished >= started;
}
#else
boolean I_WindowManagerBlockedDuring(precise_t started, precise_t finished)
{
	(void)started;
	(void)finished;
	return false;
}
#endif

// windowed video modes from which to choose from.
static const INT32 windowedModes[][2] =
{
	{2560,1440}, // 1.77
	{1920,1200}, // 1.60,6.00
	{1920,1080}, // 1.66
	{1680,1050}, // 1.60,5.25
	{1600,1200}, // 1.33
	{1600,1000}, // 1.60,5.00
	{1600, 900}, // 1.66
	{1536, 864}, // 1.66,4.80
	{1366, 768}, // 1.66
	{1440, 900}, // 1.60,4.50
	{1280,1024}, // 1.33?
	{1280, 960}, // 1.33,4.00
	{1280, 800}, // 1.60,4.00
	{1280, 720}, // 1.66
	{1152, 864}, // 1.33,3.60
	{1024, 768}, // 1.33,3.20
	{ 960, 600}, // 1.60,3.00
	{ 800, 600}, // 1.33,2.50
	{ 640, 480}, // 1.33,2.00
	{ 640, 400}, // 1.60,2.00
	{ 320, 240}, // 1.33,1.00
	{ 320, 200}, // 1.60,1.00
	{3840,2160},
};
#define MAXWINMODES ((INT32)(sizeof windowedModes / sizeof *windowedModes))

static void Impl_VideoSetupSDLBuffer(void);
static void Impl_VideoSetupBuffer(void);
static void Impl_DestroySoftwareContext(void);
static SDL_bool Impl_CreateWindow(SDL_bool fullscreen);
//static void Impl_SetWindowName(const char *title);
static void Impl_SetWindowIcon(void);

static void Impl_ApplyWindowedStyle(INT32 width, INT32 height, SDL_bool reposition)
{
	const int display = SDL_GetWindowDisplayIndex(window);

	SDL_SetWindowBordered(window, SDL_TRUE);
#ifndef __ANDROID__
	SDL_Rect workarea;
	if (SDL_GetDisplayUsableBounds(display, &workarea) == 0)
	{
		int top = 0, left = 0, bottom = 0, right = 0;
		SDL_GetWindowBordersSize(window, &top, &left, &bottom, &right);
		const int maxwidth = max(BASEVIDWIDTH, workarea.w - left - right);
		const int maxheight = max(BASEVIDHEIGHT, workarea.h - top - bottom);
		if (width > maxwidth || height > maxheight)
		{
			if ((INT64)width * maxheight >= (INT64)height * maxwidth)
			{
				height = max(BASEVIDHEIGHT, (INT32)(((INT64)height * maxwidth + width / 2) / width));
				width = maxwidth;
			}
			else
			{
				width = max(BASEVIDWIDTH, (INT32)(((INT64)width * maxheight + height / 2) / height));
				height = maxheight;
			}
		}
	}
#endif
	SDL_SetWindowSize(window, width, height);
	if (reposition)
	{
		SDL_SetWindowPosition(window,
			SDL_WINDOWPOS_CENTERED_DISPLAY(display),
			SDL_WINDOWPOS_CENTERED_DISPLAY(display));
	}
#ifdef _WIN32

	resize_cursor_valid = menuactive && M_MenuMouseActive() && GetCursorPos(&resize_cursor);
#endif
}

#if !defined(__ANDROID__) && !defined(__EMSCRIPTEN__)
static void Impl_ApplyPreferredWindowSize(INT32 width, INT32 height, SDL_bool reposition)
{
	int presetwidth, presetheight;
	if (cv_windowsize.value > WINDOW_SIZE_MATCH
		&& sscanf(cv_windowsize.string, "%dx%d", &presetwidth, &presetheight) == 2)
	{
		width = presetwidth;
		height = presetheight;
	}
	if (SDL_GetWindowFlags(window) & SDL_WINDOW_MAXIMIZED)
		SDL_RestoreWindow(window);
	Impl_ApplyWindowedStyle(width, height, reposition);
}

static void WindowSizeChanged(void)
{

	if (!window || !graphics_started || con_startup || (USE_FULLSCREEN)
		|| cv_windowsize.value == WINDOW_SIZE_CURRENT)
		return;

	if (SDL_GetWindowFlags(window) & SDL_WINDOW_FULLSCREEN)
		return;
	Impl_ApplyPreferredWindowSize(vid.width, vid.height, SDL_TRUE);
}

boolean VID_GetFixedOutputSize(INT32 *width, INT32 *height)
{
	if (!window || (cv_windowsize.value == WINDOW_SIZE_MATCH
		&& !(SDL_GetWindowFlags(window) & SDL_WINDOW_FULLSCREEN)))
		return false;

	SDL_GetWindowSize(window, width, height);
	return *width > 0 && *height > 0;
}
#endif

static void Impl_FitGameSize(INT32 renderwidth, INT32 renderheight, INT32 *width, INT32 *height)
{
	const INT64 outputarea = (INT64)*width * renderheight;
	const INT64 renderarea = (INT64)*height * renderwidth;
	const INT64 difference = outputarea - renderarea;

	const INT32 rounding = max(renderwidth, renderheight) / 2;

	if (difference > rounding)
		*width = max(1, (INT32)((renderarea + renderheight / 2) / renderheight));
	else if (difference < -rounding)
		*height = max(1, (INT32)((outputarea + renderwidth / 2) / renderwidth));
}

#if !defined(__ANDROID__) && !defined(__EMSCRIPTEN__)
boolean VID_ModeHasFitBars(INT32 outputwidth, INT32 outputheight, INT32 renderwidth, INT32 renderheight)
{
	INT32 width = outputwidth, height = outputheight;
	Impl_FitGameSize(renderwidth, renderheight, &width, &height);
	return width != outputwidth || height != outputheight;
}
#endif

void I_GetGameViewport(INT32 outputwidth, INT32 outputheight, SDL_Rect *viewport)
{
	*viewport = (SDL_Rect){0, 0, outputwidth, outputheight};
	if (outputwidth <= 0 || outputheight <= 0 || !vid.width || !vid.height)
		return;

#if !defined(__ANDROID__)
	if (cv_fullscreenscale.value)
		return;
#endif

	Impl_FitGameSize(vid.width, vid.height, &viewport->w, &viewport->h);
	viewport->x = (outputwidth - viewport->w) / 2;
	viewport->y = (outputheight - viewport->h) / 2;
}

static void SDLSetMode(INT32 width, INT32 height, SDL_bool fullscreen, SDL_bool reposition)
{
#ifdef __ANDROID__
	static SDL_bool wasfullscreen = SDL_FALSE;
#else
	static SDL_Window *sized_window;
#endif
	Uint32 rmask;
	Uint32 gmask;
	Uint32 bmask;
	Uint32 amask;
	int bpp = 16;
	int sw_texture_format = SDL_PIXELFORMAT_ABGR8888;

	realwidth = vid.width;
	realheight = vid.height;

#ifdef __ANDROID__
	if (window)
	{
		if (fullscreen)
		{
			wasfullscreen = SDL_TRUE;
			SDL_SetWindowFullscreen(window, SDL_WINDOW_FULLSCREEN_DESKTOP);
		}
		else // windowed mode
		{
			if (wasfullscreen)
			{
				wasfullscreen = SDL_FALSE;
				SDL_SetWindowFullscreen(window, 0);
			}
			Impl_ApplyWindowedStyle(width, height, reposition);
		}
	}
	else
	{
		Impl_CreateWindow(fullscreen);
		wasfullscreen = fullscreen;
		if (fullscreen)
		{
			SDL_SetWindowFullscreen(window, SDL_WINDOW_FULLSCREEN_DESKTOP);
		}
		else
			Impl_ApplyWindowedStyle(width, height, reposition);
	}
#else
	if (!window && !Impl_CreateWindow(fullscreen))
		I_Error("Cannot create the game window: %s\n", SDL_GetError());
	const SDL_bool wasfullscreen = (SDL_GetWindowFlags(window) & SDL_WINDOW_FULLSCREEN)
		? SDL_TRUE : SDL_FALSE;
	if (fullscreen != wasfullscreen)
		SDL_SetWindowFullscreen(window, fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
#ifndef __EMSCRIPTEN__
	if (graphics_started && !fullscreen
		&& (sized_window != window || cv_windowsize.value == WINDOW_SIZE_MATCH
			|| (wasfullscreen && cv_windowsize.value != WINDOW_SIZE_CURRENT)))
	{
		Impl_ApplyPreferredWindowSize(width, height, reposition);
		sized_window = window;
	}
#else
	if (graphics_started && sized_window != window && !fullscreen)
	{
		Impl_ApplyWindowedStyle(width, height, reposition);
		sized_window = window;
	}
#endif
#endif

#ifdef HWRENDER
	if (rendermode == render_opengl)
	{
		if (!OglSdlSurface(vid.width, vid.height))
		{
			int drawablewidth, drawableheight;
			INT32 bestarea = 0;
			INT32 mode = VID_GetModeForSize(BASEVIDWIDTH, BASEVIDHEIGHT);
			SDL_GL_GetDrawableSize(window, &drawablewidth, &drawableheight);
			for (INT32 i = 0; i < MAXWINMODES; i++)
			{
				const INT32 w = windowedModes[i][0], h = windowedModes[i][1];
				if (w <= drawablewidth && h <= drawableheight && w*h > bestarea)
				{
					mode = i;
					bestarea = w*h;
				}
			}
			vid.modenum = mode;
			src_rect.w = realwidth = vid.width = windowedModes[mode][0];
			src_rect.h = realheight = vid.height = windowedModes[mode][1];
			if (!OglSdlSurface(vid.width, vid.height))
				I_Error("Cannot initialize an OpenGL render surface for the current display.");
			CONS_Alert(CONS_WARNING,
				"OpenGL could not render %dx%d on this display. Using %dx%d.\n",
				width, height, vid.width, vid.height);
		}
	}
#endif

	if (rendermode == render_soft)
	{
#ifndef __ANDROID__
		SDL_SetWindowMinimumSize(window, BASEVIDWIDTH, BASEVIDHEIGHT);
#endif
#ifdef HWRENDER
		if (software_gl_presenter)
			OglSdlReleaseRenderTarget();
#endif
#ifdef __ANDROID__
		if (renderer)
			SDL_RenderSetLogicalSize(renderer, width, height);
#endif
		// Set up Texture
		realwidth = width;
		realheight = height;
		if (texture != NULL)
		{
			SDL_DestroyTexture(texture);
			texture = NULL;
		}
		if (software_color_texture)
			SDL_DestroyTexture(software_color_texture);
		software_color_texture = last_software_texture = NULL;

		if (!usesdl2soft)
		{
			sw_texture_format = SDL_PIXELFORMAT_RGB565;
		}
		else
		{
			bpp = 32;
			sw_texture_format = SDL_PIXELFORMAT_RGBA8888;
		}

		if (renderer)
		{
			texture = SDL_CreateTexture(renderer, sw_texture_format, SDL_TEXTUREACCESS_STREAMING, width, height);
			if (texture == NULL)
				I_Error("Failed to create the software screen texture: %s\n", SDL_GetError());
		}

		// Set up SW surface
		if (vidSurface != NULL)
		{
			SDL_FreeSurface(vidSurface);
		}
		SDL_PixelFormatEnumToMasks(sw_texture_format, &bpp, &rmask, &gmask, &bmask, &amask);
		vidSurface = SDL_CreateRGBSurface(0, width, height, bpp, rmask, gmask, bmask, amask);
		if (vidSurface == NULL)
			I_Error("Failed to create the software screen surface: %s\n", SDL_GetError());
	}
}

static void VidWaitChanged(void)
{
#ifdef HWRENDER
	if (software_gl_presenter && sdlglcontext != NULL
	&& SDL_GL_GetCurrentContext() == sdlglcontext)
	{
		OglSdlSetVSync(cv_vidwait.value, true);
	}
	else
#endif
	if (renderer && rendermode == render_soft)
	{
#if SDL_VERSION_ATLEAST(2, 0, 18)
		SDL_RenderSetVSync(renderer, cv_vidwait.value ? 1 : 0);
#endif
	}
#ifdef HWRENDER
	else if (rendermode == render_opengl && sdlglcontext != NULL && SDL_GL_GetCurrentContext() == sdlglcontext)
	{
		OglSdlSetVSync(cv_vidwait.value, true);
	}
#endif
}

static void WindowedStyleChanged(void)
{
	/* Accept the retired value from an older config, but always normalize it
	 * to the only supported windowed presentation. */
	if (cv_windowedstyle.value)
		CV_StealthSetValue(&cv_windowedstyle, 0);

#ifdef __ANDROID__
	if (!window || USE_FULLSCREEN)
		return;

	Impl_ApplyWindowedStyle(vid.width, vid.height, SDL_TRUE);
#endif
#ifdef HWRENDER
	if (sdlglcontext != NULL && SDL_GL_GetCurrentContext() == sdlglcontext)
		OglSdlSetVSync(cv_vidwait.value, true);
#endif
}

static INT32 Impl_SDL_Scancode_To_Keycode(SDL_Scancode code)
{
	if (code >= SDL_SCANCODE_A && code <= SDL_SCANCODE_Z)
	{
		// get lowercase ASCII
		return code - SDL_SCANCODE_A + 'a';
	}
	if (code >= SDL_SCANCODE_1 && code <= SDL_SCANCODE_9)
	{
		return code - SDL_SCANCODE_1 + '1';
	}
	else if (code == SDL_SCANCODE_0)
	{
		return '0';
	}
	if (code >= SDL_SCANCODE_F1 && code <= SDL_SCANCODE_F10)
	{
		return KEY_F1 + (code - SDL_SCANCODE_F1);
	}
	switch (code)
	{
		// F11 and F12 are separated from the rest of the function keys
		case SDL_SCANCODE_F11: return KEY_F11;
		case SDL_SCANCODE_F12: return KEY_F12;

		case SDL_SCANCODE_KP_0: return KEY_KEYPAD0;
		case SDL_SCANCODE_KP_1: return KEY_KEYPAD1;
		case SDL_SCANCODE_KP_2: return KEY_KEYPAD2;
		case SDL_SCANCODE_KP_3: return KEY_KEYPAD3;
		case SDL_SCANCODE_KP_4: return KEY_KEYPAD4;
		case SDL_SCANCODE_KP_5: return KEY_KEYPAD5;
		case SDL_SCANCODE_KP_6: return KEY_KEYPAD6;
		case SDL_SCANCODE_KP_7: return KEY_KEYPAD7;
		case SDL_SCANCODE_KP_8: return KEY_KEYPAD8;
		case SDL_SCANCODE_KP_9: return KEY_KEYPAD9;

		case SDL_SCANCODE_RETURN:         return KEY_ENTER;
		case SDL_SCANCODE_ESCAPE:         return KEY_ESCAPE;
		case SDL_SCANCODE_BACKSPACE:      return KEY_BACKSPACE;
		case SDL_SCANCODE_TAB:            return KEY_TAB;
		case SDL_SCANCODE_SPACE:          return KEY_SPACE;
		case SDL_SCANCODE_MINUS:          return KEY_MINUS;
		case SDL_SCANCODE_EQUALS:         return KEY_EQUALS;
		case SDL_SCANCODE_LEFTBRACKET:    return '[';
		case SDL_SCANCODE_RIGHTBRACKET:   return ']';
		case SDL_SCANCODE_BACKSLASH:      return '\\';
		case SDL_SCANCODE_NONUSHASH:      return '#';
		case SDL_SCANCODE_SEMICOLON:      return ';';
		case SDL_SCANCODE_APOSTROPHE:     return '\'';
		case SDL_SCANCODE_GRAVE:          return '`';
		case SDL_SCANCODE_COMMA:          return ',';
		case SDL_SCANCODE_PERIOD:         return '.';
		case SDL_SCANCODE_SLASH:          return '/';
		case SDL_SCANCODE_CAPSLOCK:       return KEY_CAPSLOCK;
		case SDL_SCANCODE_PRINTSCREEN:    return 0; // undefined?
		case SDL_SCANCODE_SCROLLLOCK:     return KEY_SCROLLLOCK;
		case SDL_SCANCODE_PAUSE:          return KEY_PAUSE;
		case SDL_SCANCODE_INSERT:         return KEY_INS;
		case SDL_SCANCODE_HOME:           return KEY_HOME;
		case SDL_SCANCODE_PAGEUP:         return KEY_PGUP;
		case SDL_SCANCODE_DELETE:         return KEY_DEL;
		case SDL_SCANCODE_END:            return KEY_END;
		case SDL_SCANCODE_PAGEDOWN:       return KEY_PGDN;
		case SDL_SCANCODE_RIGHT:          return KEY_RIGHTARROW;
		case SDL_SCANCODE_LEFT:           return KEY_LEFTARROW;
		case SDL_SCANCODE_DOWN:           return KEY_DOWNARROW;
		case SDL_SCANCODE_UP:             return KEY_UPARROW;
		case SDL_SCANCODE_NUMLOCKCLEAR:   return KEY_NUMLOCK;
		case SDL_SCANCODE_KP_DIVIDE:      return KEY_KPADSLASH;
		case SDL_SCANCODE_KP_MULTIPLY:    return '*'; // undefined?
		case SDL_SCANCODE_KP_MINUS:       return KEY_MINUSPAD;
		case SDL_SCANCODE_KP_PLUS:        return KEY_PLUSPAD;
		case SDL_SCANCODE_KP_ENTER:       return KEY_ENTER;
		case SDL_SCANCODE_KP_PERIOD:      return KEY_KPADDEL;
		case SDL_SCANCODE_NONUSBACKSLASH: return '\\';

		case SDL_SCANCODE_LSHIFT: return KEY_LSHIFT;
		case SDL_SCANCODE_RSHIFT: return KEY_RSHIFT;
		case SDL_SCANCODE_LCTRL:  return KEY_LCTRL;
		case SDL_SCANCODE_RCTRL:  return KEY_RCTRL;
		case SDL_SCANCODE_LALT:   return KEY_LALT;
		case SDL_SCANCODE_RALT:   return KEY_RALT;
		case SDL_SCANCODE_LGUI:   return KEY_LEFTWIN;
		case SDL_SCANCODE_RGUI:   return KEY_RIGHTWIN;
		default:                  break;
	}

	return 0;
}

static boolean ShouldIgnoreMouse(void)
{
	if (chat_on || con_destlines)
		return true;
	if (M_MenuMouseActive())
		return false;
	if (cv_alwaysgrabmouse.value)
		return false;
	if (menuactive)
		return !M_MouseNeeded();
	if (paused || con_destlines || chat_on)
		return true;
	if (gamestate != GS_LEVEL && gamestate != GS_INTERMISSION &&
			gamestate != GS_CONTINUING && gamestate != GS_CUTSCENE)
		return true;
	return false;
}

static boolean ShouldGrabMouse(void)
{
	// Text entry releases the pointer even with Always Grab Mouse enabled.
	if (chat_on || con_destlines)
		return false;
	if (M_MenuMouseActive())
		return false;
	if (cv_alwaysgrabmouse.value)
		return true;
	if (ShouldIgnoreMouse())
		return false;
	if (!mousegrabbedbylua)
		return false;
	return true;
}

static void SDLdoGrabMouse(void)
{
	SDL_ShowCursor(SDL_DISABLE);
	SDL_SetWindowGrab(window, SDL_TRUE);
	if (SDL_SetRelativeMouseMode(SDL_TRUE) == 0) // already warps mouse if successful
		wrapmouseok = SDL_TRUE; // TODO: is wrapmouseok or HalfWarpMouse needed anymore?
}

/* Windows can leave SDL's relative-mouse flag set while the OS cursor is no
 * longer captured after repeated Alt-Tab cycles. Toggle the mode on a genuine
 * focus return so SDL rebuilds the platform grab instead of accepting the
 * stale "already enabled" state. */
static void SDLreacquireMouse(void)
{
	SDL_SetRelativeMouseMode(SDL_FALSE);
	SDL_SetWindowGrab(window, SDL_FALSE);
	SDLdoGrabMouse();
}

static void SDLdoUngrabMouse(void)
{
	mousemovex = mousemovey = 0;
	SDL_SetWindowGrab(window, SDL_FALSE);
	wrapmouseok = SDL_FALSE;
	SDL_SetRelativeMouseMode(SDL_FALSE);
	SDL_ShowCursor(!chat_on && !con_destlines && SDL_GetKeyboardFocus() == window
		&& SDL_GetMouseFocus() == window && M_MenuMouseActive()
		&& !M_MenuMouseVisible() ? SDL_DISABLE : SDL_ENABLE);
}

void SDLforceUngrabMouse(void)
{
	if (SDL_WasInit(SDL_INIT_VIDEO)==SDL_INIT_VIDEO && window != NULL)
		SDLdoUngrabMouse();
}

void I_UpdateMouseGrab(void)
{
	if (SDL_WasInit(SDL_INIT_VIDEO) == SDL_INIT_VIDEO && window != NULL)
	{
		if (SDL_GetKeyboardFocus() == window && USE_MOUSEINPUT && ShouldGrabMouse())
			SDLdoGrabMouse();
		else
			SDLdoUngrabMouse();
	}
}

void I_SetMouseGrab(boolean grab)
{
	if (grab && !chat_on && !con_destlines)
		SDLdoGrabMouse();
	else
		SDLdoUngrabMouse();
}

static void VID_Command_NumModes_f (void)
{
	CONS_Printf(M_GetText("%d video mode(s) available(s)\n"), VID_NumModes());
}

// SDL2 doesn't have SDL_GetVideoSurface or a lot of the SDL_Surface flags that SDL 1.2 had
static void SurfaceInfo(const SDL_Surface *infoSurface, const char *SurfaceText)
{
	INT32 vfBPP;

	if (!infoSurface)
		return;

	if (!SurfaceText)
		SurfaceText = M_GetText("Unknown Surface");

	vfBPP = infoSurface->format?infoSurface->format->BitsPerPixel:0;

	CONS_Printf("\x82" "%s\n", SurfaceText);
	CONS_Printf(M_GetText(" %ix%i at %i bit color\n"), infoSurface->w, infoSurface->h, vfBPP);

	if (infoSurface->flags&SDL_PREALLOC)
		CONS_Printf("%s", M_GetText(" Uses preallocated memory\n"));
	else
		CONS_Printf("%s", M_GetText(" Stored in system memory\n"));
	if (infoSurface->flags&SDL_RLEACCEL)
		CONS_Printf("%s", M_GetText(" Colorkey RLE acceleration blit\n"));
}

static void VID_Command_Info_f (void)
{
#if 0
	SDL2STUB();
#else
#if 0
	const SDL_VideoInfo *videoInfo;
	videoInfo = SDL_GetVideoInfo(); //Alam: Double-Check
	if (videoInfo)
	{
		CONS_Printf("%s", M_GetText("Video Interface Capabilities:\n"));
		if (videoInfo->hw_available)
			CONS_Printf("%s", M_GetText(" Hardware surfaces\n"));
		if (videoInfo->wm_available)
			CONS_Printf("%s", M_GetText(" Window manager\n"));
		//UnusedBits1  :6
		//UnusedBits2  :1
		if (videoInfo->blit_hw)
			CONS_Printf("%s", M_GetText(" Accelerated blits HW-2-HW\n"));
		if (videoInfo->blit_hw_CC)
			CONS_Printf("%s", M_GetText(" Accelerated blits HW-2-HW with Colorkey\n"));
		if (videoInfo->wm_available)
			CONS_Printf("%s", M_GetText(" Accelerated blits HW-2-HW with Alpha\n"));
		if (videoInfo->blit_sw)
		{
			CONS_Printf("%s", M_GetText(" Accelerated blits SW-2-HW\n"));
			if (!M_CheckParm("-noblit")) videoblitok = SDL_TRUE;
		}
		if (videoInfo->blit_sw_CC)
			CONS_Printf("%s", M_GetText(" Accelerated blits SW-2-HW with Colorkey\n"));
		if (videoInfo->blit_sw_A)
			CONS_Printf("%s", M_GetText(" Accelerated blits SW-2-HW with Alpha\n"));
		if (videoInfo->blit_fill)
			CONS_Printf("%s", M_GetText(" Accelerated Color filling\n"));
		//UnusedBits3  :16
		if (videoInfo->video_mem)
			CONS_Printf(M_GetText(" There is %i KB of video memory\n"), videoInfo->video_mem);
		else
			CONS_Printf("%s", M_GetText(" There no video memory for SDL\n"));
		//*vfmt
	}
#else
	if (!M_CheckParm("-noblit")) videoblitok = SDL_TRUE;
#endif
	SurfaceInfo(bufSurface, M_GetText("Current Engine Mode"));
	SurfaceInfo(vidSurface, M_GetText("Current Video Mode"));
	CONS_Printf(" Render resolution: %dx%d\n", vid.width, vid.height);
	if (window)
	{
		int width = 0, height = 0;
		SDL_Rect viewport;
		SDL_GetWindowSize(window, &width, &height);
		CONS_Printf(" Window: %dx%d %s on display %d\n",
			width, height, (SDL_GetWindowFlags(window) & SDL_WINDOW_FULLSCREEN)
				? "fullscreen" : "windowed", SDL_GetWindowDisplayIndex(window));
		if (renderer)
			SDL_GetRendererOutputSize(renderer, &width, &height);
		else
			SDL_GL_GetDrawableSize(window, &width, &height);
		I_GetGameViewport(width, height, &viewport);
		CONS_Printf(" Presentation: %dx%d in %dx%d at %d,%d\n",
			viewport.w, viewport.h, width, height, viewport.x, viewport.y);
	}
	CONS_Printf(" Frame pacing: %.2f FPS current, %u Hz display, %s cap (%u effective)\n",
		averageFPS, refresh_rate, cv_fpscap.string, R_GetFramerateCap());
#ifdef HWRENDER
	if (sdlglcontext != NULL && SDL_GL_GetCurrentContext() == sdlglcontext)
	{
		if (cv_vidwait.value && OglSdlCompositorProvidesPacing())
			CONS_Printf(" VSync: %s, Windows compositor pacing\n",
				cv_vidwait.string);
		else
			CONS_Printf(" VSync: %s, active OpenGL swap interval %d\n",
				cv_vidwait.string, SDL_GL_GetSwapInterval());
	}
	else
#endif
		CONS_Printf(" VSync: %s\n", cv_vidwait.string);
#endif
}

static void VID_Command_ModeList_f(void)
{
	// List windowed modes
	INT32 i = 0;
	CONS_Printf("NOTE: Under SDL2, all modes are supported on all platforms.\n");
	CONS_Printf("Fullscreen scales the selected render resolution to the desktop display.\n");
	for (i = 0; i < MAXWINMODES; i++)
	{
		CONS_Printf("%2d: %dx%d\n", i, windowedModes[i][0], windowedModes[i][1]);
	}

}

static void VID_Command_Mode_f (void)
{
	INT32 modenum;

	if (COM_Argc()!= 2)
	{
		CONS_Printf(M_GetText("vid_mode <modenum> : set video mode, current video mode %i\n"), vid.modenum);
		return;
	}

	modenum = atoi(COM_Argv(1));

	if (modenum >= VID_NumModes())
		CONS_Printf(M_GetText("Video mode not present\n"));
	else
		setmodeneeded = modenum+1; // request vid mode change
}

INT32 I_JoystickButtonKey(INT32 button, boolean secondary)
{
 INT32 base = secondary ? KEY_2JOY1 : KEY_JOY1;
 if (button < 0 || button >= JOYBUTTONS) return KEY_NULL;
#ifdef __ANDROID__
 static const UINT8 buttons[] = {0, 1, 2, 3, 6, 10, 7, 8, 9, 4, 5};
 if (button < (INT32)(sizeof buttons/sizeof buttons[0])) return base+buttons[button];
 if (button >= 11 && button <= 14) return (secondary ? KEY_2HAT1 : KEY_HAT1)+button-11;
#endif
 return base+button;
}

static inline void SDLJoyRemap(event_t *event)
{
	(void)event;
}

static INT32 SDLJoyAxis(const Sint16 axis, evtype_t which)
{
	// -32768 to 32767
	INT32 raxis = axis/32;
	if (which == ev_joystick)
	{
		if (Joystick.bGamepadStyle)
		{
			// gamepad control type, on or off, live or die
			if (raxis < -(JOYAXISRANGE/2))
				raxis = -1;
			else if (raxis > (JOYAXISRANGE/2))
				raxis = 1;
			else
				raxis = 0;
		}
		else
		{
			raxis = JoyInfo.scale!=1?((raxis/JoyInfo.scale)*JoyInfo.scale):raxis;

#ifdef SDL_JDEADZONE
			if (-SDL_JDEADZONE <= raxis && raxis <= SDL_JDEADZONE)
				raxis = 0;
#endif
		}
	}
	else if (which == ev_joystick2)
	{
		if (Joystick2.bGamepadStyle)
		{
			// gamepad control type, on or off, live or die
			if (raxis < -(JOYAXISRANGE/2))
				raxis = -1;
			else if (raxis > (JOYAXISRANGE/2))
				raxis = 1;
			else raxis = 0;
		}
		else
		{
			raxis = JoyInfo2.scale!=1?((raxis/JoyInfo2.scale)*JoyInfo2.scale):raxis;

#ifdef SDL_JDEADZONE
			if (-SDL_JDEADZONE <= raxis && raxis <= SDL_JDEADZONE)
				raxis = 0;
#endif
		}
	}
	return raxis;
}

static void Impl_HandleWindowEvent(SDL_WindowEvent evt)
{
	static SDL_bool firsttimeonmouse = SDL_TRUE;
	static SDL_bool mousefocus = SDL_TRUE;
	static SDL_bool kbfocus = SDL_TRUE;
	SDL_bool reacquire = SDL_FALSE;

	switch (evt.event)
	{
		case SDL_WINDOWEVENT_ENTER:
			mousefocus = SDL_TRUE;
			break;
		case SDL_WINDOWEVENT_LEAVE:
			mousefocus = SDL_FALSE;
			break;
		case SDL_WINDOWEVENT_FOCUS_GAINED:
			kbfocus = SDL_TRUE;
			mousefocus = SDL_TRUE;
			reacquire = SDL_TRUE;
			VID_UpdateRefreshRate(true);
			break;
		case SDL_WINDOWEVENT_FOCUS_LOST:
			kbfocus = SDL_FALSE;
			mousefocus = SDL_FALSE;
			break;
		case SDL_WINDOWEVENT_MAXIMIZED:
		case SDL_WINDOWEVENT_MOVED:
#if SDL_VERSION_ATLEAST(2, 0, 18)
		case SDL_WINDOWEVENT_DISPLAY_CHANGED:
#endif
			VID_UpdateRefreshRate(true);
			break;
	}

	if (mousefocus && kbfocus)
	{
		// Tell game we got focus back, resume music if necessary
		window_notinfocus = false;
		if (!paused)
			S_ResumeAudio(); //resume it

		if (!firsttimeonmouse)
		{
			if (cv_usemouse.value) I_StartupMouse();
		}
		//else firsttimeonmouse = SDL_FALSE;

		if (USE_MOUSEINPUT && ShouldGrabMouse())
		{
			if (reacquire)
				SDLreacquireMouse();
			else
				SDLdoGrabMouse();
		}
	}
	else if (!mousefocus && !kbfocus)
	{
		// Tell game we lost focus, pause music
		window_notinfocus = true;
		if (! cv_playmusicifunfocused.value)
			S_PauseAudio();
		if (! cv_playsoundsifunfocused.value)
			S_StopSounds();

		if (!disable_mouse)
		{
			SDLforceUngrabMouse();
		}
		memset(gamekeydown, 0, NUMKEYS); // TODO this is a scary memset

		if (MOUSE_MENU)
		{
			SDLdoUngrabMouse();
		}
	}

}

static void Impl_HandleKeyboardEvent(SDL_KeyboardEvent evt, Uint32 type)
{
	event_t event;
	if (type == SDL_KEYUP)
	{
		event.type = ev_keyup;
	}
	else if (type == SDL_KEYDOWN)
	{
		event.type = ev_keydown;
	}
	else
	{
		return;
	}
	event.key = Impl_SDL_Scancode_To_Keycode(evt.keysym.scancode);
	event.repeated = (evt.repeat != 0);
	if (event.key) D_PostEvent(&event);
}

static void Impl_HandleTextEvent(SDL_TextInputEvent evt)
{
	event_t event;
	event.type = ev_text;
	// SDL may deliver several characters in one text event (for example an
	// address pasted or entered by an IME). Keep the existing ASCII policy,
	// but do not discard an otherwise valid whole string.
	for (size_t i = 0; i < sizeof evt.text && evt.text[i]; i++)
	{
		if ((UINT8)evt.text[i] >= 128) return;
	}
	for (size_t i = 0; i < sizeof evt.text && evt.text[i]; i++)
	{
		if ((UINT8)evt.text[i] < 32 || evt.text[i] == 127) continue;
		event.key = evt.text[i];
		D_PostEvent(&event);
	}
}

static boolean Impl_IgnoreResizePointer(Uint32 source)
{
#ifdef _WIN32
	if (resize_cursor_valid && source != SDL_TOUCH_MOUSEID)
	{
		POINT cursor;

		if (mouse.buttons & MB_BUTTON1)
		{
			resize_cursor_valid = GetCursorPos(&resize_cursor);
			return true;
		}
		resize_cursor_valid = GetCursorPos(&cursor)
			&& cursor.x == resize_cursor.x && cursor.y == resize_cursor.y;
		return resize_cursor_valid;
	}
#else
	(void)source;
#endif
	return false;
}

static void Impl_PostMenuPointer(INT32 x, INT32 y)
{
	int width, height;
	event_t event;
	SDL_GetWindowSize(window, &width, &height);
	if (width <= 0 || height <= 0)
		return;
	SDL_Rect viewport;
	I_GetGameViewport(width, height, &viewport);
	SDL_memset(&event, 0, sizeof event);
	event.type = ev_mouseabsolute;

	event.x = x < viewport.x ? -1 : (INT32)((INT64)(x - viewport.x)*vid.width/viewport.w);
	event.y = y < viewport.y ? -1 : (INT32)((INT64)(y - viewport.y)*vid.height/viewport.h);
	D_PostEvent(&event);
}

static void Impl_HandleMouseMotionEvent(SDL_MouseMotionEvent evt)
{
	static boolean firstmove = true;
	if (chat_on || con_destlines)
	{
		if (SDL_GetRelativeMouseMode())
			SDLdoUngrabMouse();
		if (!disable_mouse && havefocus)
			Impl_PostMenuPointer(evt.x, evt.y);
		firstmove = false;
		return;
	}
	if (!disable_mouse && havefocus && M_MenuMouseActive())
	{
		if (SDL_GetRelativeMouseMode())
			SDLdoUngrabMouse();
		mousemovex = mousemovey = 0;
		if (!Impl_IgnoreResizePointer(evt.which))
			Impl_PostMenuPointer(evt.x, evt.y);
		firstmove = false;
		return;
	}

	if (USE_MOUSEINPUT)
	{
		if ((SDL_GetMouseFocus() != window && SDL_GetKeyboardFocus() != window) || (!ShouldGrabMouse() && !firstmove))
		{
			SDLdoUngrabMouse();
			firstmove = false;
			return;
		}

		// If using relative mouse mode, don't post an event_t just now,
		// add on the offsets so we can make an overall event later.
		if (SDL_GetRelativeMouseMode())
		{
			if (SDL_GetMouseFocus() == window && SDL_GetKeyboardFocus() == window)
			{
				mousemovex += evt.xrel;
				mousemovey += evt.yrel;
				SDL_SetWindowGrab(window, SDL_TRUE);
			}
			firstmove = false;
			return;
		}

		// If the event is from warping the pointer to middle
		// of the screen then ignore it.
		if ((evt.x == realwidth/2) && (evt.y == realheight/2))
		{
			firstmove = false;
			return;
		}

		// Don't send an event_t if not in relative mouse mode anymore,
		// just grab and set relative mode
		// this fixes the stupid camera jerk on mouse entering bug
		// -- Monster Iestyn
		if (SDL_GetMouseFocus() == window && SDL_GetKeyboardFocus() == window)
		{
			SDLdoGrabMouse();
		}
	}

	firstmove = false;
}

static void Impl_HandleMouseButtonEvent(SDL_MouseButtonEvent evt, Uint32 type)
{
	event_t event;
	const boolean menumouse = !disable_mouse && havefocus && (M_MenuMouseActive() || con_destlines || chat_on);
	if (evt.button == SDL_BUTTON_LEFT && type == SDL_MOUSEBUTTONUP)
		SDL_CaptureMouse(SDL_FALSE);

	SDL_memset(&event, 0, sizeof(event_t));

	// Ignore the event if the mouse is not actually focused on the window.
	// This can happen if you used the mouse to restore keyboard focus;
	// this apparently makes a mouse button down event but not a mouse button up event,
	// resulting in whatever key was pressed down getting "stuck" if we don't ignore it.
	// -- Monster Iestyn (28/05/18)
	if ((SDL_GetMouseFocus() != window && !(menumouse && type == SDL_MOUSEBUTTONUP))
	 || (ShouldIgnoreMouse() && !chat_on && !con_destlines))
		return;

	/// \todo inputEvent.button.which
	if (USE_MOUSEINPUT || menumouse)
	{
		if (menumouse)
		{
#ifdef _WIN32
			if (type == SDL_MOUSEBUTTONDOWN)
				resize_cursor_valid = false;
#endif

			if (type == SDL_MOUSEBUTTONDOWN || !Impl_IgnoreResizePointer(evt.which))
				Impl_PostMenuPointer(evt.x, evt.y);
			if (evt.button == SDL_BUTTON_LEFT && type == SDL_MOUSEBUTTONDOWN)
				SDL_CaptureMouse(SDL_TRUE);
		}
		if (type == SDL_MOUSEBUTTONUP)
		{
			event.type = ev_keyup;
		}
		else if (type == SDL_MOUSEBUTTONDOWN)
		{
			event.type = ev_keydown;
		}
		else return;
		if (evt.button == SDL_BUTTON_MIDDLE)
			event.key = KEY_MOUSE1+2;
		else if (evt.button == SDL_BUTTON_RIGHT)
			event.key = KEY_MOUSE1+1;
		else if (evt.button == SDL_BUTTON_LEFT)
			event.key = KEY_MOUSE1;
		else if (evt.button == SDL_BUTTON_X1)
			event.key = KEY_MOUSE1+3;
		else if (evt.button == SDL_BUTTON_X2)
			event.key = KEY_MOUSE1+4;
		if (event.type == ev_keyup || event.type == ev_keydown)
		{
			D_PostEvent(&event);
		}
	}
}

static void Impl_HandleMouseWheelEvent(SDL_MouseWheelEvent evt)
{
	event_t event;

	SDL_memset(&event, 0, sizeof(event_t));

	if (evt.y > 0)
	{
		event.key = KEY_MOUSEWHEELUP;
		event.type = ev_keydown;
	}
	if (evt.y < 0)
	{
		event.key = KEY_MOUSEWHEELDOWN;
		event.type = ev_keydown;
	}
	if (evt.y == 0)
	{
		event.key = 0;
		event.type = ev_keyup;
	}
	if (event.type == ev_keyup || event.type == ev_keydown)
	{
		D_PostEvent(&event);
	}
}

static void Impl_HandleJoystickAxisEvent(SDL_JoyAxisEvent evt)
{
	event_t event;
	SDL_JoystickID joyid[2];

	// Determine the Joystick IDs for each current open joystick
	joyid[0] = SDL_JoystickInstanceID(JoyInfo.dev);
	joyid[1] = SDL_JoystickInstanceID(JoyInfo2.dev);

	evt.axis++;
	event.key = event.x = event.y = INT32_MAX;

	if (evt.which == joyid[0])
	{
		event.type = ev_joystick;
	}
	else if (evt.which == joyid[1])
	{
		event.type = ev_joystick2;
	}
	else return;
	//axis
	if (evt.axis > JOYAXISSET*2)
		return;
	//vaule
	if (evt.axis%2)
	{
		event.key = evt.axis / 2;
		event.x = SDLJoyAxis(evt.value, event.type);
	}
	else
	{
		evt.axis--;
		event.key = evt.axis / 2;
		event.y = SDLJoyAxis(evt.value, event.type);
	}
	D_PostEvent(&event);
}

#if 0
static void Impl_HandleJoystickHatEvent(SDL_JoyHatEvent evt)
{
	event_t event;
	SDL_JoystickID joyid[2];

	// Determine the Joystick IDs for each current open joystick
	joyid[0] = SDL_JoystickInstanceID(JoyInfo.dev);
	joyid[1] = SDL_JoystickInstanceID(JoyInfo2.dev);

	if (evt.hat >= JOYHATS)
		return; // ignore hats with too high an index

	if (evt.which == joyid[0])
	{
		event.key = KEY_HAT1 + (evt.hat*4);
	}
	else if (evt.which == joyid[1])
	{
		event.key = KEY_2HAT1 + (evt.hat*4);
	}
	else return;

	// NOTE: UNFINISHED
}
#endif

static void Impl_HandleJoystickButtonEvent(SDL_JoyButtonEvent evt, Uint32 type)
{
	event_t event;
	SDL_JoystickID joyid[2];

	// Determine the Joystick IDs for each current open joystick
	joyid[0] = SDL_JoystickInstanceID(JoyInfo.dev);
	joyid[1] = SDL_JoystickInstanceID(JoyInfo2.dev);

	if (evt.which == joyid[0])
	{
		event.key = KEY_JOY1;
	}
	else if (evt.which == joyid[1])
	{
		event.key = KEY_2JOY1;
	}
	else return;
	if (type == SDL_JOYBUTTONUP)
	{
		event.type = ev_keyup;
	}
	else if (type == SDL_JOYBUTTONDOWN)
	{
		event.type = ev_keydown;
	}
	else return;
	if (evt.button < JOYBUTTONS)
	{
		event.key += evt.button;
	}
	else return;

	SDLJoyRemap(&event);
	if (event.type != ev_console) D_PostEvent(&event);
}



#ifdef __EMSCRIPTEN__
boolean web_gamecontrols[NUM_GAMECONTROLS];

EM_JS(INT32, Web_NextTouchButton, (void), {
	return Module['nextTouchButton']?.() || 0;
});

static void Impl_PollTouchButtons(void)
{
	// Order matches the button IDs in web/touch-controls.mjs.
	static const struct { INT32 key, control; boolean repeat; } buttons[] = {
		{KEY_UPARROW, GC_FORWARD, true}, {KEY_DOWNARROW, GC_BACKWARD, true},
		{KEY_LEFTARROW, GC_TURNLEFT, true}, {KEY_RIGHTARROW, GC_TURNRIGHT, true},
		{KEY_ENTER, GC_JUMP, false}, {KEY_BACKSPACE, GC_SPIN, false},
		{0, GC_FIRE, false}, {KEY_ESCAPE, GC_NULL, false},
	};
	static INT32 activekeys[sizeof buttons / sizeof buttons[0]];
	static Uint32 repeat_at[sizeof buttons / sizeof buttons[0]];
	const boolean playing = gamestate == GS_LEVEL && !menuactive && !chat_on && !CON_Ready();
	const boolean answering = M_YesNoPromptActive();
	const Uint32 now = SDL_GetTicks();
	INT32 input;

	if (!playing)
		memset(web_gamecontrols, 0, sizeof web_gamecontrols);

	while ((input = Web_NextTouchButton()) != 0)
	{
		const UINT32 index = (UINT32)(abs(input) - 1);
		if (index >= sizeof buttons / sizeof buttons[0])
			continue;

		const boolean pressed = input > 0;
		const INT32 control = buttons[index].control;
		if (pressed)
		{
			INT32 key = buttons[index].key;
			if (answering && key == KEY_ENTER)
				key = 'y';
			else if (answering && key == KEY_BACKSPACE)
				key = 'n';
			activekeys[index] = !playing || control == GC_NULL ? key : 0;
			repeat_at[index] = now + 350;
		}
		if (control != GC_NULL)
			web_gamecontrols[control] = playing && pressed;

		if (activekeys[index])
		{
			const event_t event = {.type = pressed ? ev_keydown : ev_keyup, .key = activekeys[index]};
			D_PostEvent(&event);
		}
		if (!pressed)
			activekeys[index] = 0;
	}

	// Process releases first. A held direction then scrolls the menu at most
	// once per interval, even if the browser paused the game between frames.
	if (menuactive && !CON_Ready())
	{
		for (size_t i = 0; i < sizeof buttons / sizeof buttons[0]; i++)
		{
			if (!buttons[i].repeat || !activekeys[i] || !SDL_TICKS_PASSED(now, repeat_at[i]))
				continue;

			const event_t event = {.type = ev_keydown, .key = activekeys[i], .repeated = true};
			D_PostEvent(&event);
			repeat_at[i] = now + 100;
		}
	}
}
#endif

void I_GetEvent(void)
{
	SDL_Event evt;
	// We only want the first motion event,
	// otherwise we'll end up catching the warp back to center.
	//int mouseMotionOnce = 0;

	if (!graphics_started)
	{
		return;
	}

	mousemovex = mousemovey = 0;

#ifdef __EMSCRIPTEN__
	Impl_PollTouchButtons();
#endif
	while (SDL_PollEvent(&evt))
	{
		switch (evt.type)
		{
			case SDL_WINDOWEVENT:
				Impl_HandleWindowEvent(evt.window);
				break;
			case SDL_KEYUP:
			case SDL_KEYDOWN:
				Impl_HandleKeyboardEvent(evt.key, evt.type);
				break;
			case SDL_TEXTINPUT:
				Impl_HandleTextEvent(evt.text);
				break;
			case SDL_MOUSEMOTION:
				//if (!mouseMotionOnce)
				Impl_HandleMouseMotionEvent(evt.motion);
				//mouseMotionOnce = 1;
				break;
			case SDL_MOUSEBUTTONUP:
			case SDL_MOUSEBUTTONDOWN:
				Impl_HandleMouseButtonEvent(evt.button, evt.type);
				break;
			case SDL_MOUSEWHEEL:
				Impl_HandleMouseWheelEvent(evt.wheel);
				break;
			case SDL_JOYAXISMOTION:
				Impl_HandleJoystickAxisEvent(evt.jaxis);
				break;
#if 0
			case SDL_JOYHATMOTION:
				Impl_HandleJoystickHatEvent(evt.jhat)
				break;
#endif
			case SDL_JOYBUTTONUP:
			case SDL_JOYBUTTONDOWN:
				Impl_HandleJoystickButtonEvent(evt.jbutton, evt.type);
				break;
			case SDL_JOYDEVICEADDED:
				{
					SDL_Joystick *newjoy = SDL_JoystickOpen(evt.jdevice.which);

					CONS_Debug(DBG_GAMELOGIC, "Joystick device index %d added\n", evt.jdevice.which + 1);

					// Because SDL's device index is unstable, we're going to cheat here a bit:
					// For the first joystick setting that is NOT active:
					// 1. Set cv_usejoystickX.value to the new device index (this does not change what is written to config.cfg)
					// 2. Set OTHERS' cv_usejoystickX.value to THEIR new device index, because it likely changed
					//    * If device doesn't exist, switch cv_usejoystick back to default value (.string)
					//      * BUT: If that default index is being occupied, use ANOTHER cv_usejoystick's default value!
					if (newjoy && (!JoyInfo.dev || !SDL_JoystickGetAttached(JoyInfo.dev))
						&& JoyInfo2.dev != newjoy) // don't override a currently active device
					{
						cv_usejoystick.value = evt.jdevice.which + 1;

						if (JoyInfo2.dev)
							cv_usejoystick2.value = I_GetJoystickDeviceIndex(JoyInfo2.dev) + 1;
						else if (atoi(cv_usejoystick2.string) != JoyInfo.oldjoy
								&& atoi(cv_usejoystick2.string) != cv_usejoystick.value)
							cv_usejoystick2.value = atoi(cv_usejoystick2.string);
						else if (atoi(cv_usejoystick.string) != JoyInfo.oldjoy
								&& atoi(cv_usejoystick.string) != cv_usejoystick.value)
							cv_usejoystick2.value = atoi(cv_usejoystick.string);
						else // we tried...
							cv_usejoystick2.value = 0;
					}
					else if (newjoy && (!JoyInfo2.dev || !SDL_JoystickGetAttached(JoyInfo2.dev))
						&& JoyInfo.dev != newjoy) // don't override a currently active device
					{
						cv_usejoystick2.value = evt.jdevice.which + 1;

						if (JoyInfo.dev)
							cv_usejoystick.value = I_GetJoystickDeviceIndex(JoyInfo.dev) + 1;
						else if (atoi(cv_usejoystick.string) != JoyInfo2.oldjoy
								&& atoi(cv_usejoystick.string) != cv_usejoystick2.value)
							cv_usejoystick.value = atoi(cv_usejoystick.string);
						else if (atoi(cv_usejoystick2.string) != JoyInfo2.oldjoy
								&& atoi(cv_usejoystick2.string) != cv_usejoystick2.value)
							cv_usejoystick.value = atoi(cv_usejoystick2.string);
						else // we tried...
							cv_usejoystick.value = 0;
					}

					// Was cv_usejoystick disabled in settings?
					if (!strcmp(cv_usejoystick.string, "0") || !cv_usejoystick.value)
						cv_usejoystick.value = 0;
					else if (atoi(cv_usejoystick.string) <= I_NumJoys() // don't mess if we intentionally set higher than NumJoys
						     && cv_usejoystick.value) // update the cvar ONLY if a device exists
						CV_SetValue(&cv_usejoystick, cv_usejoystick.value);

					if (!strcmp(cv_usejoystick2.string, "0") || !cv_usejoystick2.value)
						cv_usejoystick2.value = 0;
					else if (atoi(cv_usejoystick2.string) <= I_NumJoys() // don't mess if we intentionally set higher than NumJoys
					         && cv_usejoystick2.value) // update the cvar ONLY if a device exists
						CV_SetValue(&cv_usejoystick2, cv_usejoystick2.value);

					// Update all joysticks' init states
					// This is a little wasteful since cv_usejoystick already calls this, but
					// we need to do this in case CV_SetValue did nothing because the string was already same.
					// if the device is already active, this should do nothing, effectively.
					I_InitJoystick();
					I_InitJoystick2();

					CONS_Debug(DBG_GAMELOGIC, "Joystick1 device index: %d\n", JoyInfo.oldjoy);
					CONS_Debug(DBG_GAMELOGIC, "Joystick2 device index: %d\n", JoyInfo2.oldjoy);

					// update the menu
					if (currentMenu == &OP_JoystickSetDef)
						M_SetupJoystickMenu(0);

					if (JoyInfo.dev != newjoy && JoyInfo2.dev != newjoy)
						SDL_JoystickClose(newjoy);
				}
				break;
			case SDL_JOYDEVICEREMOVED:
				if (JoyInfo.dev && !SDL_JoystickGetAttached(JoyInfo.dev))
				{
					CONS_Debug(DBG_GAMELOGIC, "Joystick1 removed, device index: %d\n", JoyInfo.oldjoy);
					I_ShutdownJoystick();
				}

				if (JoyInfo2.dev && !SDL_JoystickGetAttached(JoyInfo2.dev))
				{
					CONS_Debug(DBG_GAMELOGIC, "Joystick2 removed, device index: %d\n", JoyInfo2.oldjoy);
					I_ShutdownJoystick2();
				}

				// Update the device indexes, because they likely changed
				// * If device doesn't exist, switch cv_usejoystick back to default value (.string)
				//   * BUT: If that default index is being occupied, use ANOTHER cv_usejoystick's default value!
				if (JoyInfo.dev)
					cv_usejoystick.value = JoyInfo.oldjoy = I_GetJoystickDeviceIndex(JoyInfo.dev) + 1;
				else if (atoi(cv_usejoystick.string) != JoyInfo2.oldjoy)
					cv_usejoystick.value = atoi(cv_usejoystick.string);
				else if (atoi(cv_usejoystick2.string) != JoyInfo2.oldjoy)
					cv_usejoystick.value = atoi(cv_usejoystick2.string);
				else // we tried...
					cv_usejoystick.value = 0;

				if (JoyInfo2.dev)
					cv_usejoystick2.value = JoyInfo2.oldjoy = I_GetJoystickDeviceIndex(JoyInfo2.dev) + 1;
				else if (atoi(cv_usejoystick2.string) != JoyInfo.oldjoy)
					cv_usejoystick2.value = atoi(cv_usejoystick2.string);
				else if (atoi(cv_usejoystick.string) != JoyInfo.oldjoy)
					cv_usejoystick2.value = atoi(cv_usejoystick.string);
				else // we tried...
					cv_usejoystick2.value = 0;

				// Was cv_usejoystick disabled in settings?
				if (!strcmp(cv_usejoystick.string, "0"))
					cv_usejoystick.value = 0;
				else if (atoi(cv_usejoystick.string) <= I_NumJoys() // don't mess if we intentionally set higher than NumJoys
						 && cv_usejoystick.value) // update the cvar ONLY if a device exists
					CV_SetValue(&cv_usejoystick, cv_usejoystick.value);

				if (!strcmp(cv_usejoystick2.string, "0"))
					cv_usejoystick2.value = 0;
				else if (atoi(cv_usejoystick2.string) <= I_NumJoys() // don't mess if we intentionally set higher than NumJoys
						 && cv_usejoystick2.value) // update the cvar ONLY if a device exists
					CV_SetValue(&cv_usejoystick2, cv_usejoystick2.value);

				CONS_Debug(DBG_GAMELOGIC, "Joystick1 device index: %d\n", JoyInfo.oldjoy);
				CONS_Debug(DBG_GAMELOGIC, "Joystick2 device index: %d\n", JoyInfo2.oldjoy);

				// update the menu
				if (currentMenu == &OP_JoystickSetDef)
					M_SetupJoystickMenu(0);
				break;
			case SDL_QUIT:
				LUA_HookBool(true, HOOK(GameQuit));
				I_Quit();
				break;
		}
	}

	// Send all relative mouse movement as one single mouse event.
	if (mousemovex || mousemovey)
	{
		event_t event;
		int wwidth, wheight;
		SDL_GetWindowSize(window, &wwidth, &wheight);
		//SDL_memset(&event, 0, sizeof(event_t));
		event.type = ev_mouse;
		event.key = 0;
		event.x = (INT32)lround(mousemovex * ((float)wwidth / (float)realwidth));
		event.y = (INT32)lround(mousemovey * ((float)wheight / (float)realheight));
		D_PostEvent(&event);
	}

	// In order to make wheels act like buttons, we have to set their state to Up.
	// This is because wheel messages don't have an up/down state.
	gamekeydown[KEY_MOUSEWHEELDOWN] = gamekeydown[KEY_MOUSEWHEELUP] = 0;
}

void I_StartupMouse(void)
{
	static SDL_bool firsttimeonmouse = SDL_TRUE;

	if (disable_mouse)
		return;

	if (!firsttimeonmouse)
	{
		HalfWarpMouse(realwidth, realheight); // warp to center
	}
	else
		firsttimeonmouse = SDL_FALSE;
	if (cv_usemouse.value && ShouldGrabMouse())
		SDLdoGrabMouse();
	else
		SDLdoUngrabMouse();
}

//
// I_OsPolling
//
void I_OsPolling(void)
{
	SDL_Keymod mod;
#ifdef _WIN32
	if (windows_move_ticking)
		return;
#endif

	if (consolevent)
		I_GetConsoleEvents();
	if (SDL_WasInit(SDL_INIT_JOYSTICK) == SDL_INIT_JOYSTICK)
	{
		SDL_JoystickUpdate();
		I_GetJoystickEvents();
		I_GetJoystick2Events();
	}

	I_GetMouseEvents();

	I_GetEvent();

	mod = SDL_GetModState();
	/* Handle here so that our state is always synched with the system. */
	shiftdown = ctrldown = altdown = 0;
	capslock = false;
	if (mod & KMOD_LSHIFT) shiftdown |= 1;
	if (mod & KMOD_RSHIFT) shiftdown |= 2;
	if (mod & KMOD_LCTRL)   ctrldown |= 1;
	if (mod & KMOD_RCTRL)   ctrldown |= 2;
	if (mod & KMOD_LALT)     altdown |= 1;
	if (mod & KMOD_RALT)     altdown |= 2;
	if (mod & KMOD_CAPS) capslock = true;
}

static void Impl_PresentSoftwareTexture(SDL_Texture *frame)
{
	int width, height;
	if (SDL_GetRendererOutputSize(renderer, &width, &height) != 0 || width <= 0 || height <= 0)
		return;

	SDL_RenderClear(renderer);
#ifdef __ANDROID__
	SDL_RenderCopy(renderer, frame, &src_rect, NULL);
#else
	SDL_Rect viewport;
	I_GetGameViewport(width, height, &viewport);
	SDL_RenderCopy(renderer, frame, &src_rect, &viewport);
#endif
	SDL_RenderPresent(renderer);
}

//
// I_UpdateNoBlit
//
void I_UpdateNoBlit(void)
{
	if (rendermode == render_none)
		return;
	if (exposevideo)
	{
#ifdef HWRENDER
		if (rendermode == render_opengl)
		{
			OglSdlFinishUpdate(cv_vidwait.value);
		}
		else
#endif
		if (rendermode == render_soft && renderer && last_software_texture)
			Impl_PresentSoftwareTexture(last_software_texture);
	}
	exposevideo = SDL_FALSE;
}

// I_SkipFrame
//
// Returns true if it thinks we can afford to skip this frame
// from PrBoom's src/SDL/i_video.c
static inline boolean I_SkipFrame(void)
{
#if 1
	// While I fixed the FPS counter bugging out with this,
	// I actually really like being able to pause and
	// use perfstats to measure rendering performance
	// without game logic changes.
	return false;
#else
	static boolean skip = false;

	skip = !skip;

	switch (gamestate)
	{
		case GS_LEVEL:
			if (!paused)
				return false;
			/* FALLTHRU */
		//case GS_TIMEATTACK: -- sorry optimisation but now we have a cool level platter and that being laggardly looks terrible
		case GS_WAITINGPLAYERS:
			return skip; // Skip odd frames
		default:
			return false;
	}
#endif
}

//
// I_FinishUpdate
//


void I_FinishUpdate(void)
{
	if (rendermode == render_none)
		return; //Alam: No software or OpenGl surface

	SCR_CalculateFPS();

	if (I_SkipFrame())
		return;

	if (marathonmode)
		SCR_DisplayMarathonInfo();

	// draw captions if enabled
	if (cv_closedcaptioning.value)
		SCR_ClosedCaptions();

	if (cv_ticrate.value)
		SCR_DisplayTicRate();

	if (cv_showping.value && netgame && consoleplayer != serverplayer)
		SCR_DisplayLocalPing();

	if (rendermode == render_soft && screens[0])
	{
		const RGBA_t *colors = V_FinishSoftwareColors();
		if (colors && renderer && texture)
		{
			if (!software_color_texture)
			{
				software_color_texture = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA32,
					SDL_TEXTUREACCESS_STREAMING, vid.width, vid.height);
				if (software_color_texture)
					SDL_SetTextureBlendMode(software_color_texture, SDL_BLENDMODE_NONE);
			}
			if (!software_color_texture || SDL_UpdateTexture(software_color_texture, &src_rect,
				colors, vid.width * (INT32)sizeof *colors) < 0)
				colors = NULL;
		}

		if (!bufSurface) //Double-Check
		{
			Impl_VideoSetupSDLBuffer();
		}

		if (bufSurface && !colors)
		{
			SDL_BlitSurface(bufSurface, &src_rect, vidSurface, &src_rect);
		}

#ifdef HWRENDER
		if (software_gl_presenter)
		{
			OglSdlPresentSoftware(colors ? (const void *)colors : vidSurface->pixels,
				vid.width, vid.height, cv_vidwait.value, colors != NULL);
		}
		else
#endif
		if (renderer && texture)
		{


			if (!colors)
				SDL_UpdateTexture(texture, &src_rect, vidSurface->pixels, vidSurface->pitch);
			last_software_texture = colors ? software_color_texture : texture;
			Impl_PresentSoftwareTexture(last_software_texture);
		}
	}
#ifdef HWRENDER
	else if (rendermode == render_opengl)
	{
		// Final postprocess step of palette rendering, after everything else has been drawn.
		if (HWR_ShouldUsePaletteRendering())
		{
			HWD.pfnMakeScreenTexture(HWD_SCREENTEXTURE_GENERIC2);
			HWD.pfnSetShader(HWR_GetShaderFromTarget(SHADER_PALETTE_POSTPROCESS));
			HWD.pfnDrawScreenTexture(HWD_SCREENTEXTURE_GENERIC2, NULL, 0, true);
			HWD.pfnUnSetShader();
		}
		OglSdlFinishUpdate(cv_vidwait.value);
	}
#endif

	if (window_needs_first_present && window)
	{
		SDL_ShowWindow(window);
		SDL_RaiseWindow(window);
		window_needs_first_present = SDL_FALSE;
	}

	exposevideo = SDL_FALSE;
}

//
// I_UpdateNoVsync
//
void I_UpdateNoVsync(void)
{
	INT32 real_vidwait = cv_vidwait.value;
	cv_vidwait.value = 0;
	I_FinishUpdate();
	cv_vidwait.value = real_vidwait;
}

//
// I_ReadScreen
//
void I_ReadScreen(UINT8 *scr)
{
	if (rendermode != render_soft)
		I_Error ("I_ReadScreen: called while in non-software mode");
	else
		VID_BlitLinearScreen(screens[0], scr,
			vid.width*vid.bpp, vid.height,
			vid.rowbytes, vid.rowbytes);
}

//
// I_SetPalette
//
void I_SetPalette(RGBA_t *palette)
{
	size_t i;
	for (i=0; i<256; i++)
	{
		localPalette[i].r = palette[i].s.red;
		localPalette[i].g = palette[i].s.green;
		localPalette[i].b = palette[i].s.blue;
	}
	//if (vidSurface) SDL_SetPaletteColors(vidSurface->format->palette, localPalette, 0, 256);
	// Fury -- SDL2 vidSurface is a 32-bit surface buffer copied to the texture. It's not palletized, like bufSurface.
	if (bufSurface) SDL_SetPaletteColors(bufSurface->format->palette, localPalette, 0, 256);
}

// return number of fullscreen + X11 modes
INT32 VID_NumModes(void)
{
	if (USE_FULLSCREEN && numVidModes != -1)
		return numVidModes - firstEntry;
	else
		return MAXWINMODES;
}

const char *VID_GetModeName(INT32 modeNum)
{
#if 0
	if (USE_FULLSCREEN && numVidModes != -1) // fullscreen modes
	{
		modeNum += firstEntry;
		if (modeNum >= numVidModes)
			return NULL;

		sprintf(&vidModeName[modeNum][0], "%dx%d",
			modeList[modeNum]->w,
			modeList[modeNum]->h);
	}
	else // windowed modes
	{
#endif
	if (modeNum == -1)
	{
		return fallback_resolution_name;
	}
		if (modeNum >= MAXWINMODES)
			return NULL;

		sprintf(&vidModeName[modeNum][0], "%dx%d",
			windowedModes[modeNum][0],
			windowedModes[modeNum][1]);
	//}
	return &vidModeName[modeNum][0];
}

INT32 VID_GetModeForSize(INT32 w, INT32 h)
{
	int i;
	for (i = 0; i < MAXWINMODES; i++)
	{
		if (windowedModes[i][0] == w && windowedModes[i][1] == h)
		{
			return i;
		}
	}
	return -1;
}

void VID_PrepareModeList(void)
{
	// Under SDL2, we just use the windowed modes list, and scale in windowed fullscreen.
	allow_fullscreen = true;
}

// SDL_Renderer owns backend state that conflicts with SRB2's OpenGL context
// on some Windows drivers. Always discard every software object before making
// the game context current again; stale texture pointers also caused delayed
// crashes after the first Software -> OpenGL transition.
static void Impl_DestroySoftwareContext(void)
{
#ifdef HWRENDER
	if (software_gl_presenter && window && sdlglcontext)
	{
		if (SDL_GL_GetCurrentContext() != sdlglcontext)
			SDL_GL_MakeCurrent(window, sdlglcontext);
		if (SDL_GL_GetCurrentContext() == sdlglcontext)
			OglSdlDestroySoftwarePresenter();
	}
	software_gl_presenter = SDL_FALSE;
#endif

	if (texture)
	{
		SDL_DestroyTexture(texture);
		texture = NULL;
	}
	if (software_color_texture)
		SDL_DestroyTexture(software_color_texture);
	software_color_texture = last_software_texture = NULL;

	if (renderer)
	{
		// Submit queued presentation work before deleting its backend context.
		// This closes a timing-dependent race seen after several rapid switches.
#if SDL_VERSION_ATLEAST(2, 0, 10)
		SDL_RenderFlush(renderer);
#endif
		SDL_DestroyRenderer(renderer);
		renderer = NULL;
	}

	if (vidSurface)
	{
		SDL_FreeSurface(vidSurface);
		vidSurface = NULL;
	}

	if (bufSurface)
	{
		SDL_FreeSurface(bufSurface);
		bufSurface = NULL;
	}
}

static SDL_bool Impl_CreateContext(void)
{
	// Renderer-specific stuff
#ifdef HWRENDER
	if ((rendermode == render_opengl)
	&& (vid.glstate != VID_GL_LIBRARY_ERROR))
	{
		Impl_DestroySoftwareContext();

		if (!sdlglcontext)
			sdlglcontext = SDL_GL_CreateContext(window);
		if (sdlglcontext == NULL)
		{
			SDL_DestroyWindow(window);
			window = NULL;
			I_Error("Failed to create a GL context: %s\n", SDL_GetError());
		}
		if (SDL_GL_MakeCurrent(window, sdlglcontext) != 0)
			I_Error("Failed to activate the GL context: %s\n", SDL_GetError());
		{
			static INT32 reported_samples = -1;
			static INT32 reported_depth = -1;
			INT32 buffers = 0, samples = 0, depth = 0;
			SDL_GL_GetAttribute(SDL_GL_MULTISAMPLEBUFFERS, &buffers);
			SDL_GL_GetAttribute(SDL_GL_MULTISAMPLESAMPLES, &samples);
			SDL_GL_GetAttribute(SDL_GL_DEPTH_SIZE, &depth);
			if (!buffers)
				samples = 0;
			if (samples != reported_samples)
			{
				CONS_Printf("OpenGL edge antialiasing: %s\n",
					samples ? va("%dx MSAA", samples) : "Off");
				reported_samples = samples;
			}
			if (depth != reported_depth)
			{
				CONS_Printf("OpenGL depth buffer: %d bits\n", depth);
				reported_depth = depth;
			}
		}
	}
	else
#endif
	if (rendermode == render_soft)
	{
		int flags = 0; // Use this to set SDL_RENDERER_* flags now
#if defined(__EMSCRIPTEN__) && defined(HWRENDER)
		// Share the context with the hardware renderer. The browser keeps
		// one WebGL context per canvas, even when SDL creates a new wrapper.
		if (!sdlglcontext && vid.glstate != VID_GL_LIBRARY_ERROR
		&& (SDL_GetWindowFlags(window) & SDL_WINDOW_OPENGL))
		{
			sdlglcontext = SDL_GL_CreateContext(window);
			if (sdlglcontext)
				SetupGLFunc4();
			else
			{
				vid.glstate = VID_GL_LIBRARY_ERROR;
				SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
			}
		}
#endif
#ifdef HWRENDER
		// SDL renderers are not reliable on an SDL_WINDOW_OPENGL window,
		// especially in fullscreen. Upload Software through SRB2's persistent
		// game context. Keeping the same HWND *and* GL context lets OBS retain
		// its Game Capture hook across OpenGL -> Software switches. SDLSetMode's
		// OglSdlSurface call restores the complete HWR state on the way back.
		if (sdlglcontext)
		{
			static SDL_bool reported_gl_software_presenter = SDL_FALSE;

			if (SDL_GL_GetCurrentContext() != sdlglcontext
			&& SDL_GL_MakeCurrent(window, sdlglcontext) != 0)
				I_Error("Failed to activate the GL software presenter: %s\n", SDL_GetError());
			software_gl_presenter = SDL_TRUE;
			if (!reported_gl_software_presenter)
			{
				CONS_Printf("Software presentation: OpenGL framebuffer upload\n");
				reported_gl_software_presenter = SDL_TRUE;
			}
			return SDL_TRUE;
		}
#endif
		if (usesdl2soft)
			flags |= SDL_RENDERER_SOFTWARE;
		else if (cv_vidwait.value)
		{
#if SDL_VERSION_ATLEAST(2, 0, 18)
			// If SDL is new enough, we can turn off vsync later.
			flags |= SDL_RENDERER_PRESENTVSYNC;
#else
			// However, if it isn't, we should just silently turn vid_wait off
			// This is because the renderer will be created before the config
			// is read and vid_wait is set from the user's preferences, and thus
			// vid_wait will have no effect.
			CV_StealthSetValue(&cv_vidwait, 0);
#endif
		}

		if (!renderer)
			renderer = SDL_CreateRenderer(window, -1, flags);
		if (renderer == NULL)
		{
			CONS_Printf(M_GetText("Couldn't create rendering context: %s\n"), SDL_GetError());
			return SDL_FALSE;
		}
#ifdef __ANDROID__
		SDL_RenderSetLogicalSize(renderer, BASEVIDWIDTH, BASEVIDHEIGHT);
#endif
	}
	return SDL_TRUE;
}

static INT32 Impl_GetStartupMSAA(void)
{
	INT32 parm = M_CheckParm("-msaa");

	if (parm && M_IsNextParm())
	{
		const char *value = M_GetNextParm();
		INT32 samples = atoi(value);
		return (samples == 2 || samples == 4 || samples == 8 || samples == 16) ? samples : 0;
	}

	/* Multisampling costs bandwidth even while GL_MULTISAMPLE is disabled,
	 * because the window still owns a multisampled color/depth backbuffer.
	 * Keep the normal startup path single-sampled; -msaa remains available for
	 * users who explicitly accept that cost. */
	return 0;
}

void VID_CheckGLLoaded(rendermode_t oldrender)
{
	(void)oldrender;
#ifdef HWRENDER
	if (vid.glstate == VID_GL_LIBRARY_ERROR) // Well, it didn't work the first time anyway.
	{
		CONS_Alert(CONS_ERROR, "OpenGL never loaded\n");
		rendermode = oldrender;
		if (chosenrendermode == render_opengl) // fallback to software
			rendermode = render_soft;
		if (setrenderneeded)
		{
			CV_StealthSetValue(&cv_renderer, oldrender);
			setrenderneeded = 0;
		}
	}
#endif
}

boolean VID_CheckRenderer(void)
{
	boolean rendererchanged = false;
	boolean contextcreated = false;
#ifdef HWRENDER
	rendermode_t oldrenderer = rendermode;
#endif

	if (dedicated)
		return false;

	if (setrenderneeded)
	{
#if defined(_WIN32) && !defined(DEDICATED)
		I_SetCrashContext(va("switching renderer %d to %d at %dx%d fullscreen=%d",
			rendermode, setrenderneeded, vid.width, vid.height, USE_FULLSCREEN));
#endif
#ifdef HWRENDER
		// Release Software's uploader texture before restoring the hardware
		// renderer's complete state on the same persistent OpenGL context.
		if (oldrenderer == render_soft && setrenderneeded == render_opengl)
			Impl_DestroySoftwareContext();

#endif

		rendermode = setrenderneeded;
		rendererchanged = true;

#ifdef HWRENDER
		if (rendermode == render_opengl)
		{
			VID_CheckGLLoaded(oldrenderer);

			// Initialise OpenGL before calling SDLSetMode!!!
			// This is because SDLSetMode calls OglSdlSurface.
			if (vid.glstate == VID_GL_LIBRARY_NOTLOADED)
			{
				VID_StartupOpenGL();

				// Loaded successfully!
				if (vid.glstate == VID_GL_LIBRARY_LOADED)
				{
					Impl_DestroySoftwareContext();
					if (!window || !(SDL_GetWindowFlags(window) & SDL_WINDOW_OPENGL))
					{
						if (window)
						{
							SDL_DestroyWindow(window);
							window = NULL;
						}
						Impl_CreateWindow(USE_FULLSCREEN);
					}
					else
						Impl_CreateContext();

					// The OpenGL context is active on the retained or new window.
					contextcreated = true;
				}
			}
			else if (vid.glstate == VID_GL_LIBRARY_ERROR)
				rendererchanged = false;
		}
#endif

		if (!contextcreated)
			Impl_CreateContext();

		setrenderneeded = 0;
	}

	SDLSetMode(vid.width, vid.height, USE_FULLSCREEN, (setmodeneeded ? SDL_TRUE : SDL_FALSE));
	VID_UpdateRefreshRate(false);
	Impl_VideoSetupBuffer();

	if (rendermode == render_soft)
	{
		if (bufSurface)
		{
			SDL_FreeSurface(bufSurface);
			bufSurface = NULL;
		}

		SCR_SetDrawFuncs();
	}
#ifdef HWRENDER
	else if (rendermode == render_opengl && rendererchanged)
	{
		HWR_Switch();
		V_SetPalette(0);
	}
#endif

#if defined(_WIN32) && !defined(DEDICATED)
	if (rendererchanged)
		I_SetCrashContext(va("renderer %d active at %dx%d fullscreen=%d",
			rendermode, vid.width, vid.height, USE_FULLSCREEN));
#endif

	return rendererchanged;
}

static void VID_UpdateRefreshRate(boolean report)
{
	SDL_DisplayMode mode;
	int index;

	if (!window || !SDL_WasInit(SDL_INIT_VIDEO))
		return;

	index = SDL_GetWindowDisplayIndex(window);
	if (index < 0)
		return;
	if ((SDL_GetCurrentDisplayMode(index, &mode) != 0 || mode.refresh_rate <= 0)
		&& (SDL_GetDesktopDisplayMode(index, &mode) != 0 || mode.refresh_rate <= 0))
		return;

	if ((UINT32)mode.refresh_rate == refresh_rate)
		return;

	refresh_rate = (UINT32)mode.refresh_rate;
	if (report)
		CONS_Printf("Display refresh rate: %u Hz\n", refresh_rate);
}

INT32 VID_SetMode(INT32 modeNum)
{
	SDLdoUngrabMouse();

	vid.recalc = 1;
	vid.bpp = 1;

	if (modeNum < 0)
		modeNum = 0;
	if (modeNum >= MAXWINMODES)
		modeNum = VID_GetModeForSize(BASEVIDWIDTH, BASEVIDHEIGHT);

	vid.width = windowedModes[modeNum][0];
	vid.height = windowedModes[modeNum][1];
	vid.modenum = modeNum;

	//Impl_SetWindowName("SRB2 "VERSIONSTRING);
	src_rect.w = vid.width;
	src_rect.h = vid.height;

	VID_CheckRenderer();
	return SDL_TRUE;
}

static SDL_bool Impl_CreateWindow(SDL_bool fullscreen)
{
	int flags = SDL_WINDOW_HIDDEN;
#ifndef __ANDROID__
	flags |= SDL_WINDOW_RESIZABLE;
#endif
#ifdef HWRENDER
	const INT32 requested_msaa = Impl_GetStartupMSAA();
#endif

	if (rendermode == render_none) // dedicated
		return SDL_TRUE; // Monster Iestyn -- not sure if it really matters what we return here tbh

	if (window != NULL)
		return SDL_FALSE;

	if (fullscreen)
		flags |= SDL_WINDOW_FULLSCREEN_DESKTOP;

#ifdef HWRENDER
	/* Create the initial Software window with OpenGL capability so renderer
	 * switches can retain the same native window handle for capture tools. */
	flags |= SDL_WINDOW_OPENGL;
#ifdef __EMSCRIPTEN__
	// Repeating textures of arbitrary sizes are supported by WebGL 2.
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
#endif

	/* A 24-bit depth buffer is broadly accelerated on Windows and avoids the
	 * precision loss and GDI Generic fallback caused by unsupported formats. */
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
	// Hardware visual portals use the stencil buffer to confine the paired
	// view to the portal opening instead of leaking it across nearby walls.
	SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 8);
	if (requested_msaa > 0)
	{
		SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 1);
		SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, requested_msaa);
	}
	else
	{
		SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 0);
		SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, 0);
	}
#endif

	// Create a window
	window = SDL_CreateWindow("SRB2 "VERSIONSTRING, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
			realwidth, realheight, flags);

#ifdef HWRENDER
	/* Unsupported sample counts must not prevent the game from starting. Retry
	 * without MSAA and leave a clear message explaining the fallback. */
	if (window == NULL && requested_msaa > 0)
	{
		SDL_GL_SetAttribute(SDL_GL_MULTISAMPLEBUFFERS, 0);
		SDL_GL_SetAttribute(SDL_GL_MULTISAMPLESAMPLES, 0);
		window = SDL_CreateWindow("SRB2 "VERSIONSTRING, SDL_WINDOWPOS_CENTERED,
			SDL_WINDOWPOS_CENTERED, realwidth, realheight, flags);
		if (window)
			CONS_Alert(CONS_WARNING,
				"The GPU/driver could not create %dx MSAA; continuing without edge antialiasing.\n",
				requested_msaa);
	}

#endif

#ifdef HWRENDER
	/* Software rendering should still start on a system where SDL cannot make
	 * an OpenGL-capable window; that system will use the normal SDL presenter. */
	if (window == NULL && rendermode == render_soft)
	{
		flags &= ~SDL_WINDOW_OPENGL;
		window = SDL_CreateWindow("SRB2 "VERSIONSTRING,
			SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
			realwidth, realheight, flags);
	}
#endif

	if (window == NULL)
	{
		CONS_Printf(M_GetText("Couldn't create window: %s\n"), SDL_GetError());
		return SDL_FALSE;
	}

	// Do not expose Windows' default white client area. I_FinishUpdate shows
	// the window only after a complete Software or OpenGL frame is presented.
	window_needs_first_present = SDL_TRUE;

#ifdef _WIN32
	Impl_SubclassGameWindow();
#endif
	Impl_SetWindowIcon();

	return Impl_CreateContext();
}

/*
static void Impl_SetWindowName(const char *title)
{
	if (window == NULL)
	{
		return;
	}
	SDL_SetWindowTitle(window, title);
}
*/

static void Impl_SetWindowIcon(void)
{
	if (window && icoSurface)
		SDL_SetWindowIcon(window, icoSurface);
}

static void Impl_VideoSetupSDLBuffer(void)
{
	if (bufSurface != NULL)
	{
		SDL_FreeSurface(bufSurface);
		bufSurface = NULL;
	}
	// Set up the SDL palletized buffer (copied to vidbuffer before being rendered to texture)
	if (vid.bpp == 1)
	{
		bufSurface = SDL_CreateRGBSurfaceFrom(screens[0],vid.width,vid.height,8,
			(int)vid.rowbytes,0x00000000,0x00000000,0x00000000,0x00000000); // 256 mode
	}
	else if (vid.bpp == 2) // Fury -- don't think this is used at all anymore
	{
		bufSurface = SDL_CreateRGBSurfaceFrom(screens[0],vid.width,vid.height,15,
			(int)vid.rowbytes,0x00007C00,0x000003E0,0x0000001F,0x00000000); // 555 mode
	}
	if (bufSurface)
	{
		SDL_SetPaletteColors(bufSurface->format->palette, localPalette, 0, 256);
	}
	else
	{
		I_Error("%s", M_GetText("No system memory for SDL buffer surface\n"));
	}
}

static void Impl_VideoSetupBuffer(void)
{
	size_t required;
	void *newbuffer;

	// Set up game's software render buffer
	vid.rowbytes = vid.width * vid.bpp;
	vid.direct = NULL;
	required = (size_t)NUMSCREENS * (size_t)vid.rowbytes * (size_t)vid.height;

	// Resolution switches used to free and reallocate the full framebuffer even
	// when the existing allocation was already large enough. Keep a high-water
	// buffer so switching down from a large mode is effectively allocation-free.
	if (!vid.buffer || required > vid_buffer_capacity)
	{
		newbuffer = calloc(1, required);
		if (!newbuffer)
			I_Error("%s", M_GetText("Not enough memory for video buffer\n"));
		free(vid.buffer);
		vid.buffer = newbuffer;
		vid_buffer_capacity = required;
	}
	else
		memset(vid.buffer, 0, required);

	if (!vid.buffer)
	{
		I_Error("%s", M_GetText("Not enough memory for video buffer\n"));
	}
}

void I_StartupGraphics(void)
{
	if (dedicated)
	{
		rendermode = render_none;
		return;
	}
	if (graphics_started)
		return;

	COM_AddCommand ("vid_nummodes", VID_Command_NumModes_f, COM_LUA);
	COM_AddCommand ("vid_info", VID_Command_Info_f, COM_LUA);
	COM_AddCommand ("vid_modelist", VID_Command_ModeList_f, COM_LUA);
	COM_AddCommand ("vid_mode", VID_Command_Mode_f, 0);
	CV_RegisterVar (&cv_vidwait);
	CV_RegisterVar (&cv_windowedstyle);
#if !defined(__ANDROID__) && !defined(__EMSCRIPTEN__)
	CV_RegisterVar (&cv_windowsize);
#endif
	CV_RegisterVar (&cv_stretch);
	CV_RegisterVar (&cv_alwaysgrabmouse);
	disable_mouse = M_CheckParm("-nomouse");
	disable_fullscreen = M_CheckParm("-win") ? 1 : 0;

	keyboard_started = true;

#if !defined(HAVE_TTF)
	// Previously audio was init here for questionable reasons?
	if (SDL_InitSubSystem(SDL_INIT_VIDEO) < 0)
	{
		CONS_Printf(M_GetText("Couldn't initialize SDL's Video System: %s\n"), SDL_GetError());
		return;
	}
#endif
	{
		const char *vd = SDL_GetCurrentVideoDriver();
		//CONS_Printf(M_GetText("Starting up with video driver: %s\n"), vd);
		if (vd && (
			strncasecmp(vd, "gcvideo", 8) == 0 ||
			strncasecmp(vd, "fbcon", 6) == 0 ||
			strncasecmp(vd, "wii", 4) == 0 ||
			strncasecmp(vd, "psl1ght", 8) == 0
		))
			framebuffer = SDL_TRUE;
	}

	// Renderer choices
	// Takes priority over the config.
	if (M_CheckParm("-renderer"))
	{
		INT32 i = 0;
		CV_PossibleValue_t *renderer_list = cv_renderer_t;
		const char *modeparm = M_GetNextParm();
		while (renderer_list[i].strvalue)
		{
			if (!stricmp(modeparm, renderer_list[i].strvalue))
			{
				chosenrendermode = renderer_list[i].value;
				break;
			}
			i++;
		}
	}

	// Choose Software renderer
	else if (M_CheckParm("-software"))
		chosenrendermode = render_soft;

#ifdef HWRENDER
	// Choose OpenGL renderer
	else if (M_CheckParm("-opengl"))
		chosenrendermode = render_opengl;

	// Don't startup OpenGL
	if (M_CheckParm("-nogl"))
	{
		vid.glstate = VID_GL_LIBRARY_ERROR;
		if (chosenrendermode == render_opengl)
			chosenrendermode = render_none;
	}
#endif

	if (chosenrendermode != render_none)
		rendermode = chosenrendermode;

	usesdl2soft = M_CheckParm("-softblit");

	//SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY>>1,SDL_DEFAULT_REPEAT_INTERVAL<<2);
	//VID_Command_ModeList_f();

#ifdef HWRENDER
	if (rendermode == render_opengl)
		VID_StartupOpenGL();
#endif

	// Window icon
#ifdef HAVE_IMAGE
	icoSurface = IMG_ReadXPMFromArray(SDL_icon_xpm);
#endif

	// Fury: we do window initialization after GL setup to allow
	// SDL_GL_LoadLibrary to work well on Windows

	// Create window
	//Impl_CreateWindow(USE_FULLSCREEN);
	//Impl_SetWindowName("SRB2 "VERSIONSTRING);
	VID_SetMode(VID_GetModeForSize(BASEVIDWIDTH, BASEVIDHEIGHT));

	vid.width = BASEVIDWIDTH; // Default size for startup
	vid.height = BASEVIDHEIGHT; // BitsPerPixel is the SDL interface's
	vid.recalc = true; // Set up the console stufff
	vid.direct = NULL; // Maybe direct access?
	vid.bpp = 1; // This is the game engine's Bpp
	vid.WndParent = NULL; //For the window?

#ifdef HAVE_TTF
	I_ShutdownTTF();
#endif

	VID_SetMode(VID_GetModeForSize(BASEVIDWIDTH, BASEVIDHEIGHT));

	if (M_CheckParm("-nomousegrab"))
		mousegrabok = SDL_FALSE;
#if 0 // defined (_DEBUG)
	else
	{
		char videodriver[4] = {'S','D','L',0};
		if (!M_CheckParm("-mousegrab") &&
		    *strncpy(videodriver, SDL_GetCurrentVideoDriver(), 4) != '\0' &&
		    strncasecmp("x11",videodriver,4) == 0)
			mousegrabok = SDL_FALSE; //X11's XGrabPointer not good
	}
#endif
	realwidth = (Uint16)vid.width;
	realheight = (Uint16)vid.height;

	//VID_Command_Info_f();
	SDLdoUngrabMouse();

	SDL_RaiseWindow(window);

	if (mousegrabok && !disable_mouse
#ifdef __EMSCRIPTEN__
		&& ShouldGrabMouse()
#endif
		)
		SDLdoGrabMouse();

	graphics_started = true;
}

void VID_StartupOpenGL(void)
{
#ifdef HWRENDER
	static boolean glstartup = false;
	if (!glstartup)
	{
		CONS_Printf("VID_StartupOpenGL()...\n");
		HWD.pfnInit             = hwSym("Init",NULL);
		HWD.pfnFinishUpdate     = NULL;
		HWD.pfnDraw2DLine       = hwSym("Draw2DLine",NULL);
		HWD.pfnDrawPolygon      = hwSym("DrawPolygon",NULL);
		HWD.pfnDrawIndexedTriangles = hwSym("DrawIndexedTriangles",NULL);
		HWD.pfnRenderSkyDome    = hwSym("RenderSkyDome",NULL);
		HWD.pfnSetBlend         = hwSym("SetBlend",NULL);
		HWD.pfnClearBuffer      = hwSym("ClearBuffer",NULL);
		HWD.pfnSetTexture       = hwSym("SetTexture",NULL);
		HWD.pfnUpdateTexture    = hwSym("UpdateTexture",NULL);
		HWD.pfnDeleteTexture    = hwSym("DeleteTexture",NULL);
		HWD.pfnReadScreenTexture= hwSym("ReadScreenTexture",NULL);
		HWD.pfnGClipRect        = hwSym("GClipRect",NULL);
		HWD.pfnClearMipMapCache = hwSym("ClearMipMapCache",NULL);
		HWD.pfnSetSpecialState  = hwSym("SetSpecialState",NULL);
		HWD.pfnSetTexturePalette= hwSym("SetTexturePalette",NULL);
		HWD.pfnGetTextureUsed   = hwSym("GetTextureUsed",NULL);
		HWD.pfnDrawModel        = hwSym("DrawModel",NULL);
		HWD.pfnCreateModelVBOs  = hwSym("CreateModelVBOs",NULL);
		HWD.pfnSetTransform     = hwSym("SetTransform",NULL);
		HWD.pfnPostImgRedraw    = hwSym("PostImgRedraw",NULL);
		HWD.pfnFlushScreenTextures=hwSym("FlushScreenTextures",NULL);
		HWD.pfnDoScreenWipe     = hwSym("DoScreenWipe",NULL);
		HWD.pfnDrawScreenTexture= hwSym("DrawScreenTexture",NULL);
		HWD.pfnMakeScreenTexture= hwSym("MakeScreenTexture",NULL);
		HWD.pfnDrawScreenFinalTexture=hwSym("DrawScreenFinalTexture",NULL);

		HWD.pfnInitShaders      = hwSym("InitShaders",NULL);
		HWD.pfnLoadShader       = hwSym("LoadShader",NULL);
		HWD.pfnCompileShader    = hwSym("CompileShader",NULL);
		HWD.pfnSetShader        = hwSym("SetShader",NULL);
		HWD.pfnUnSetShader      = hwSym("UnSetShader",NULL);

		HWD.pfnSetShaderInfo    = hwSym("SetShaderInfo",NULL);

		HWD.pfnSetPaletteLookup = hwSym("SetPaletteLookup",NULL);
		HWD.pfnCreateLightTable = hwSym("CreateLightTable",NULL);
		HWD.pfnUpdateLightTable = hwSym("UpdateLightTable",NULL);
		HWD.pfnClearLightTables = hwSym("ClearLightTables",NULL);
		HWD.pfnSetScreenPalette = hwSym("SetScreenPalette",NULL);

		vid.glstate = HWD.pfnInit() ? VID_GL_LIBRARY_LOADED : VID_GL_LIBRARY_ERROR; // let load the OpenGL library

		if (vid.glstate == VID_GL_LIBRARY_ERROR)
		{
			rendermode = render_soft;
			setrenderneeded = 0;
		}
		glstartup = true;
	}
#endif
}

void I_ShutdownGraphics(void)
{
	rendermode = render_none;
	V_FreeSoftwareColors();
#ifdef _WIN32
	windows_move_frame = NULL;
	if (windows_sizemove_window)
		KillTimer(windows_sizemove_window, SRB2_SIZEMOVE_TIMER_ID);
	windows_sizemove_window = NULL;
	windows_sizemove_active = false;
#endif
	if (icoSurface) SDL_FreeSurface(icoSurface);
	icoSurface = NULL;

	I_OutputMsg("I_ShutdownGraphics(): ");

	// was graphics initialized anyway?
	if (!graphics_started)
	{
		I_OutputMsg("graphics never started\n");
		return;
	}
	graphics_started = false;
	I_OutputMsg("shut down\n");

	Impl_DestroySoftwareContext();
	if (vid.buffer)
	{
		free(vid.buffer);
		vid.buffer = NULL;
		vid_buffer_capacity = 0;
	}

#ifdef HWRENDER
	if (sdlglcontext)
	{
		if (window && SDL_GL_GetCurrentContext() == sdlglcontext)
		{
			OglSdlReleaseRenderTarget();
			SDL_GL_MakeCurrent(window, NULL);
		}
		SDL_GL_DeleteContext(sdlglcontext);
		sdlglcontext = NULL;
	}
#endif
	if (window)
	{
		SDL_DestroyWindow(window);
		window = NULL;
	}
	SDL_QuitSubSystem(SDL_INIT_VIDEO);
	framebuffer = SDL_FALSE;
}
#endif

void I_GetCursorPosition(INT32 *x, INT32 *y)
{
	SDL_GetMouseState(x, y);
}

UINT32 I_GetRefreshRate(void)
{
	return refresh_rate;
}

boolean I_VSyncProvidesPacing(void)
{
#ifdef HWRENDER
	if (sdlglcontext != NULL && SDL_GL_GetCurrentContext() == sdlglcontext)
		return SDL_GL_GetSwapInterval() != 0 || OglSdlCompositorProvidesPacing();
#endif
	return renderer != NULL && rendermode == render_soft && cv_vidwait.value != 0;
}

boolean I_CompositorProvidesPacing(void)
{
#ifdef HWRENDER
	return sdlglcontext != NULL && SDL_GL_GetCurrentContext() == sdlglcontext
		&& OglSdlCompositorProvidesPacing();
#else
	return false;
#endif
}
