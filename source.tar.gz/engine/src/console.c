// SONIC ROBO BLAST 2
//-----------------------------------------------------------------------------
// Copyright (C) 1998-2000 by DooM Legacy Team.
// Copyright (C) 1999-2024 by Sonic Team Junior.
//
// This program is free software distributed under the
// terms of the GNU General Public License, version 2.
// See the 'LICENSE' file for more details.
//-----------------------------------------------------------------------------
/// \file  console.c
/// \brief Console drawing and input

#ifdef __GNUC__
#include <unistd.h>
#endif

#include "doomdef.h"
#include "console.h"
#include "g_game.h"
#include "g_input.h"
#include "hu_stuff.h"
#include "keys.h"
#include "r_main.h"
#include "r_defs.h"
#include "sounds.h"
#include "st_stuff.h"
#include "s_sound.h"
#include "v_video.h"
#include "i_video.h"
#include "z_zone.h"
#include "i_system.h"
#include "i_threads.h"
#include "d_main.h"
#include "m_menu.h"
#include "filesrch.h"
#include "m_misc.h"

#ifdef _WINDOWS
#include "win32/win_main.h"
#endif

#ifdef _WIN32
#include <shellapi.h>
#endif

#ifdef HWRENDER
#include "hardware/hw_main.h"
#endif

#define MAXHUDLINES 20

#ifdef HAVE_THREADS
I_mutex con_mutex;

#  define Lock_state()    I_lock_mutex(&con_mutex)
#  define Unlock_state() I_unlock_mutex(con_mutex)
#else/*HAVE_THREADS*/
#  define Lock_state()
#  define Unlock_state()
#endif/*HAVE_THREADS*/

static boolean con_started = false; // console has been initialised
       boolean con_startup = false; // true at game startup
       boolean con_refresh = false; // screen needs refreshing
static boolean con_forcepic = true; // at startup toggle console translucency when first off
       boolean con_recalc;          // set true when screen size has changed

static tic_t con_tick; // console ticker for blinking prompt cursor
                        // con_scrollup should use time (currenttime - lasttime)..

static boolean consoletoggle; // true when console key pushed, ticker will handle
static boolean consoleready;  // console prompt is ready

       INT32 con_destlines; // vid lines used by console at final position
static INT32 con_curlines;  // vid lines currently used by console

static UINT8  con_hudlines;             // number of console heads up message lines
static UINT32 con_hudtime[MAXHUDLINES]; // remaining time of display for hud msg lines

// console text output
static char *con_line;          // console text output current line
static size_t con_cx;
static size_t con_columns;
static size_t con_columns_used;
static size_t con_cy;           // cursor line number in con_buffer, is always
                                // increasing, and wrapped around in the text
                                // buffer using modulo.

static size_t con_totallines;      // lines of console text into the console buffer
static size_t con_width;           // columns of chars, depend on vid mode width
static size_t con_historylines;    // valid lines retained, including the current line

static size_t con_scrollup;        // how many rows of text to scroll up (pgup/pgdn)
static boolean con_scroll_drag;
static INT32 con_scroll_grab;
static INT32 con_mouse_x, con_mouse_y;
UINT32 con_scalefactor;            // text size scale factor

typedef struct
{
	size_t line, column;
} con_historypos_t;

static con_historypos_t con_selection_start, con_selection_end;
static boolean con_select_drag, con_select_moved;

static void CON_ClearHistorySelection(void)
{
	con_selection_start = con_selection_end = (con_historypos_t){0, 0};
	con_select_drag = con_select_moved = false;
}

// hold 32 last lines of input for history
#define CON_MAXPROMPTCHARS 256
#define CON_PROMPTCHAR '$'

static char inputlines[32][CON_MAXPROMPTCHARS]; // hold last 32 prompt lines

static INT32 inputline;    // current input line number
static INT32 inputhist;    // line number of history input line to restore
static size_t input_cur; // position of cursor in line
static size_t input_sel; // position of selection marker (I.E.: anything between this and input_cur is "selected")
static size_t input_len; // length of current line, used to bound cursor and such
// notice: input does NOT include the "$" at the start of the line. - 11/3/16

// protos.
static void CON_InputInit(void);
static void CON_RecalcSize(void);
static void CON_ChangeHeight(void);
static size_t CON_MaxScroll(void);

static void CON_DrawBackpic(void);
static void CONS_height_Change(void);
static void CONS_hudlines_Change(void);
static void CONS_backcolor_Change(void);

//======================================================================
//                   CONSOLE VARS AND COMMANDS
//======================================================================
#ifdef macintosh
#define CON_BUFFERSIZE 4096 // my compiler can't handle local vars >32k
#else
/* Keep a session-sized history without adding work to the per-frame drawer.
 * At common console widths this retains tens of thousands of lines. */
#define CON_BUFFERSIZE (8*1024*1024)
#endif


#define CON_ROW_EXTRA 13
static char con_buffer[CON_BUFFERSIZE];

// how many seconds the hud messages lasts on the screen
// CV_Unsigned can overflow when multiplied by TICRATE later, so let's use a 3-year limit instead
static CV_PossibleValue_t hudtime_cons_t[] = {{0, "MIN"}, {99999999, "MAX"}, {0, NULL}};
static consvar_t cons_hudtime = CVAR_INIT ("con_hudtime", "5", CV_SAVE, hudtime_cons_t, NULL);

// number of lines displayed on the HUD
static CV_PossibleValue_t hudlines_cons_t[] = {{0, "MIN"}, {MAXHUDLINES, "MAX"}, {0, NULL}};
static consvar_t cons_hudlines = CVAR_INIT ("con_hudlines", "5", CV_CALL|CV_SAVE, hudlines_cons_t, CONS_hudlines_Change);

// number of lines console move per frame
// (con_speed needs a limit, apparently)
static CV_PossibleValue_t speed_cons_t[] = {{0, "MIN"}, {64, "MAX"}, {0, NULL}};
static consvar_t cons_speed = CVAR_INIT ("con_speed", "8", CV_SAVE, speed_cons_t, NULL);

// percentage of screen height to use for console
static consvar_t cons_height = CVAR_INIT ("con_height", "50", CV_CALL|CV_SAVE, CV_Unsigned, CONS_height_Change);

// -1 preserves the traditional percentage height, 0 disables the console,
// and 1-64 selects the exact number of output rows to display.
static CV_PossibleValue_t lines_cons_t[] = {{-1, "MIN"}, {64, "MAX"}, {0, NULL}};
consvar_t cons_lines = CVAR_INIT ("con_lines", "-1", CV_CALL|CV_SAVE, lines_cons_t, CONS_height_Change);

static CV_PossibleValue_t backpic_cons_t[] = {{0, "Translucent"}, {1, "Picture"}, {2, "None"}, {0, NULL}};
// Whether to use the console picture, translucent tint, or no background.
consvar_t cons_backpic = CVAR_INIT ("con_backpic", "Translucent", CV_SAVE, backpic_cons_t, NULL);

static CV_PossibleValue_t backcolor_cons_t[] = {{0, "White"}, 		{1, "Black"},		{2, "Sepia"},
												{3, "Brown"},		{4, "Pink"},		{5, "Raspberry"},
												{6, "Red"},			{7, "Creamsicle"},	{8, "Orange"},
												{9, "Gold"},		{10,"Yellow"},		{11,"Emerald"},
												{12,"Green"},		{13,"Cyan"},		{14,"Steel"},
												{15,"Periwinkle"},	{16,"Blue"},		{17,"Purple"},
												{18,"Lavender"},
												{0, NULL}};


consvar_t cons_backcolor = CVAR_INIT ("con_backcolor", "Green", CV_CALL|CV_SAVE, backcolor_cons_t, CONS_backcolor_Change);

static void CON_Print(char *msg);

// Change the console height on demand
//
static void CONS_height_Change(void)
{
	Lock_state();

	if (con_destlines > 0 && !con_startup) // If the console is open (as in, not using "bind")...
		CON_ChangeHeight(); // ...update its height now, not only when it's closed and re-opened

	Unlock_state();
}

//
//
static void CONS_hudlines_Change(void)
{
	INT32 i;

	Lock_state();

	// Clear the currently displayed lines
	for (i = 0; i < con_hudlines; i++)
		con_hudtime[i] = 0;

	con_hudlines = cons_hudlines.value;

	Unlock_state();

	CONS_Printf(M_GetText("Number of console HUD lines is now %d\n"), con_hudlines);
}

// Clear console text buffer
//
static void CONS_Clear_f(void)
{
	Lock_state();

	CON_ClearHistorySelection();
	memset(con_buffer, 0, CON_BUFFERSIZE);

	con_cx = con_columns_used = 0;
	con_cy = con_totallines - 1;
	con_line = &con_buffer[con_cy*con_width];
	con_historylines = 1;
	con_scrollup = 0;

	Unlock_state();
}

// Choose english keymap
//
/*static void CONS_English_f(void)
{
	shiftxform = english_shiftxform;
	CONS_Printf(M_GetText("%s keymap.\n"), M_GetText("English"));
}*/

static char *bindtable[NUMINPUTS];

static void CONS_Bind_f(void)
{
	size_t na;
	char *newcmd = NULL;
	//size_t newlen = 0;
	unsigned int i;
	INT32 key;

	na = COM_Argc();

	if (na < 2)
	{
		CONS_Printf(M_GetText("bind <keyname> [<command>] [<arg1>] [...]: create shortcut keys to command(s)\n"));
		CONS_Printf("\x82%s", M_GetText("Bind table :\n"));
		na = 0;
		for (key = 0; key < NUMINPUTS; key++)
			if (bindtable[key])
			{
				CONS_Printf("%s : \"%s\"\n", G_KeyNumToName(key), bindtable[key]);
				na = 1;
			}
		if (!na)
			CONS_Printf(M_GetText("(empty)\n"));
		return;
	}

	key = G_KeyNameToNum(COM_Argv(1));
	if (key <= 0 || key >= NUMINPUTS)
	{
		CONS_Alert(CONS_NOTICE, M_GetText("Invalid key name\n"));
		return;
	}

	Z_Free(bindtable[key]);
	bindtable[key] = NULL;

	if (na < 3)
		return;

	for (i = 2; i < na; ++i)
	{
		const char *arg = COM_Argv(i);

		// on the second iteration, and after
		if (i > 2)
		{
			size_t newlen = strlen(bindtable[key]) + strlen(arg) + 1; // new length, allow space for ' ' and '\0'
			size_t curpos = newcmd - bindtable[key]; // offset from newcmd to original pointer

			newcmd = bindtable[key] = Z_Realloc(bindtable[key], newlen, PU_STATIC, NULL);
			newcmd += curpos; // reapply offset

			newcmd[0] = ' '; // replace previous '\0' w/ ' '
			++newcmd; // make sure later strcpy doesnt overwrite ' '
		}
		// first iteration
		else
			// allocate space for argument and a ' ' or '\0'
			newcmd = bindtable[key] = Z_Calloc(strlen(arg) + 1, PU_STATIC, NULL);

		// the copy
		strcpy(newcmd, arg);

		// move window past copied argument for next iteration
		newcmd += strlen(arg);
	}
}

//======================================================================
//                          CONSOLE SETUP
//======================================================================

// Font colormap colors
// TODO: This could probably be improved somehow...
// These colormaps are 99% identical, with just a few changed bytes
// This could EASILY be handled by modifying a centralised colormap
// for software depending on the prior state - but yknow, OpenGL...
UINT8 *yellowmap, *magentamap, *lgreenmap, *bluemap, *graymap, *redmap, *orangemap, *skymap, *purplemap, *aquamap, *peridotmap, *azuremap, *brownmap, *rosymap, *invertmap;

// Console BG color
UINT8 *consolebgmap = NULL;
UINT8 *promptbgmap = NULL;
static UINT8 promptbgcolor = UINT8_MAX;

void CON_SetupBackColormapEx(INT32 color, boolean prompt)
{
	UINT16 i, palsum;
	UINT8 j, palindex;
	UINT8 *pal = W_CacheLumpName(GetPalette(), PU_CACHE);
	INT32 shift = 6;

	if (color == INT32_MAX)
		color = cons_backcolor.value;

	shift = 6; // 12 colors -- shift of 7 means 6 colors

	switch (color)
	{
		case 0:		palindex = 15; 	break; 	// White
		case 1:		palindex = 31;	break; 	// Black
		case 2:		palindex = 251;	break;	// Sepia
		case 3:		palindex = 239;	break; 	// Brown
		case 4:		palindex = 215; shift = 7; 	break; 	// Pink
		case 5:		palindex = 37; shift = 7;	break; 	// Raspberry
		case 6:		palindex = 47; shift = 7;	break; 	// Red
		case 7:		palindex = 53;	shift = 7;	break;	// Creamsicle
		case 8:		palindex = 63;	break; 	// Orange
		case 9:		palindex = 56; shift = 7;	break; 	// Gold
		case 10:	palindex = 79; shift = 7;	break; 	// Yellow
		case 11:	palindex = 119; shift = 7; 	break; 	// Emerald
		case 12:	palindex = 111;	break; 	// Green
		case 13:	palindex = 136;	shift = 7; break; 	// Cyan
		case 14:	palindex = 175; shift = 7;	break; 	// Steel
		case 15:	palindex = 166;	shift = 7; 	break; 	// Periwinkle
		case 16:	palindex = 159;	break; 	// Blue
		case 17:	palindex = 187; shift = 7; 	break; 	// Purple
		case 18:	palindex = 199; shift = 7; 	break; 	// Lavender
		// Default green
		default:	palindex = 111; break;
	}

	if (prompt)
	{
		if (!promptbgmap)
			promptbgmap = (UINT8 *)Z_Malloc(256, PU_STATIC, NULL);

		if (color == promptbgcolor)
			return;
		else
			promptbgcolor = color;
	}
	else if (!consolebgmap)
		consolebgmap = (UINT8 *)Z_Malloc(256, PU_STATIC, NULL);

	// setup background colormap
	for (i = 0, j = 0; i < 768; i += 3, j++)
	{
		palsum = (pal[i] + pal[i+1] + pal[i+2]) >> shift;
		if (prompt)
			promptbgmap[j] = (UINT8)(palindex - palsum);
		else
			consolebgmap[j] = (UINT8)(palindex - palsum);
	}
}

void CON_SetupBackColormap(void)
{
	CON_SetupBackColormapEx(cons_backcolor.value, false);
	CON_SetupBackColormapEx(1, true); // default to gray
}

static void CONS_backcolor_Change(void)
{
	CON_SetupBackColormapEx(cons_backcolor.value, false);
}

static void CON_SetupColormaps(void)
{
	INT32 i;
	UINT8 *memorysrc = (UINT8 *)Z_Malloc((256*15), PU_STATIC, NULL);

	magentamap = memorysrc;
	yellowmap  = (magentamap+256);
	lgreenmap  = (yellowmap+256);
	bluemap    = (lgreenmap+256);
	redmap     = (bluemap+256);
	graymap    = (redmap+256);
	orangemap  = (graymap+256);
	skymap     = (orangemap+256);
	purplemap  = (skymap+256);
	aquamap    = (purplemap+256);
	peridotmap = (aquamap+256);
	azuremap   = (peridotmap+256);
	brownmap   = (azuremap+256);
	rosymap    = (brownmap+256);
	invertmap  = (rosymap+256);

	// setup the other colormaps, for console text

	// these don't need to be aligned, unless you convert the
	// V_DrawMappedPatch() into optimised asm.

	for (i = 0; i < (256*15); i++, ++memorysrc)
		*memorysrc = (UINT8)(i & 0xFF); // remap each color to itself...

#define colset(map, a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p) \
	map[0x0] = (UINT8)a;\
	map[0x1] = (UINT8)b;\
	map[0x2] = (UINT8)c;\
	map[0x3] = (UINT8)d;\
	map[0x4] = (UINT8)e;\
	map[0x5] = (UINT8)f;\
	map[0x6] = (UINT8)g;\
	map[0x7] = (UINT8)h;\
	map[0x8] = (UINT8)i;\
	map[0x9] = (UINT8)j;\
	map[0xA] = (UINT8)k;\
	map[0xB] = (UINT8)l;\
	map[0xC] = (UINT8)m;\
	map[0xD] = (UINT8)n;\
	map[0xE] = (UINT8)o;\
	map[0xF] = (UINT8)p;

	// Tried to keep the colors vanilla while adding some shades in between them ~SonicX8000

	//                      0x1       0x3                           0x9                           0xF
	colset(magentamap, 177, 177, 178, 178, 178, 180, 180, 180, 182, 182, 182, 182, 184, 184, 184, 185);
	colset(yellowmap,   82,  82,  73,  73,  73,  74,  74,  74,  66,  66,  66,  66,  67,  67,  67,  68);
	colset(lgreenmap,   96,  96,  98,  98,  98, 100, 100, 100, 103, 103, 103, 103, 105, 105, 105, 107);
	colset(bluemap,    146, 146, 147, 147, 147, 148, 148, 148, 149, 149, 149, 149, 150, 150, 150, 151);
	colset(redmap,      32,  32,  33,  33,  33,  34,  34,  34,  35,  35,  35,  35,  37,  37,  37,  39);
	colset(graymap,      8,   9,  10,  11,  12,  13,  14,  15,  16,  17,  18,  19,  20,  21,  22,  23);
	colset(orangemap,   50,  50,  52,  52,  52,  54,  54,  54,  56,  56,  56,  56,  59,  59,  59,  60);
	colset(skymap,     129, 129, 130, 130, 130, 131, 131, 131, 133, 133, 133, 133, 135, 135, 135, 136);
	colset(purplemap,  160, 160, 161, 161, 161, 162, 162, 162, 163, 163, 163, 163, 164, 164, 164, 165);
	colset(aquamap,    120, 120, 121, 121, 121, 122, 122, 122, 123, 123, 123, 123, 124, 124, 124, 125);
	colset(peridotmap,  73,  73, 188, 188, 188, 189, 189, 189, 190, 190, 190, 190, 191, 191, 191,  94);
	colset(azuremap,   144, 144, 145, 145, 145, 146, 146, 146, 170, 170, 170, 170, 171, 171, 171, 172);
	colset(brownmap,   219, 219, 221, 221, 221, 222, 222, 222, 224, 224, 224, 224, 227, 227, 227, 229);
	colset(rosymap,    200, 200, 201, 201, 201, 202, 202, 202, 203, 203, 203, 203, 204, 204, 204, 205);

#undef colset

	// Yeah just straight up invert it like a normal person
	for (i = 0x00; i <= 0x1F; i++)
		invertmap[0x1F - i] = i;

	// Init back colormap
	CON_SetupBackColormap();
}

// Setup the console text buffer
//
void CON_Init(void)
{
	INT32 i;

	for (i = 0; i < NUMINPUTS; i++)
		bindtable[i] = NULL;

	Lock_state();

	// clear all lines
	memset(con_buffer, 0, CON_BUFFERSIZE);

	// make sure it is ready for the loading screen
	con_width = 0;

	Unlock_state();

	CON_RecalcSize();

	CON_SetupColormaps();

	Lock_state();

	con_hudlines = atoi(cons_hudlines.defaultvalue);

	Unlock_state();

	// setup console input filtering
	CON_InputInit();

	// register our commands
	//
	COM_AddCommand("cls", CONS_Clear_f, 0);
	//COM_AddCommand("english", CONS_English_f);
	// set console full screen for game startup MAKE SURE VID_Init() done !!!
	Lock_state();

	con_destlines = vid.height;
	con_curlines = vid.height;

	Unlock_state();

	if (!dedicated)
	{
		Lock_state();

		con_started = true;
		con_startup = true;
		con_refresh = true; // needs explicit screen refresh until we are in the main game loop
		consoletoggle = false;

		Unlock_state();

		CV_RegisterVar(&cons_hudtime);
		CV_RegisterVar(&cons_hudlines);
		CV_RegisterVar(&cons_speed);
		CV_RegisterVar(&cons_height);
		CV_RegisterVar(&cons_lines);
		CV_RegisterVar(&cons_backpic);
		CV_RegisterVar(&cons_backcolor);
		COM_AddCommand("bind", CONS_Bind_f, 0);
	}
	else
	{
		Lock_state();

		con_started = true;
		con_startup = false;
		con_refresh = false; // disable explicit screen refresh
		consoletoggle = true;

		Unlock_state();
	}

	COM_AddCommand("these_arent_the_mods_youre_looking_for", G_SetGameNotModified, 0);
}

void CON_StartRefresh(void)
{
	if (con_startup)
		con_refresh = true;
}

void CON_StopRefresh(void)
{
	if (con_startup)
		con_refresh = false;
}

// Console input initialization
//
static void CON_InputInit(void)
{
	Lock_state();

	// prepare the first prompt line
	memset(inputlines, 0, sizeof (inputlines));
	inputline = 0;
	input_cur = input_sel = input_len = 0;

	Unlock_state();
}

//======================================================================
//                        CONSOLE EXECUTION
//======================================================================

// Called at screen size change to set the rows and line size of the
// console text buffer.
//
static void CON_RecalcSize(void)
{
	size_t columns;
	char *history = NULL;

	Lock_state();

	switch (cv_constextsize.value)
	{
	case V_NOSCALEPATCH:
		con_scalefactor = 1;
		break;
	case V_SMALLSCALEPATCH:
		con_scalefactor = vid.smalldup;
		break;
	case V_MEDSCALEPATCH:
		con_scalefactor = vid.meddup;
		break;
	default:
		con_scalefactor = vid.dup;
		break;
	}

	con_recalc = false;
	con_scalefactor = max(1, con_scalefactor);
	columns = dedicated ? 1 : max(8, (INT32)(vid.width / (8 * con_scalefactor)) - 2);

	if (con_startup)
		con_curlines = con_destlines = vid.height;
	else if (con_destlines > 0)
	{
		CON_ChangeHeight();
		con_curlines = con_destlines;
	}

	if (columns == con_columns)
	{
		Unlock_state();
		return;
	}


	CON_ClearHistorySelection();
	if (con_width)
	{
		history = Z_Malloc(con_historylines * con_width + 1, PU_STATIC, NULL);
		char *out = history;
		for (size_t i = con_cy + 1 - con_historylines; i <= con_cy; i++)
		{
			const char *line = &con_buffer[(i % con_totallines) * con_width];
			const size_t bytes = strlen(line);
			M_Memcpy(out, line, bytes);
			out += bytes;
			if (i < con_cy && !line[con_width - 1])
				*out++ = '\n';
		}
		*out = '\0';
	}

	con_columns = columns;
	con_width = columns + CON_ROW_EXTRA;
	con_totallines = CON_BUFFERSIZE / con_width;
	con_cx = con_columns_used = 0;
	con_cy = con_totallines - 1;
	con_line = &con_buffer[con_cy * con_width];
	memset(con_line, 0, con_width);
	con_historylines = 1;
	con_scrollup = 0;

	if (history)
	{
		CON_Print(history);
		Z_Free(history);
	}
	Unlock_state();
}
static size_t CON_MaxScroll(void)
{
	size_t visiblelines;
	INT32 minheight = 20 * (INT32)con_scalefactor;
	INT32 charheight = 8 * (INT32)con_scalefactor;

	if (con_curlines < minheight || charheight <= 0)
		return 0;

	visiblelines = (size_t)((con_curlines - minheight) / charheight) + 1;
	if (con_historylines <= visiblelines + 1)
		return 0;

	return con_historylines - visiblelines - 1;
}

static void CON_ChangeHeight(void)
{
	INT32 minheight;
	INT32 charheight;

	Lock_state();

	minheight = 20 * con_scalefactor;	// 20 = 8+8+4
	charheight = 8 * con_scalefactor;

	// toggle console in
	if (cons_lines.value == 0)
		con_destlines = 0;
	else if (cons_lines.value > 0)
		con_destlines = minheight + (cons_lines.value - 1) * charheight;
	else
		con_destlines = (cons_height.value*vid.height)/100;

	if (!con_destlines)
	{
		con_curlines = 0;
		consoleready = false;
		CON_ClearHistorySelection();
		CON_ClearHUD();
		I_UpdateMouseGrab();
		Unlock_state();
		return;
	}

	if (con_destlines < minheight)
		con_destlines = minheight;
	else if (con_destlines > vid.height)
		con_destlines = vid.height;

	con_destlines &= ~0x3; // multiple of text row height

	Unlock_state();
}

// Handles Console moves in/out of screen (per frame)
//
static void CON_MoveConsole(void)
{
	static fixed_t fracmovement = 0;

	Lock_state();

	// instant
	if (!cons_speed.value)
	{
		con_curlines = con_destlines;
		Unlock_state();
		return;
	}

	// Not instant - Increment fracmovement fractionally
	fracmovement += FixedMul(cons_speed.value*vid.fdup, renderdeltatics);

	if (con_curlines < con_destlines) // Move the console downwards
	{
		con_curlines += FixedInt(fracmovement); // Move by fracmovement's integer value
		if (con_curlines > con_destlines) // If we surpassed the destination...
			con_curlines = con_destlines; // ...clamp to it!
	}
	else // Move the console upwards
	{
		con_curlines -= FixedInt(fracmovement);
		if (con_curlines < con_destlines)
			con_curlines = con_destlines;

		if (con_destlines == 0) // If the console is being closed, not just moved up...
			con_tick = 0; // ...don't show the blinking cursor
	}

	fracmovement %= FRACUNIT; // Reset fracmovement's integer value, but keep the fraction

	Unlock_state();
}

// Clear time of console heads up messages
//
void CON_ClearHUD(void)
{
	INT32 i;

	Lock_state();

	for (i = 0; i < con_hudlines; i++)
		con_hudtime[i] = 0;

	Unlock_state();
}

// Force console to move out immediately
// note: con_ticker will set consoleready false
void CON_ToggleOff(void)
{
	Lock_state();

	if (!con_destlines)
	{
		Unlock_state();
		return;
	}

	con_destlines = 0;
	con_curlines = 0;
	CON_ClearHistorySelection();
	CON_ClearHUD();
	con_forcepic = 0;

	I_UpdateMouseGrab();

	Unlock_state();
}

boolean CON_Ready(void)
{
	boolean ready;
	Lock_state();
	{
		ready = consoleready;
	}
	Unlock_state();
	return ready;
}

// Console ticker: handles console move in/out, cursor blinking
//
void CON_Ticker(void)
{
	INT32 i;
	INT32 minheight;

	Lock_state();

	minheight = 20 * con_scalefactor;	// 20 = 8+8+4

	// cursor blinking
	con_tick++;
	con_tick &= 7;

	// console key was pushed
	if (consoletoggle)
	{
		consoletoggle = false;

		// toggle off console
		if (con_destlines > 0)
		{
			con_destlines = 0;
			CON_ClearHistorySelection();
			CON_ClearHUD();
			I_UpdateMouseGrab();
		}
		else
		{
			/* Reopening explicitly returns to the newest output. */
			con_scrollup = 0;
			CON_ChangeHeight();
			I_SetMouseGrab(false);
		}
	}

	// check if console ready for prompt
	if (con_destlines >= minheight)
		consoleready = true;
	else
		consoleready = false;

	// make overlay messages disappear after a while
	for (i = 0; i < con_hudlines; i++)
	{
		if (con_hudtime[i])
			con_hudtime[i]--;
	}

	Unlock_state();
}

//
// ----
//
// Shortcuts for adding and deleting characters, strings, and sections
// Necessary due to moving cursor
//

static void CON_InputClear(void)
{
	Lock_state();

	memset(inputlines[inputline], 0, CON_MAXPROMPTCHARS);
	input_cur = input_sel = input_len = 0;

	Unlock_state();
}

static void CON_InputSetString(const char *c)
{
	size_t newlen;

	Lock_state();

	/* c may point inside the current input line (history/autocomplete edits).
	 * Copying with strcpy after clearing the destination destroys that source,
	 * and strcpy itself is undefined for overlap. */
	newlen = strlen(c);
	if (newlen >= CON_MAXPROMPTCHARS)
		newlen = CON_MAXPROMPTCHARS - 1;
	memmove(inputlines[inputline], c, newlen);
	memset(inputlines[inputline] + newlen, 0, CON_MAXPROMPTCHARS - newlen);
	input_cur = input_sel = input_len = newlen;

	Unlock_state();
}

static void CON_InputAddString(const char *c)
{
	size_t csize = strlen(c);

	Lock_state();

	if (input_len + csize > CON_MAXPROMPTCHARS-1)
	{
		Unlock_state();
		return;
	}
	if (input_cur != input_len)
		memmove(&inputlines[inputline][input_cur+csize], &inputlines[inputline][input_cur], input_len-input_cur);
	memcpy(&inputlines[inputline][input_cur], c, csize);
	input_len += csize;
	input_sel = (input_cur += csize);

	Unlock_state();
}

static void CON_InputDelSelection(void)
{
	size_t start, end, len;

	Lock_state();

	if (input_cur > input_sel)
	{
		start = input_sel;
		end = input_cur;
	}
	else
	{
		start = input_cur;
		end = input_sel;
	}
	len = (end - start);

	if (end != input_len)
		memmove(&inputlines[inputline][start], &inputlines[inputline][end], input_len-end);
	memset(&inputlines[inputline][input_len - len], 0, len);

	input_len -= len;
	input_sel = input_cur = start;

	Unlock_state();
}

static void CON_InputAddChar(char c)
{
	if (input_len >= CON_MAXPROMPTCHARS-1)
		return;

	Lock_state();

	if (input_cur != input_len)
		memmove(&inputlines[inputline][input_cur+1], &inputlines[inputline][input_cur], input_len-input_cur);
	inputlines[inputline][input_cur++] = c;
	inputlines[inputline][++input_len] = 0;
	input_sel = input_cur;

	Unlock_state();
}

static void CON_InputDelChar(void)
{
	if (!input_cur)
		return;

	Lock_state();

	if (input_cur != input_len)
		memmove(&inputlines[inputline][input_cur-1], &inputlines[inputline][input_cur], input_len-input_cur);
	inputlines[inputline][--input_len] = 0;
	input_sel = --input_cur;

	Unlock_state();
}

typedef struct
{
	size_t first, last;
	INT32 top, charwidth;
} con_historyview_t;

static boolean CON_HistoryView(con_historyview_t *view)
{
	const INT32 height = con_curlines - 20 * (INT32)con_scalefactor;
	const INT32 charwidth = 8 * (INT32)con_scalefactor;
	if (height < 0 || charwidth <= 0 || con_historylines <= con_scrollup + 1)
		return false;

	const size_t rows = min((size_t)(1 + height / charwidth), con_historylines - con_scrollup - 1);
	view->last = con_cy - con_scrollup - 1;
	view->first = view->last + 1 - rows;
	view->top = height - (INT32)(rows - 1) * charwidth;
	view->charwidth = charwidth;
	return true;
}

static const UINT8 *CON_HistoryLine(size_t row)
{
	return (const UINT8 *)&con_buffer[(row % con_totallines) * con_width];
}

static size_t CON_HistoryColumns(size_t row)
{
	size_t columns = 0;
	for (const UINT8 *p = CON_HistoryLine(row); *p; p++)
		if (!(*p & 0x80)) columns++;
	return columns;
}

static boolean CON_HistorySelection(con_historypos_t *first, con_historypos_t *last)
{
	*first = con_selection_start;
	*last = con_selection_end;
	if (first->line > last->line || (first->line == last->line && first->column > last->column))
	{
		*first = con_selection_end;
		*last = con_selection_start;
	}
	return first->line >= con_cy + 1 - con_historylines && last->line < con_cy
		&& (first->line != last->line || first->column != last->column);
}

static boolean CON_HistoryPointer(con_historypos_t *position, boolean dragging)
{
	con_historyview_t view;
	if (!CON_HistoryView(&view))
		return false;

	const INT32 bottom = view.top + (INT32)(view.last + 1 - view.first) * view.charwidth;
	if (con_mouse_y < view.top)
	{
		*position = (con_historypos_t){view.first, 0};
		return dragging;
	}
	if (con_mouse_y >= bottom)
	{
		*position = (con_historypos_t){view.last, CON_HistoryColumns(view.last)};
		return dragging;
	}
	if (!dragging && (con_mouse_x < 0 || con_mouse_x >= vid.width))
		return false;

	position->line = view.first + (size_t)((con_mouse_y - view.top) / view.charwidth);
	const INT32 column = (con_mouse_x - view.charwidth / 2) / view.charwidth;
	position->column = min((size_t)max(0, column), CON_HistoryColumns(position->line));
	return true;
}

static void CON_UpdateHistoryDrag(void)
{
	con_historypos_t position;
	if (con_select_drag && CON_HistoryPointer(&position, true))
	{
		con_select_moved |= position.line != con_selection_start.line || position.column != con_selection_start.column;
		con_selection_end = position;
	}
}

static void CON_CopyHistorySelection(void)
{
	con_historypos_t first, last;
	Lock_state();
	if (!CON_HistorySelection(&first, &last))
	{
		Unlock_state();
		return;
	}

	char *text = Z_Malloc((last.line + 1 - first.line) * con_width + 1, PU_STATIC, NULL);
	char *out = text;
	for (size_t row = first.line; row <= last.line; row++)
	{
		const UINT8 *line = CON_HistoryLine(row);
		const size_t start = row == first.line ? first.column : 0;
		const size_t end = row == last.line ? last.column : con_columns;
		size_t column = 0;
		for (const UINT8 *p = line; *p && column < end; p++)
		{
			if (*p & 0x80) continue;
			if (column >= start) *out++ = (char)*p;
			column++;
		}

		if (row < last.line && !line[con_width - 1])
			*out++ = '\n';
	}
	Unlock_state();
	if (out != text)
		I_ClipboardCopy(text, (size_t)(out - text));
	Z_Free(text);
}


static void CON_OpenURLAtCursor(size_t row, size_t column)
{
	char line[1024];
	char url[1024];
	size_t raw, plain = 0, start, end;
#ifdef _WIN32
	HINSTANCE opened;
#endif

	Lock_state();
	const UINT8 *source = CON_HistoryLine(row);
	for (raw = 0; source[raw] && plain+1 < sizeof line; raw++)
	{
		if (!(source[raw] & 0x80))
			line[plain++] = (char)source[raw];
	}
	line[plain] = '\0';
	Unlock_state();

	for (start = 0; start < plain; start++)
	{
		if (strnicmp(&line[start], "https://", 8)
		 && strnicmp(&line[start], "http://", 7))
			continue;
		for (end = start; end < plain && line[end] > ' '; end++)
			;
		while (end > start && strchr(".,;:!?)]}>\"'", line[end-1]))
			end--;
		if (column >= start && column < end)
		{
			size_t length = min(end-start, sizeof url-1);
			memcpy(url, &line[start], length);
			url[length] = '\0';
#ifdef _WIN32
			opened = ShellExecuteA(NULL, "open", url, NULL, NULL, SW_SHOWNORMAL);
			if ((INT_PTR)opened > 32)
			{
				CONS_Printf("Opened link: %s\n", url);
				return;
			}
#endif
			I_ClipboardCopy(url, strlen(url));
			CONS_Printf("Could not open the link, so it was copied: %s\n", url);
			return;
		}
		start = end;
	}
}

//
// ----
//

// Handles console key input
//
static boolean CON_Scrollbar(INT32 *x, INT32 *height, INT32 *width, INT32 *range, INT32 *top, INT32 *thumb)
{
	const INT32 fontScale = con_scalefactor;
	const INT32 history = (INT32)CON_MaxScroll();
	*height = con_curlines - 16 * fontScale;
	if (!consoleready || con_startup || !history || *height <= 1 || fontScale <= 0)
		return false;

	const INT32 visible = 1 + (con_curlines - 20 * fontScale) / (8 * fontScale);
	*width = max(4, 4 * fontScale);
	*x = vid.width - *width - 2;
	*range = history;
	*thumb = V_ScrollbarThumb(*height, history, visible, history - (INT32)min((size_t)history, con_scrollup), top);
	return true;
}

static void CON_DragScrollbar(INT32 y, INT32 height, INT32 range, INT32 thumb)
{
	con_scrollup = (size_t)(range - V_ScrollbarValue(y - con_scroll_grab, height - thumb, range));
}

static boolean CON_ScrollbarInput(const event_t *ev)
{
	if (!consoleready || ev->type == ev_keyup)
	{
		if (ev->key == KEY_MOUSE1 || !consoleready)
			con_scroll_drag = false;
		return false;
	}

	const boolean press = ev->type == ev_keydown && ev->key == KEY_MOUSE1;
	if (ev->type == ev_mouseabsolute)
	{
		con_mouse_x = ev->x;
		con_mouse_y = ev->y;
	}
	else if (!press)
		return false;

	if (!press && !con_scroll_drag)
		return false;

	INT32 x, height, width, range, top, thumb;
	if (!CON_Scrollbar(&x, &height, &width, &range, &top, &thumb))
	{
		con_scroll_drag = false;
		return false;
	}

	if (press)
	{
		if (con_mouse_x < x || con_mouse_x >= x + width || con_mouse_y < 0 || con_mouse_y >= height)
			return false;
		con_scroll_drag = true;
		if (con_mouse_y >= top && con_mouse_y < top + thumb)
		{
			con_scroll_grab = con_mouse_y - top;
			return true;
		}
		con_scroll_grab = thumb / 2;
	}

	CON_DragScrollbar(con_mouse_y, height, range, thumb);
	return true;
}

static boolean CON_HistorySelectionInput(const event_t *ev)
{
	if (!consoleready)
		return false;
	if (ev->type == ev_mouseabsolute && con_select_drag)
	{
		CON_UpdateHistoryDrag();
		return true;
	}
	if (ev->key != KEY_MOUSE1)
		return false;
	if (ev->type == ev_keydown)
	{
		con_historypos_t position;
		CON_ClearHistorySelection();
		if (CON_HistoryPointer(&position, false))
		{
			con_selection_start = con_selection_end = position;
			con_select_drag = true;
			input_sel = input_cur;
		}
		return true;
	}
	if (ev->type == ev_keyup && con_select_drag)
	{
		CON_UpdateHistoryDrag();
		con_select_drag = false;
		const INT32 charwidth = (INT32)con_scalefactor * 8;
		if (!con_select_moved && con_mouse_x >= charwidth
			&& con_selection_start.line >= con_cy + 1 - con_historylines)
		{
			CON_OpenURLAtCursor(con_selection_start.line, (size_t)((con_mouse_x - charwidth) / charwidth));
		}
		return true;
	}
	return false;
}


boolean CON_Responder(event_t *ev)
{
	// sequential completions a la 4dos
	static char completioncmd[80 + sizeof("find ")] = "find ";
	static char *completion = &completioncmd[sizeof("find ")-1];

	static INT32 skips;

	static INT32   com_skips;
	static INT32   var_skips;
	static INT32 alias_skips;

	const char *cmd = NULL;
	INT32 key;

	if (chat_on)
		return false;

	if (CON_ScrollbarInput(ev) || CON_HistorySelectionInput(ev))
		return true;

	// let go keyup events, don't eat them
	if (ev->type != ev_keydown && ev->type != ev_text && ev->type != ev_console)
	{
		return false;
	}

	key = ev->key;

	// check for console toggle key
	if (ev->type == ev_keydown)
	{
		if (modeattacking || metalrecording || marathonmode)
			return false;

		if ((key == gamecontrol[GC_CONSOLE][0] || key == gamecontrol[GC_CONSOLE][1]) && !shiftdown)
		{
			I_SetTextInputMode(con_destlines == 0); // inverse, since this is changed next tic.
			consoletoggle = true;
			return true;
		}

		// check other keys only if console prompt is active
		if (!consoleready && key < NUMINPUTS) // metzgermeister: boundary check!!
		{
			if (!menuactive && bindtable[key])
			{
				COM_BufAddText(bindtable[key]);
				COM_BufAddText("\n");
				return true;
			}
			return false;
		}

		// escape key toggle off console
		if (key == KEY_ESCAPE)
		{
			I_SetTextInputMode(false);
			consoletoggle = true;
			return true;
		}
	}
	else if (ev->type == ev_text)
	{
		if (!consoletoggle && consoleready)
		{
			CON_ClearHistorySelection();
			CON_InputAddChar(key);
		}
		return true;
	}

	// Always eat ctrl/shift/alt if console open, so the menu doesn't get ideas
	if (key == KEY_LSHIFT || key == KEY_RSHIFT
	 || key == KEY_LCTRL || key == KEY_RCTRL
	 || key == KEY_LALT || key == KEY_RALT)
		return true;

	if (key == KEY_LEFTARROW)
	{
		if (input_cur != 0)
		{
			if (ctrldown)
				input_cur = M_JumpWordReverse(inputlines[inputline], input_cur);
			else
				--input_cur;
		}
		if (!shiftdown)
			input_sel = input_cur;
		return true;
	}
	else if (key == KEY_RIGHTARROW)
	{
		if (input_cur < input_len)
		{
			if (ctrldown)
				input_cur += M_JumpWord(&inputlines[inputline][input_cur]);
			else
				++input_cur;
		}
		if (!shiftdown)
			input_sel = input_cur;
		return true;
	}

	// backspace and delete command prompt
	if (input_sel != input_cur)
	{
		if (key == KEY_BACKSPACE || key == KEY_DEL)
		{
			CON_InputDelSelection();
			return true;
		}
	}
	else if (key == KEY_BACKSPACE)
	{
		if (ctrldown && input_cur != 0)
		{
			input_sel = M_JumpWordReverse(inputlines[inputline], input_cur);
			CON_InputDelSelection();
		}
		else
			CON_InputDelChar();
		return true;
	}
	else if (key == KEY_DEL)
	{
		if (input_cur == input_len)
			return true;

		if (ctrldown)
		{
			input_sel = input_cur + M_JumpWord(&inputlines[inputline][input_cur]);
			CON_InputDelSelection();
		}
		else
		{
			++input_cur;
			CON_InputDelChar();
		}
		return true;
	}

	// ctrl modifier -- changes behavior, adds shortcuts
	if (ctrldown)
	{
		// show all cvars/commands that match what we have inputted
		if (key == KEY_TAB)
		{
			if (!completion[0])
			{
				if (!input_len || input_len >= 40 || strchr(inputlines[inputline], ' '))
					return true;
				strcpy(completion, inputlines[inputline]);
			}
			COM_BufInsertText(completioncmd);
			completion[0] = 0;
			return true;
		}
		// ---

		if (key == KEY_HOME) // oldest text in buffer
		{
			con_scrollup = CON_MaxScroll();
			return true;
		}
		else if (key == KEY_END) // most recent text in buffer
		{
			con_scrollup = 0;
			return true;
		}

		if (key == 'x' || key == 'X')
		{
			if (input_sel == input_cur) // Don't replace the clipboard without a text selection
				return true;
			else if (input_sel > input_cur)
				I_ClipboardCopy(&inputlines[inputline][input_cur], input_sel-input_cur);
			else
				I_ClipboardCopy(&inputlines[inputline][input_sel], input_cur-input_sel);
			CON_InputDelSelection();
			completion[0] = 0;
			return true;
		}
		else if (key == 'c' || key == 'C')
		{
			if (input_sel == input_cur)
				CON_CopyHistorySelection();
			else if (input_sel > input_cur)
				I_ClipboardCopy(&inputlines[inputline][input_cur], input_sel-input_cur);
			else
				I_ClipboardCopy(&inputlines[inputline][input_sel], input_cur-input_sel);
			return true;
		}
		else if (key == 'v' || key == 'V')
		{
			CON_ClearHistorySelection();
			const char *paste = I_ClipboardPaste();
			if (input_sel != input_cur)
				CON_InputDelSelection();
			if (paste != NULL)
				CON_InputAddString(paste);
			completion[0] = 0;
			return true;
		}

		// Select all
		if (key == 'a' || key == 'A')
		{
			CON_ClearHistorySelection();
			input_sel = 0;
			input_cur = input_len;
			return true;
		}

		// ...why shouldn't it eat the key? if it doesn't, it just means you
		// can control Sonic from the console, which is silly
		return true;//return false;
	}

	// command completion forward (tab) and backward (shift-tab)
	if (key == KEY_TAB)
	{
		// sequential command completion forward and backward

		// remember typing for several completions (a-la-4dos)
		if (!completion[0])
		{
			if (!input_len || input_len >= 40 || strchr(inputlines[inputline], ' '))
				return true;
			strcpy(completion, inputlines[inputline]);
			skips       = 0;
			com_skips   = 0;
			var_skips   = 0;
			alias_skips = 0;
		}
		else
		{
			if (shiftdown)
			{
				if (skips > 0)
					skips--;
			}
			else
			{
				skips++;
			}
		}

		if (skips <= com_skips)
		{
			cmd = COM_CompleteCommand(completion, skips);

			if (cmd && skips == com_skips)
			{
				com_skips  ++;
				var_skips  ++;
				alias_skips++;
			}
		}

		if (!cmd && skips <= var_skips)
		{
			cmd = CV_CompleteVar(completion, skips - com_skips);

			if (cmd && skips == var_skips)
			{
				var_skips  ++;
				alias_skips++;
			}
		}

		if (!cmd && skips <= alias_skips)
		{
			cmd = COM_CompleteAlias(completion, skips - var_skips);

			if (cmd && skips == alias_skips)
			{
				alias_skips++;
			}
		}

		if (cmd)
		{
			CON_InputSetString(va("%s ", cmd));
		}
		else
		{
			skips--;
		}

		return true;
	}

	// Mouse wheel scrolls history without changing or submitting the prompt.
 if (key == KEY_MOUSEWHEELUP || key == KEY_MOUSEWHEELDOWN)
 {
  size_t maximum = CON_MaxScroll();
  if (key == KEY_MOUSEWHEELUP) con_scrollup = min(maximum, con_scrollup+3);
  else con_scrollup = con_scrollup > 3 ? con_scrollup-3 : 0;
  CON_UpdateHistoryDrag();
  return true;
 }

 // move up (backward) in console textbuffer
	if (key == KEY_PGUP)
	{
		if (con_scrollup < CON_MaxScroll())
			con_scrollup++;
		return true;
	}
	else if (key == KEY_PGDN)
	{
		if (con_scrollup > 0)
			con_scrollup--;
		return true;
	}
	else if (key == KEY_HOME)
	{
		input_cur = 0;
		if (!shiftdown)
			input_sel = input_cur;
		return true;
	}
	else if (key == KEY_END)
	{
		input_cur = input_len;
		if (!shiftdown)
			input_sel = input_cur;
		return true;
	}

	// At this point we're messing with input
	// Clear completion
	completion[0] = 0;

	// command enter
	if (key == KEY_ENTER)
	{
		if (!input_len)
			return true;

		// push the command
		COM_BufAddText(inputlines[inputline]);
		COM_BufAddText("\n");

		CONS_Printf("\x86""%c""\x80""%s\n", CON_PROMPTCHAR, inputlines[inputline]);

		inputline = (inputline+1) & 31;
		inputhist = inputline;
		CON_InputClear();

		return true;
	}

	// move back in input history
	if (key == KEY_UPARROW)
	{
		// copy one of the previous inputlines to the current
		do
			inputhist = (inputhist - 1) & 31; // cycle back
		while (inputhist != inputline && !inputlines[inputhist][0]);

		// stop at the last history input line, which is the
		// current line + 1 because we cycle through the 32 input lines
		if (inputhist == inputline)
			inputhist = (inputline + 1) & 31;

		CON_InputSetString(inputlines[inputhist]);
		return true;
	}

	// move forward in input history
	if (key == KEY_DOWNARROW)
	{
		if (inputhist == inputline)
			return true;
		do
			inputhist = (inputhist + 1) & 31;
		while (inputhist != inputline && !inputlines[inputhist][0]);

		// back to currentline
		if (inputhist == inputline)
			CON_InputClear();
		else
			CON_InputSetString(inputlines[inputhist]);
		return true;
	}

	// allow people to use keypad in console (good for typing IP addresses) - Calum
	if (key >= KEY_KEYPAD7 && key <= KEY_KPADDEL)
	{
		char keypad_translation[] = {'7','8','9','-',
		                             '4','5','6','+',
		                             '1','2','3',
		                             '0','.'};

		key = keypad_translation[key - KEY_KEYPAD7];
	}
	else if (key == KEY_KPADSLASH)
		key = '/';

	// enter a char into the command prompt
	if (key < 32 || key > 127)
		return true;

	if (input_sel != input_cur)
		CON_InputDelSelection();
	if (ev->type == ev_console)
		CON_InputAddChar(key);

	return true;
}

// Insert a new line in the console text buffer
//
static void CON_Linefeed(boolean wrapped)
{
	if (con_hudlines)
		con_hudtime[con_cy % con_hudlines] = cons_hudtime.value * TICRATE;

	con_line[con_width - 1] = wrapped;
	con_cy++;
	con_cx = con_columns_used = 0;
	if (con_historylines < con_totallines)
		con_historylines++;

	con_line = &con_buffer[(con_cy % con_totallines) * con_width];
	memset(con_line, 0, con_width);
}

static void CON_WrapLine(UINT8 color)
{
	CON_Linefeed(true);
	if (color != 0x80)
		con_line[con_cx++] = (char)color;
}

static void CON_PrintCharacter(UINT8 key, UINT8 color)
{
	if (con_columns_used == con_columns || con_cx >= con_width - 2)
		CON_WrapLine(color);
	con_line[con_cx++] = (char)key;
	con_columns_used++;
}


static void CON_Print(char *text)
{
	UINT8 *msg = (UINT8 *)text;
	UINT8 color = 0x80;

	if (!msg)
		return;

	if (*msg == '\3' || *msg == '\4')
	{
		if (*msg == '\4')
			color = *msg = 0x82;
		S_StartSound(NULL, sfx_radio);
	}

	Lock_state();
	const size_t oldscroll = con_scrollup;
	const size_t oldcy = con_cy;

	if (!(*msg & 0x80) && con_cx)
	{
		if (con_cx >= con_width - 2)
			CON_WrapLine(color);
		con_line[con_cx++] = (char)color;
	}

	while (*msg)
	{
		if (*msg & 0x80)
		{
			color = *msg++;
			if (con_cx >= con_width - 2)
				CON_Linefeed(true);
			con_line[con_cx++] = (char)color;
		}
		else if (*msg == '\r' || *msg == '\n')
		{
			if (*msg++ == '\r')
			{
				memset(con_line, 0, con_width);
				con_cx = con_columns_used = 0;
				color = 0x80;
			}
			else
			{
				CON_Linefeed(false);
				if (color != 0x80)
					con_line[con_cx++] = (char)color;
			}
		}
		else if (*msg == ' ' || *msg == '\t')
		{
			size_t spaces = *msg++ == '\t' ? 4 - (con_columns_used % 4) : 1;
			while (spaces--)
				CON_PrintCharacter(' ', color);
		}
		else if (*msg > ' ')
		{
			size_t length = 0;
			while (length < con_columns && msg[length] > ' ' && !(msg[length] & 0x80))
				length++;
			if (con_columns_used + length > con_columns)
				CON_WrapLine(color);
			while (length--)
				CON_PrintCharacter(*msg++, color);
		}
		else
			msg++;
	}

	if (oldscroll && con_cy > oldcy)
		con_scrollup = min(oldscroll + (con_cy - oldcy), CON_MaxScroll());

	Unlock_state();
}
void CON_LogMessage(const char *msg)
{
	char txt[8192], *t;
	const char *p = msg, *e = txt+sizeof (txt)-2;

	for (t = txt; *p != '\0'; p++)
	{
		if (*p == '\n' || *p >= ' ') // don't log or console print CON_Print's control characters
			*t++ = *p;

		if (t >= e)
		{
			*t = '\0'; //end of string
			I_OutputMsg("%s", txt); //print string
			t = txt; //reset t pointer
			memset(txt,'\0', sizeof (txt)); //reset txt
		}
	}
	*t = '\0'; //end of string
	I_OutputMsg("%s", txt);
}

// Console print! Wahooo! Lots o fun!
//

void CONS_Printf(const char *fmt, ...)
{
	va_list argptr;
	static char *txt = NULL;
	boolean refresh;

	if (txt == NULL)
		txt = malloc(8192);
	if (txt == NULL)
		return;

	va_start(argptr, fmt);
	vsnprintf(txt, 8192, fmt, argptr);
	va_end(argptr);

	// echo console prints to log file
	DEBFILE(txt);

	// write message in con text buffer
	if (con_started)
		CON_Print(txt);

	CON_LogMessage(txt);

	Lock_state();

	refresh = con_refresh;

	Unlock_state();

	// if not in display loop, force screen update
	if (refresh)
	{
		CON_Drawer(); // here we display the console text
		I_FinishUpdate(); // page flip or blit buffer
	}
}

void CONS_Alert(alerttype_t level, const char *fmt, ...)
{
	va_list argptr;
	static char *txt = NULL;

	if (txt == NULL)
		txt = malloc(8192);
	if (txt == NULL)
		return;

	va_start(argptr, fmt);
	vsnprintf(txt, 8192, fmt, argptr);
	va_end(argptr);

	switch (level)
	{
		case CONS_NOTICE:
			// no notice for notices, hehe
			CONS_Printf("\x83" "%s" "\x80 ", M_GetText("NOTICE:"));
			break;
		case CONS_WARNING:
			refreshdirmenu |= REFRESHDIR_WARNING;
			CONS_Printf("\x82" "%s" "\x80 ", M_GetText("WARNING:"));
			break;
		case CONS_ERROR:
			refreshdirmenu |= REFRESHDIR_ERROR;
			CONS_Printf("\x85" "%s" "\x80 ", M_GetText("ERROR:"));
			break;
	}

	// I am lazy and I feel like just letting CONS_Printf take care of things.
	// Is that okay?
	CONS_Printf("%s", txt);
}

void CONS_Debug(INT32 debugflags, const char *fmt, ...)
{
	va_list argptr;
	static char *txt = NULL;

	if ((cv_debug & debugflags) != debugflags)
		return;

	if (txt == NULL)
		txt = malloc(8192);
	if (txt == NULL)
		return;

	va_start(argptr, fmt);
	vsnprintf(txt, 8192, fmt, argptr);
	va_end(argptr);

	// Again I am lazy, oh well
	CONS_Printf("%s", txt);
}


// Print an error message, and wait for ENTER key to continue.
// To make sure the user has seen the message
//
void CONS_Error(const char *msg)
{
#if defined(RPC_NO_WINDOWS_H) && defined(_WINDOWS)
	if (!graphics_started)
	{
		MessageBoxA(vid.WndParent, msg, "SRB2 Warning", MB_OK);
		return;
	}
#endif
	CONS_Printf("\x82%s", msg); // write error msg in different colour
	CONS_Printf(M_GetText("Press ENTER to continue\n"));

	// dirty quick hack, but for the good cause
	while (I_GetKey() != KEY_ENTER)
		I_OsPolling();
}

//======================================================================
//                          CONSOLE DRAW
//======================================================================

// draw console prompt line
//
static void CON_DrawInput(void)
{
	INT32 charwidth = (INT32)con_scalefactor << 3;
	const char *p = inputlines[inputline];
	size_t c, clen, cend;
	UINT8 lellip = 0, rellip = 0;
	INT32 x, y, i;

	y = con_curlines - 12 * con_scalefactor;
	x = charwidth*2;

	clen = con_columns - 2;

	if (input_len <= clen)
	{
		c = 0;
		clen = input_len;
	}
	else // input line scrolls left if it gets too long
	{
		clen -= 2; // There will always be some extra truncation -- but where is what we'll find out

		if (input_cur <= clen/2)
		{
			// Close enough to right edge to show all
			c = 0;
			// Always will truncate right side from this position, so always draw right ellipsis
			rellip = 1;
		}
		else
		{
			// Cursor in the middle (or right side) of input
			// Move over for the ellipsis
			c = input_cur - (clen/2) + 2;
			x += charwidth*2;
			lellip = 1;

			if (c + clen >= input_len)
			{
				// Cursor in the right side of input
				// We were too far over, so move back
				c = input_len - clen;
			}
			else
			{
				// Cursor in the middle -- ellipses on both sides
				clen -= 2;
				rellip = 1;
			}
		}
	}

	if (lellip)
	{
		x -= charwidth*3;
		if (input_sel < c)
			V_DrawFill(x, y, charwidth*3, (10 * con_scalefactor), 77 | V_NOSCALESTART);
		for (i = 0; i < 3; ++i, x += charwidth)
			V_DrawCharacter(x, y, '.' | cv_constextsize.value | V_GRAYMAP | V_NOSCALESTART, true);
	}
	else
		V_DrawCharacter(x-charwidth, y, CON_PROMPTCHAR | cv_constextsize.value | V_GRAYMAP | V_NOSCALESTART, true);

	for (cend = c + clen; c < cend; ++c, x += charwidth)
	{
		if ((input_sel > c && input_cur <= c) || (input_sel <= c && input_cur > c))
		{
			V_DrawFill(x, y, charwidth, (10 * con_scalefactor), 77 | V_NOSCALESTART);
			V_DrawCharacter(x, y, p[c] | cv_constextsize.value | V_YELLOWMAP | V_NOSCALESTART, true);
		}
		else
			V_DrawCharacter(x, y, p[c] | cv_constextsize.value | V_NOSCALESTART, true);

		if (c == input_cur && con_tick >= 4)
			V_DrawCharacter(x, y + (con_scalefactor*2), '_' | cv_constextsize.value | V_NOSCALESTART, true);
	}
	if (cend == input_cur && con_tick >= 4)
		V_DrawCharacter(x, y + (con_scalefactor*2), '_' | cv_constextsize.value | V_NOSCALESTART, true);
	if (rellip)
	{
		if (input_sel > cend)
			V_DrawFill(x, y, charwidth*3, (10 * con_scalefactor), 77 | V_NOSCALESTART);
		for (i = 0; i < 3; ++i, x += charwidth)
			V_DrawCharacter(x, y, '.' | cv_constextsize.value | V_GRAYMAP | V_NOSCALESTART, true);
	}
}

// draw the last lines of console text to the top of the screen
static void CON_DrawHistoryLine(size_t row, INT32 x, INT32 y, INT32 charwidth)
{
	const UINT8 *p = CON_HistoryLine(row);
	INT32 color = 0;

	for (; *p; p++)
	{
		if (*p & 0x80)
			color = (*p & 0x7f) << V_CHARCOLORSHIFT;
		else
		{
			if (*p >= FONTSTART)
				V_DrawCharacter(x, y, *p | color | cv_constextsize.value | V_NOSCALESTART, true);
			x += charwidth;
		}
	}
}

static void CON_DrawHudlines(void)
{
	if (!con_hudlines)
		return;

	const INT32 charsize = 8 * con_scalefactor;
	INT32 y = (chat_on && OLDCHAT) ? charsize : 0;
	const size_t shown = min(con_hudlines + 1, con_historylines);
	for (size_t i = con_cy + 1 - shown; i <= con_cy; i++)
	{
		if (!con_hudtime[i % con_hudlines])
			continue;
		CON_DrawHistoryLine(i, 0, y, charsize);
		y += charsize;
	}
}
// Lactozilla: Draws the console's background picture.
static void CON_DrawBackpic(void)
{
	patch_t *con_backpic;
	lumpnum_t piclump;
	int x, w, h;

	// Get the lumpnum for CONSBACK, STARTUP (Only during game startup) or fallback into MISSING.
	if (con_startup)
		piclump = W_CheckNumForPatchName("STARTUP");
	else
		piclump = W_CheckNumForPatchName("CONSBACK");

	if (piclump == LUMPERROR)
		piclump = W_GetNumForPatchName("MISSING");

	// Cache the patch.
	con_backpic = W_CachePatchNum(piclump, PU_PATCH);
	if (con_backpic == NULL)
		return;

	// Center the backpic, and draw a vertically cropped patch.
	w = con_backpic->width * vid.dup;
	x = (vid.width / 2) - (w / 2);
	h = con_curlines/vid.dup;

	// If the patch doesn't fill the entire screen,
	// then fill the sides with a solid color.
	if (x > 0)
	{
		column_t *column = &con_backpic->columns[0];
		if (column->num_posts && !column->posts[0].topdelta)
		{
			UINT8 *source = column->pixels;
			INT32 color = (source[0] | V_NOSCALESTART);
			// left side
			V_DrawFill(0, 0, x, con_curlines, color);
			// right side
			V_DrawFill((x + w), 0, (vid.width - w), con_curlines, color);
		}
	}

	// Draw the patch.
	V_DrawCroppedPatch(x << FRACBITS, 0, FRACUNIT, FRACUNIT, V_NOSCALESTART, con_backpic, NULL,
			0, (BASEVIDHEIGHT - h) << FRACBITS, BASEVIDWIDTH << FRACBITS, h << FRACBITS);

	// Unlock the cached patch.
	W_UnlockCachedPatch(con_backpic);
}

// draw the console background, text, and prompt if enough place
//
static void CON_DrawConsole(void)
{
	con_historyview_t view;

	if (con_curlines <= 0)
		return;

	// draw console background
	if (cons_backpic.value == 1 || con_forcepic)
		CON_DrawBackpic();
	else if (cons_backpic.value == 0)
	{
		// inu: no more width (was always 0 and vid.width)
		if (rendermode != render_none)
			V_DrawFadeConsBack(con_curlines); // translucent background
	}

	// draw console text lines from top to bottom
	if (CON_HistoryView(&view))
	{
		if (rendermode == render_none) return;

		con_historypos_t first, last;
		const boolean selected = CON_HistorySelection(&first, &last);
#ifdef HWRENDER
		HWR_BeginTextBatch();
#endif
		INT32 y = view.top;
		for (size_t row = view.first; row <= view.last; row++, y += view.charwidth)
		{
			if (selected && row >= first.line && row <= last.line)
			{
				const size_t start = row == first.line ? first.column : 0;
				const size_t end = row == last.line ? last.column : CON_HistoryColumns(row);
				if (end > start)
					V_DrawFill(((INT32)start+1)*view.charwidth, y,
						(INT32)(end-start)*view.charwidth, view.charwidth, V_NOSCALESTART | 156);
			}
			CON_DrawHistoryLine(row, view.charwidth, y, view.charwidth);
		}
#ifdef HWRENDER
		HWR_EndTextBatch();
#endif
	}

	INT32 barX, barHeight, barWidth, barRange, barTop, barThumb;
	if (CON_Scrollbar(&barX, &barHeight, &barWidth, &barRange, &barTop, &barThumb))
	{
		V_DrawFill(barX, 0, barWidth, barHeight, V_NOSCALESTART | 159);
		V_DrawFill(barX, barTop, barWidth, barThumb, V_NOSCALESTART | (con_scroll_drag ? 120 : 148));
	}

	// draw prompt if enough place (not while game startup)
	if (con_curlines >= 12 * (INT32)con_scalefactor && !con_startup)
		CON_DrawInput();
}

// Console refresh drawer, call each frame
//
void CON_Drawer(void)
{
	Lock_state();

	if (!con_started || !graphics_started)
	{
		Unlock_state();
		return;
	}

	if (con_recalc)
	{
		CON_RecalcSize();
		if (con_curlines <= 0)
			CON_ClearHUD();
	}

	// console movement
	if (con_curlines != con_destlines)
		CON_MoveConsole();

	if (con_curlines > 0)
		CON_DrawConsole();
	else if (gamestate == GS_LEVEL || gamestate == GS_INTERMISSION || gamestate == GS_CREDITS
	|| gamestate == GS_EVALUATION || gamestate == GS_ENDING || gamestate == GS_CUTSCENE
	|| gamestate == GS_WAITINGPLAYERS || cv_debug)
		CON_DrawHudlines();

	Unlock_state();
}
