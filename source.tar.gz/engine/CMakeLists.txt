cmake_minimum_required(VERSION 3.20)
project(SRB2Web LANGUAGES C)

if(NOT EMSCRIPTEN)
  message(FATAL_ERROR "Configure this target with Emscripten's emcmake.")
endif()

set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}/bin")
set(SRB2_COMP_BRANCH "web")
set(SRB2_COMP_REVISION "V5.150")
set(SRB2_COMP_NOTE "Emscripten")
set(SRB2_COMP_OPTIMIZED ON)
configure_file(src/config.h.in config.h)
add_subdirectory(src)
