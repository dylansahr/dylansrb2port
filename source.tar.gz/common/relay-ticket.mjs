const encoder = new TextEncoder();
const decoder = new TextDecoder();
export const ticketLifetime = 60_000;
export const gameProtocol = "srb2-netplay-v1";

export function isSigningKey(value) {
  return typeof value === "string" && /^[A-Za-z0-9_-]{43}$/.test(value);
}

function base64url(bytes) {
  return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}

function decode(value) {
  return Uint8Array.from(atob(value.replaceAll("-", "+").replaceAll("_", "/")), c => c.charCodeAt(0));
}

function importKey(secret) {
  return crypto.subtle.importKey("raw", decode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}

export async function issueTicket(secret, { address, port, origin, visitor }) {
  const key = await importKey(secret);
  const visitorTag = await crypto.subtle.sign("HMAC", key, encoder.encode("visitor:" + visitor));
  const claims = {
    id: crypto.randomUUID(),
    expires: Date.now() + ticketLifetime,
    address,
    port,
    origin,
    visitor: base64url(new Uint8Array(visitorTag).subarray(0, 16)),
  };
  const body = base64url(encoder.encode(JSON.stringify(claims)));
  const mac = await crypto.subtle.sign("HMAC", key, encoder.encode(body));
  return `${body}.${base64url(new Uint8Array(mac))}`;
}

export async function verifyTicket(secret, token, { address, port, origin }) {
  const match = /^([A-Za-z0-9_-]{1,600})\.([A-Za-z0-9_-]{43})$/.exec(token);
  if (!match) return null;
  try {
    const [, body, signature] = match;
    const key = await importKey(secret);
    if (!await crypto.subtle.verify("HMAC", key, decode(signature), encoder.encode(body))) return null;
    const claims = JSON.parse(decoder.decode(decode(body)));
    const now = Date.now();
    if (claims.address !== address || claims.port !== port || claims.origin !== origin ||
        !Number.isSafeInteger(claims.expires) || claims.expires <= now ||
        claims.expires > now + ticketLifetime + 5000 ||
        !/^[a-f0-9-]{36}$/.test(claims.id) || !/^[A-Za-z0-9_-]{22}$/.test(claims.visitor)) return null;
    return claims;
  } catch {
    return null;
  }
}
